# Ajeet Singh — portfolio export

Three self-contained pages. Each file has every stylesheet, script, font reference and
asset inlined, so it runs from any web host, any static bucket, or straight off disk —
no build step, no dependencies, no server.

```
export/
  index.html                  Landing page
  knowra.html                 Knowra case study
  document-intelligence.html  Document Intelligence case study
```

Keep all three in the same folder — the links between them are relative.

## Deploying

Upload the three files as-is. Works on Netlify, Vercel, GitHub Pages, S3, Cloudflare
Pages, cPanel, or any Nginx/Apache directory. `index.html` is the entry point.

## The theme switcher (author-only)

Three themes ship in the page: **Nocturne** (dark blue, default), **Ember** (warm ink +
copper) and **Paper** (light minimal). Visitors never see the switcher.

To reveal it, do either of these on the live page:

- open `index.html?theme=switch` (or add `#theme-switch` to the URL), or
- press **Shift + T**.

Pick a theme and it is remembered in that browser (localStorage) and applied across all
three pages. Press **Shift + T** again to hide the switcher; the chosen theme stays.

Every visitor sees Nocturne unless you change the default. To ship a different default,
open `theme.js` in the project, and in `window.PortfolioTheme` change the two
`"nocturne"` fallbacks in `get()` to `"ember"` or `"paper"`, then re-export.

## Before you publish

1. **Résumé.** Four links point to `Ajeet-Singh-Resume.pdf`. Put that file next to
   `index.html`.
2. **Contact details.** The pages use `hello@example.com`, `https://www.linkedin.com/`
   and `https://github.com/` as placeholders. Find and replace all three.
3. **Images.** Every image area is a placeholder. The easiest route is to drop your
   screenshots into the slots in the design project and re-export — they bake into the
   bundle. To edit the exported HTML by hand instead, find each
   `<image-slot id="…"></image-slot>` and replace it with
   `<img src="your-image.png" alt="…" style="width:100%;height:100%;object-fit:cover">`.
4. **Metrics.** Knowra's four numbers are real. Add retrieval or impact numbers
   (hit rate, latency, pages processed, hours saved) where you have them.

## Notes

- Responsive from 390px up; no breakpoint stack — fluid type and auto-fitting grids.
- Motion respects `prefers-reduced-motion`.
- Colour, type, spacing and radii all come from the Nocturne design tokens; a theme is a
  token swap, nothing else.

/* Theme layer. Nocturne (design-system default, dark blue), Ember (warm ink + copper),
   Paper (light minimal). Each theme overrides the same token names on :root, so every
   page keeps reading var(--*) and nothing else has to change.

   Note on the light theme: this page uses the ramps directionally — 300/400/500 for
   muted text, 800/900 for borders and tinted fills. Paper therefore inverts the ramp
   order (100 = darkest) so those roles keep meaning on a light ground. */
(function () {
  var EMBER = {
    "--color-bg": "#12100e",
    "--color-surface": "#1f1c18",
    "--color-text": "#f0ece7",
    "--color-accent": "#d3945c",
    "--color-accent-2": "#d3945c",
    "--color-divider": "color-mix(in srgb, #f0ece7 14%, transparent)",

    "--color-neutral-100": "#f9f7f4",
    "--color-neutral-200": "#ebe7e1",
    "--color-neutral-300": "#d6d0c8",
    "--color-neutral-400": "#b4ada3",
    "--color-neutral-500": "#948d84",
    "--color-neutral-600": "#756e66",
    "--color-neutral-700": "#59534d",
    "--color-neutral-800": "#3e3934",
    "--color-neutral-900": "#26231f",

    "--color-accent-100": "#fdf6ee",
    "--color-accent-200": "#f8e7d4",
    "--color-accent-300": "#f0d0ae",
    "--color-accent-400": "#e5b585",
    "--color-accent-500": "#d3945c",
    "--color-accent-600": "#b0764a",
    "--color-accent-700": "#8a5b39",
    "--color-accent-800": "#5d3f28",
    "--color-accent-900": "#37271b",

    "--color-section": "#412613",
    "--color-section-glow": "#5c3519",
    "--color-section-ghost": "#7d4d28",

    "--shadow-sm": "0 0 0 1px #3e3934",
    "--shadow-md": "0 0 0 1px #59534d, 0 6px 18px rgba(0,0,0,0.55)",
    "--shadow-lg": "0 0 0 1px #948d84, 0 16px 40px rgba(0,0,0,0.65)"
  };

  var PAPER = {
    "--color-bg": "#fbfaf8",
    "--color-surface": "#ffffff",
    "--color-text": "#16161a",
    "--color-accent": "#4b46c0",
    "--color-accent-2": "#4b46c0",
    "--color-divider": "color-mix(in srgb, #16161a 11%, transparent)",

    "--color-neutral-100": "#16161a",
    "--color-neutral-200": "#232329",
    "--color-neutral-300": "#3b3b44",
    "--color-neutral-400": "#5d5d68",
    "--color-neutral-500": "#5f5f6b",
    "--color-neutral-600": "#6a6a74",
    "--color-neutral-700": "#c6c5c0",
    "--color-neutral-800": "#e3e2dd",
    "--color-neutral-900": "#f2f1ec",

    "--color-accent-100": "#1d1a52",
    "--color-accent-200": "#2b2778",
    "--color-accent-300": "#3d38a3",
    "--color-accent-400": "#4b46c0",
    "--color-accent-500": "#4b46c0",
    "--color-accent-600": "#7d79d8",
    "--color-accent-700": "#a9a6e7",
    "--color-accent-800": "#d3d1f4",
    "--color-accent-900": "#eeedfb",

    "--color-section": "#eceafa",
    "--color-section-glow": "#dcd9f5",
    "--color-section-ghost": "#c6c2ee",

    "--shadow-sm": "0 0 0 1px #e3e2dd",
    "--shadow-md": "0 0 0 1px #dedcd6, 0 6px 18px rgba(22,22,26,0.07)",
    "--shadow-lg": "0 0 0 1px #d3d1cb, 0 16px 40px rgba(22,22,26,0.12)"
  };

  // accent-2 mirrors accent in both themes (mono palette, as in the design system).
  [EMBER, PAPER].forEach(function (t) {
    ["100", "200", "300", "400", "500", "600", "700", "800", "900"].forEach(function (s) {
      t["--color-accent-2-" + s] = t["--color-accent-" + s];
    });
  });

  var THEMES = { nocturne: null, ember: EMBER, paper: PAPER };
  var KEY = "ajeet-portfolio-theme";
  var allKeys = Object.keys(EMBER).concat(Object.keys(PAPER)).filter(function (k, i, a) { return a.indexOf(k) === i; });
  var patchId = "portfolio-theme-patch";

  function patch(name) {
    var el = document.getElementById(patchId);
    if (name !== "paper") { if (el) el.remove(); return; }
    if (!el) {
      el = document.createElement("style");
      el.id = patchId;
      document.head.appendChild(el);
    }
    // .lighten blends photographs into a dark ground; on a light ground it would
    // erase them, so the blend is neutralised and images sit normally instead.
    el.textContent = ".lighten{mix-blend-mode:normal}";
  }

  function apply(name) {
    var vars = THEMES[name] || null;
    var root = document.documentElement;
    allKeys.forEach(function (k) {
      if (vars && vars[k]) root.style.setProperty(k, vars[k]);
      else root.style.removeProperty(k);
    });
    patch(name);
  }

  // Transient global transition so a theme swap crossfades instead of snapping.
  function crossfade() {
    if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    var s = document.createElement("style");
    s.textContent = "*{transition:background-color .4s ease,border-color .4s ease,color .4s ease,box-shadow .4s ease,background-image .4s ease}";
    document.head.appendChild(s);
    setTimeout(function () { s.remove(); }, 520);
  }

  window.PortfolioTheme = {
    themes: ["nocturne", "ember", "paper"],
    get: function () {
      try {
        var v = localStorage.getItem(KEY);
        return THEMES.hasOwnProperty(v) ? v : "nocturne";
      } catch (e) { return "nocturne"; }
    },
    set: function (name) {
      try { localStorage.setItem(KEY, name); } catch (e) {}
      crossfade();
      apply(name);
      return name;
    },
    apply: apply,
    init: function () { var n = this.get(); apply(n); return n; }
  };
})();

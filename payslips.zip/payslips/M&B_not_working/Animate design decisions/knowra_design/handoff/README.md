# Handoff: Knowra Landing Page

## Overview

A one-page marketing site for Knowra, an internal knowledge assistant. Users upload company documents (policies, handbooks, procedures), ask questions in natural language, and get answers with numbered citations that open the exact source page.

The page's job is to close four understanding gaps: who it is for, what actually ships, how access control works, and what to do next. It deliberately makes no commercial claims — Knowra is a single-organization demo build with no billing, trial, pricing, or customers, and the copy says so.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior. They are **not production code to copy directly.**

The task is to **recreate this design in your existing codebase** using its established patterns, component library, and styling approach. If no frontend environment exists yet, choose the framework appropriate for the project and implement there.

Two things in the prototype are worth porting rather than rewriting:

1. **The design token set** (see Design Tokens). The whole theme, including dark mode, is 31 CSS custom properties on the root element. Keep that structure — it is what makes theming a one-line change rather than a refactor.
2. **The responsive strategy.** One implementation, four breakpoints, fluid type via `clamp()`. There is no separate mobile page and there should not be one.

Everything else — the markup structure, the inline styles, the reveal driver — should be rebuilt in your framework's idioms.

## Fidelity

**High-fidelity.** Final colors, typography, spacing, interactions, dark mode, and responsive behavior. Recreate pixel-accurately, substituting your own component primitives where you have them (button, card, disclosure/accordion, tab group).

Two content caveats:

- **Placeholder numbers.** The stat strip reads "14 sample documents / 312 pages indexed / 40s to index the whole set / 4 roles". Replace with real figures from the demo deployment or cut the strip.
- **Placeholder video.** Four empty players (one Demo Theater, three Product Moments) marked "drop clip here". Real footage is planned. Until it exists, either keep the placeholders or hide the sections — do not ship empty players.

## Screens / Views

One page, sixteen sections in order. Page max content width **1180px**, centered, horizontal padding `clamp(20px, 4vw, 32px)`. Header content width **1240px**, padding `clamp(20px, 3vw, 40px)`.

### 1. Header

- **Purpose:** Identity, navigation, primary CTA, theme control.
- **Layout:** Sticky (`top: 0`, `z-index: 20`), height 72px, `display: flex`, `align-items: center`, `gap: 24px`. Background `color-mix(in srgb, var(--k-bg) 88%, transparent)` with `backdrop-filter: blur(12px)`. Bottom border `1px solid var(--k-rule)`.
  - **Do not use a three-column grid here.** The nav is `display: none` below 1024px; in a grid the CTA group then auto-places into the middle track and lands mid-header. Logo is `flex: none`, nav is `margin: 0 auto`, CTA group is `flex: none; margin-left: auto`.
- **Components:**
  - Logo: 28×28px square, `var(--k-mark)` fill, radius `var(--k-r-btn)`, white "K" 16px/800. Wordmark "Knowra" 22px/800, `letter-spacing: -0.03em`. Followed by a 17×17px four-point sparkle SVG in `#6366f1` (a second smaller star at 0.55 opacity).
  - Nav: Product / How it works / Access / Solutions. 14.5px/500, `var(--k-body)`, `gap: 36px`, `white-space: nowrap`. Anchors to `#product`, `#how`, `#access`, `#uses`.
  - Theme toggle: 38×38px, radius `var(--k-r-btn)`, `1px solid var(--k-border)`, `var(--k-surface)` fill. Sun icon (rays + 3.6r circle) in dark mode, crescent moon in light. `aria-label` and `title` both flip between "Switch to dark theme" / "Switch to light theme".
  - "Sign in": 14.5px/500, `var(--k-ink)`. Hidden below 1024px (it moves into the mobile menu).
  - "Try the demo": 11px 20px padding, radius `var(--k-r-btn)`, `var(--k-mark)` fill, white 14.5px/600.
  - Hamburger: 40×40px, three 18×2px bars in `var(--k-ink)`, radius 2px. Hidden above 1024px. Open state: top bar `translateY(7px) rotate(45deg)`, middle `opacity: 0`, bottom `translateY(-7px) rotate(-45deg)`, transitions 0.25s / 0.2s ease.
  - Mobile panel: below the bar, `1px solid var(--k-rule)` top border, `var(--k-bg)`, `box-shadow: 0 18px 30px rgba(40,32,90,0.08)`. Six links (Product, How it works, Access and security, Solutions, FAQ, Sign in), each 14px 4px padding, 17px/600, `1px solid var(--k-border)` bottom rule. Clicking a link closes the panel.

### 2. Hero

- **Purpose:** State the problem, name the product, demonstrate the citation loop.
- **Layout:** Centered column, padding `clamp(48px,6vw,80px)` top / `clamp(40px,5vw,68px)` bottom. Background: two radial gradients over `var(--k-bg)` — `900px 480px at 12% 22%` in `color-mix(in srgb, var(--k-accent) 16%, transparent)` and `760px 420px at 88% 8%` in `color-mix(in srgb, var(--k-soft) 15%, transparent)`, both fading to transparent at 60%.
- **Components:**
  - Constellation SVG: absolutely positioned, `inset: 0`, `viewBox="0 0 1440 900"`, `preserveAspectRatio="xMidYMid slice"`, `opacity: 0.5`, `pointer-events: none`. Six polyline paths stroked `var(--k-net)` at 1px, ten 3r circles filled `var(--k-netdot)`. Note: SVG presentation attributes do not accept `var()` — set stroke/fill via `style`, not `stroke=`/`fill=`.
  - Eyebrow pill: "Internal knowledge assistant", 7px 14px, radius `var(--k-r-pill)`, `var(--k-surface)` fill, `1px solid var(--k-line)`, 12.5px/600 in `var(--k-deep)`, 7px accent dot, `box-shadow: 0 2px 8px color-mix(in srgb, var(--k-accent) 8%, transparent)`, `white-space: nowrap`.
  - H1: "Your organization already has the answers." `clamp(34px, 7.2vw, 70px)`, weight 800, `line-height: 1.05`, `letter-spacing: -0.04em`, `max-width: 17ch`, `text-wrap: balance`.
  - Subhead: "Upload your policies and handbooks. Ask in plain language. Open the exact page the answer came from." `clamp(16px, 2.2vw, 19px)`, `line-height: 1.55`, `var(--k-body)`, `max-width: 58ch`, `text-wrap: pretty`.
  - CTA row: "Try the demo" (`var(--k-solid)` fill, `var(--k-onsolid)` text, `box-shadow: 0 10px 24px rgba(25,23,53,0.2)`) and "Sign in" (`var(--k-surface)` fill, `1px solid var(--k-border)`). Both 14px 26px, radius `var(--k-r-btn)`, 15px/600, `white-space: nowrap`. Stack full-width below 480px.
  - Honesty line: "A working demo of a single-organization knowledge assistant. No trial, billing, or plan to sign up for." 13.5px, `var(--k-muted)`, `max-width: 58ch`.
  - **App window** (the centerpiece): `max-width: 1000px`, radius `var(--k-r-panel)`, `var(--k-surface)` fill, **`2px solid var(--k-accent)`**, `box-shadow: 0 34px 80px rgba(52,40,120,0.18)`, `overflow: hidden`, `text-align: left`. Entrance: `heroIn 0.85s cubic-bezier(0.16,0.8,0.3,1) forwards`.
    - Title bar: 13px 18px, `var(--k-panel2)` fill, `1px solid var(--k-line2)` bottom. Three 10px traffic lights (#ff5f57, #febc2e, #28c840), then "Knowra — Ask" 12px/600 `var(--k-muted)`.
    - Body: `grid-template-columns: 196px minmax(0,1fr)`.
    - Sidebar: 20px 14px, `var(--k-panel2)`, `1px solid var(--k-line2)` right rule. "WORKSPACE" label 10.5px/700 uppercase `letter-spacing: 0.12em` `var(--k-faint)`; items Ask (active: `var(--k-tint)` fill, `var(--k-deep)` text, radius `var(--k-r-sm)`), Documents, Sources, Admin at 13.5px/500 `var(--k-body)`; footer note "14 documents indexed" 11.5px `var(--k-faint)` above a `var(--k-line2)` rule.
    - Main pane: 24px 26px 26px, `min-height: 296px`.
    - Question bubble: right-aligned, `max-width: 74%`, 12px 16px, radius `var(--k-r-card) var(--k-r-card) 4px var(--k-r-card)`, `var(--k-solid)` fill, `var(--k-onsolid)` text 15px/500. Copy: "What is the remote work policy for new joiners?"
    - Answer block: 18px 20px, radius `var(--k-r-card)`, `var(--k-panel)` fill, `1px solid var(--k-line)`. Answer text 15px/1.6 `var(--k-ink2)`: "New joiners work from the office for their first 30 days, then move to the standard hybrid schedule of three days on site. Requests for full remote go through your manager and HR." Entrance `slotA 1.1s … forwards`.
    - Citation chip: inline button, 2px 7px, radius 5px, `var(--k-accent)` fill (`var(--k-deep)` once open), white 11px/700, `vertical-align: 2px`. Click opens the source viewer.
    - Sources header: `display: flex; flex-wrap: wrap; column-gap: 10px; row-gap: 4px`, `1px solid var(--k-line2)` top rule. "SOURCES" 10.5px/700 uppercase `var(--k-faint)`, then hint "Click a source to open the page" 11.5px/600 `var(--k-deep)` with **`flex: 0 0 100%`** — it needs its own full-width line or its second line overflows the box. Hint text empties once the viewer is open.
    - Source rows (entrance `slotB 1.5s … forwards`): each `display: flex; gap: 10px`, 10px 12px, radius `var(--k-r-sm)`, `var(--k-surface)` fill, 13px. Row 1 is a button — `[1]` in `var(--k-accent)`/700, filename 600 with `min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap`, "page 5" in `var(--k-muted)` `white-space: nowrap`, "Open" 700 `var(--k-deep)` pushed right, border `1px solid var(--k-line)`. Row 2 is static (Onboarding Handbook.docx, page 12), border `1px solid var(--k-line2)`, text `var(--k-body)`.
    - Source viewer (conditional): 14px top margin, radius `var(--k-r-sm)`, `var(--k-surface)`, `1px solid var(--k-line)`, entrance `slotA 0.45s … forwards`. Header 10px 14px, `var(--k-panel2)`, label "Remote Work Policy.pdf — page 5" 11px/700 uppercase `var(--k-faint)`, "Close" button 12px/700 `var(--k-deep)` right-aligned. Body 14px 16px, 11.5px/1.8 `var(--k-muted)`: line "5.2 Onboarding period", then the highlighted passage — `var(--k-hi)` fill, `var(--k-ink2)` text, 6px 8px, radius 6px, weight 600, reading "New joiners are office-based for the first thirty days, after which the standard hybrid schedule of three on-site days applies." — then "5.3 Full-remote arrangements require manager and People team approval."
  - Caption below the window: "Question → Answer → Sources" 14.5px/600 `var(--k-muted)`.

### 3. Stat strip

- Four columns, `gap: 24px`, padding 30px 0, `var(--k-surface)` background, `1px solid var(--k-rule)` top.
- Each: value 26px/800 `letter-spacing: -0.03em`, label 13px/600 `var(--k-muted)`.
- Content: 14 / sample documents loaded · 312 / pages indexed · 40s / to index the whole set · 4 / roles with separate visibility. **Placeholder — replace with real numbers.**
- Reveal: stagger.

### 4. Built for

- Centered header: eyebrow "BUILT FOR" 12.5px/700 uppercase `letter-spacing: 0.14em` `var(--k-muted)`; H2 "Who sees themselves in this" `clamp(25px,3.8vw,36px)`/800.
- Four cards, `gap: 16px`, left-aligned text: 24px padding, radius `var(--k-r-card)`, `var(--k-surface)`, `1px solid var(--k-border)`. Title 18px/700, body 14.5px/1.55 `var(--k-body)`.
- Content: Employees — "Ask the handbook instead of asking a colleague." / HR — "Answer the same policy question once, not forty times." / Finance — "Pull figures from reports only your team can open." / Admins — "Manage users, roles and what each document exposes."
- Reveal: stagger.

### 5. Problem strip

- `var(--k-wash)` background, `1px solid var(--k-line2)` top and bottom. Three columns, `gap: 40px`, padding 40px 0.
- Each: number 12.5px/800 `var(--k-soft)`, text 15.5px/1.5 `var(--k-ink2)`.
- Content: 01 "The knowledge is already written down — spread across drives, wikis and attachments nobody remembers the name of." / 02 "The same questions come back weekly, and HR re-answers what is already on page five of something." / 03 "Generic AI has never read your handbook, but will still answer confidently, with nothing behind it."

### 6. How it works

- Centered header: "HOW IT WORKS" / "Product journey showcase" `clamp(27px,4.2vw,40px)`/800.
- Five columns, `gap: 20px`. Each: a row with the number 13px/800 `var(--k-accent)` and a 2px rule `linear-gradient(90deg, var(--k-accent), var(--k-line))` filling remaining width; then title 18px/700; then body 14.5px/1.55 `var(--k-body)`.
- Content: 01 Upload knowledge — "Add PDFs, Word files and text documents, one at a time or in bulk." / 02 Ask naturally — "Type the question the way you would ask a colleague. No query syntax." / 03 Get grounded answers — "Knowra answers only from retrieved passages in your own documents." / 04 Verify the source — "Open the cited file at the exact page, with the passage highlighted." / 05 Access the right knowledge — "Retrieval respects roles, so people only see what they are cleared for."
- Below 1024px: single column, the gradient rules hide, each step gets 18px vertical padding and a `1px solid var(--k-rule)` bottom rule.
- Reveal: stagger.

### 7. Ask → Answer → Verify

- `var(--k-surface)` background, `1px solid var(--k-rule)` top. Split `0.85fr / 1.15fr`, `gap: 56px`, `align-items: center`, padding 60px 0.
- Left: eyebrow "ASK → ANSWER → VERIFY"; H2 "Every claim carries its page number." `clamp(25px,3.8vw,36px)`/800; citation example chip — inline-flex, 9px 14px, radius `var(--k-r-btn)`, `var(--k-panel)` fill, `1px solid var(--k-line)`, 13.5px/600 `var(--k-deep)`, text "[1] Remote Work Policy.pdf · page 5".
- Right: three columns, `gap: 24px`. Each has a 22px circular `var(--k-tint)` badge with a `var(--k-accent)` check, title 15.5px/700, body 14px/1.55 `var(--k-body)`.
- Content: "Numbered citations" — "Each claim points at a file and a page, not a vague reference list." / "Highlighted passage" — "The viewer opens on the sentence the answer was built from." / "No source, no claim" — "When retrieval finds nothing authorized, Knowra says so instead of guessing."
- Reveal: stagger.

### 8. Product Demo Theater

- Full-bleed dark panel inset by the page padding: radius `var(--k-r-panel)`, `linear-gradient(135deg, #1b1838 0%, #191735 55%, #241d5c 100%)`, white text. **This panel stays dark in both themes.**
- Split `0.8fr / 1.2fr`, `gap: 48px`, padding 44px 44px 0.
- Left: "PRODUCT DEMO" 12px/700 uppercase `letter-spacing: 0.16em` `var(--k-ondark)`; H2 "Product Demo Theater" `clamp(27px,4.2vw,40px)`/800; body 16px/1.6 `#b6b2ce` — "One continuous walkthrough: upload a policy, ask a question, follow the citation to the page it came from."; button "Watch the walkthrough" 13px 24px, radius `var(--k-r-btn)`, white fill, `#191735` text 14.5px/700.
- Right: 16:9 player placeholder — radius `var(--k-r-card)`, `radial-gradient(520px 300px at 60% 40%, color-mix(in srgb, var(--k-accent) 38%, transparent), rgba(15,13,40,0.9))`, `1px solid rgba(255,255,255,0.14)`. Centered 66px white circle at 0.92 alpha with `box-shadow: 0 10px 30px rgba(0,0,0,0.35)` and a CSS triangle play glyph (`border-width: 11px 0 11px 18px`); scales to 1.09 on hover over 0.3s. Bottom-left label "Walkthrough clip — drop the recording here" 12px/600 white at 0.6.
- Chapter row: five equal cells across the panel's full width, `1px solid rgba(255,255,255,0.12)` top, each 20px 12px centered 13.5px/600 `#b6b2ce` with a `rgba(255,255,255,0.08)` right divider. Labels: Upload · Ask · Answer · Verify · Access.
- Reveal: rise.

### 9. Access and security (merged)

- **Purpose:** Demonstrate that retrieval is permission-scoped, then explain the mechanics.
- Header split (two equal columns, `align-items: end`, `gap: 60px`): eyebrow "ACCESS AND SECURITY"; H2 "The same question returns different sources." `clamp(28px,4.4vw,42px)`/800; right paragraph 16.5px/1.6 `var(--k-body)` — "Retrieval runs inside the asker's permissions. A document the person cannot open is never read, never summarized, and never cited. Switch the role to see what changes."
- **Role card:** radius `var(--k-r-panel)`, `var(--k-surface)`, `1px solid var(--k-border)`, `box-shadow: 0 20px 46px rgba(40,32,90,0.08)`, `overflow: hidden`.
  - Tab row: 14px 18px, `var(--k-surface2)` fill, `1px solid var(--k-border)` bottom, `gap: 8px`. Four pills 9px 18px, radius `var(--k-r-pill)`, 13.5px/600. Active: `var(--k-solid)` fill / `var(--k-onsolid)` text / `var(--k-solid)` border. Inactive: `var(--k-surface)` fill / `var(--k-body)` text / `var(--k-border)` border. Below 760px the row scrolls horizontally (`overflow-x: auto`, `flex-wrap: nowrap`, items `flex: none`).
  - Body: `grid-template-columns: 1fr 1.15fr`, single column below 760px (the divider flips from left border to top border).
  - Left, 28px: "ASKED BY {ROLE}" 11.5px/700 uppercase `var(--k-faint)`; question bubble 14px 16px, radius `var(--k-r-card) var(--k-r-card) var(--k-r-card) 4px`, `var(--k-wash)` fill, 18px/600 — "How much did we spend on contractors last quarter?"; "ANSWER" label; answer 15px/1.65 `var(--k-ink2)`.
  - Right, 28px, `var(--k-panel2)` fill: "SOURCES VISIBLE TO THIS ROLE" label, then four rows 12px 14px, radius `var(--k-r-sm)`, 14px. Authorized: `var(--k-surface)` fill, `1px solid var(--k-line)`, `var(--k-ink)` text, 20px circular `var(--k-tint)` badge with `var(--k-accent)` ✓, state label 12px/700 `var(--k-deep)`. Unauthorized: `var(--k-surface2)` fill, `1px solid var(--k-line2)`, `var(--k-faint)` text, `var(--k-border)` badge with ✕, state label `var(--k-faint)`.
- **Role data** (the whole point of the section — the answer AND the source list change together):

  | Role | Answer | Sources |
  |---|---|---|
  | Employee | "You do not have access to finance reporting. Knowra could not find an authorized source for this question and did not answer it." | Employee Handbook.pdf ✓ Readable · Remote Work Policy.pdf ✓ Readable · Q3 Contractor Spend.xlsx ✕ Not visible · Vendor Contracts 2026.pdf ✕ Not visible |
  | HR | "Contractor headcount for Q3 was 14 across three teams. Cost figures sit in finance documents you cannot open, so they are not included here." | Contractor Roster Q3.docx ✓ Readable · Employee Handbook.pdf ✓ Readable · Q3 Contractor Spend.xlsx ✕ Not visible · Vendor Contracts 2026.pdf ✕ Not visible |
  | Finance | "Contractor spend for Q3 was $412,800, up 9% on Q2. The largest line is engineering contract work at $221,400." | Q3 Contractor Spend.xlsx ✓ Cited [1] · Vendor Contracts 2026.pdf ✓ Cited [2] · Employee Handbook.pdf ✓ Readable · Personnel Files.pdf ✕ Not visible |
  | Admin | "Contractor spend for Q3 was $412,800 across 14 contractors. Admins can also see which documents were retrieved and who else has access to them." | Q3 Contractor Spend.xlsx ✓ Cited [1] · Vendor Contracts 2026.pdf ✓ Cited [2] · Contractor Roster Q3.docx ✓ Cited [3] · Retrieval audit log ✓ Readable |

  The dollar figures are illustrative. Replace with real demo data or genericize.
- **Security cards:** three columns, `gap: 16px`, 28px top margin. Each 22px, radius `var(--k-r-card)`, `var(--k-surface)`, `1px solid var(--k-border)`; title 16.5px/700, body 14.5px/1.6 `var(--k-body)`.
  1. Authenticated accounts — "Every person signs in. There is no anonymous or public access to the workspace."
  2. Role-based access control — "Employee, HR, Finance and Admin roles decide which parts of the product and which documents a person reaches."
  3. Per-document permissions — "Access is set on the document, not just the folder. A file can be visible to one role and invisible to the rest."
  4. Retrieval fails closed — "The model only ever sees passages the asker is authorized to read. If nothing is authorized, the answer is a refusal."
  5. Your deployment, your documents — "Documents are indexed inside the deployment you run, and are not used to train any public model."
  6. Full retrieval log — "Admins can see which documents were retrieved for an answer and who else has access to them."
- **Compliance footnote:** 13.5px/1.6 `var(--k-muted)`, `max-width: 74ch` — "Knowra is a demo deployment and does not hold SOC 2, ISO 27001, or GDPR certification. The points above describe how the system behaves, not what it is certified for." **Keep this. Do not add compliance badges that are not true.**
- Reveal: rise.

### 10. Product Moments

- `var(--k-surface)` background. Centered header "PRODUCT MOMENTS" / "Three short clips, one minute each".
- Three cards, `gap: 20px`. Each: 16:10 placeholder — radius `var(--k-r-card)`, `linear-gradient(150deg, #221e4c, #191735 60%, #2a2270)`, `1px solid var(--k-line2)`, centered 52px white circle at 0.9 with play triangle (`border-width: 9px 0 9px 14px`), scaling to 1.1 on hover; bottom-left "Drop clip here" 11.5px/600 white at 0.55. Below: title 17px/700, meta 14px `var(--k-muted)`.
- Content: "Upload and organize knowledge" (45s) / "Ask questions naturally" (50s) / "Verify answers with sources" (55s).
- **Hidden below 760px** (`display: none`) — deliberate; three empty players are dead weight on a phone.
- Reveal: stagger.

### 11. What you can put in

- Split `1fr / 1.25fr`, `gap: 60px`, padding 72px 0, `align-items: center`.
- Left: eyebrow "WHAT YOU CAN PUT IN"; H2 "PDF, DOCX, TXT." `clamp(27px,4.2vw,40px)`/800; body 16px/1.6 `var(--k-body)` — "Drop one file or a folder of them. Knowra indexes the text and keeps the original so every citation can point back to a real page."; three format pills 7px 14px, radius `var(--k-r-pill)`, `var(--k-tint)` fill, `var(--k-deep)` 13px/700 — .pdf .docx .txt.
- Right: two columns, `gap: 12px`. Each row `display: flex; gap: 12px`, 16px 18px, radius `var(--k-r-card)`, `var(--k-surface)`, `1px solid var(--k-border)`, 14.5px/500 `var(--k-ink2)`, with an 8px `var(--k-soft)` dot.
- Content: Employee handbooks · HR and leave policies · Finance and expense procedures · Onboarding material · Internal process documentation · Bulk folder upload.

### 12. Feature grid

- `var(--k-surface)` background. Centered header "WHAT SHIPS TODAY" / "Six things you can actually use".
- Three columns, `gap: 16px`. Each card 26px, radius `var(--k-r-card)`, `var(--k-surface2)` fill, `1px solid var(--k-border)`; 34px numbered badge (radius `var(--k-r-sm)`, `var(--k-tint)` fill, `var(--k-accent)` 12px/800); title 19px/700 `letter-spacing: -0.025em`; body 14.5px/1.6 `var(--k-body)`.
- Content: 01 Cited chat — "Natural-language answers with numbered sources attached to each claim." / 02 Document upload — "PDF, DOCX and TXT, single file or bulk, with indexing status per document." / 03 Source viewer — "Opens the cited document at the right page with the passage highlighted." / 04 Roles and permissions — "Employee, HR, Finance and Admin, each with its own view of the library." / 05 Admin console — "Add users, assign roles and control which documents each role can reach." / 06 Usage dashboard — "See what is being asked, what got answered, and which documents carry the load."
- Reveal: stagger.

### 13. Solutions / use cases

- `var(--k-wash)` background, `1px solid var(--k-line2)` top and bottom. Centered header "SOLUTIONS" (eyebrow in `var(--k-soft)`) / "Four questions Knowra answers well".
- Rows, `gap: 12px`, each `grid-template-columns: 120px 1fr 1fr`, `gap: 28px`, 20px 24px, radius `var(--k-r-sm)`, `var(--k-surface)`, `1px solid var(--k-line2)`, `align-items: center`. Role pill 5px 12px, radius `var(--k-r-pill)`, `var(--k-tint)` fill, `var(--k-deep)` 12px/700; question 16.5px/600; answer 14.5px/1.6 `var(--k-body)`. Single column below 1024px.
- Content: Employee — "How many days of leave do I have left this year?" / "Answered from the leave policy, with the accrual table cited by page." · Employee — "Can I work remotely from another country?" / "Answered from the remote work policy, including the approval path." · Finance — "What was contractor spend last quarter?" / "Answered from finance reports that only the Finance role can open." · Admin — "Who has access to the personnel files?" / "Answered from the access configuration, with the role list shown."

### 14. FAQ

- Split `320px / 1fr`, `gap: 60px`, padding 76px 0. Single column below 1024px.
- Left: eyebrow "FAQ"; H2 "Questions people ask first." `clamp(25px,3.6vw,34px)`/800.
- Right: eight disclosure rows, `gap: 10px`. Each radius `var(--k-r-card)`, `var(--k-surface)`, `1px solid var(--k-border)`, `overflow: hidden`. Trigger is a full-width button, 20px 24px, 17px/700, `var(--k-ink)`, with a right-aligned +/– glyph at 22px/400 (`var(--k-accent)` when open, `var(--k-faint)` when closed). Answer 0 24px 22px padding, 15.5px/1.65 `var(--k-body)`, `max-width: 70ch`.
- Single-open accordion; first item open by default; clicking the open row closes it.
- Content:
  1. What file formats can I upload? — "PDF, DOCX and TXT. Files can be uploaded one at a time or in bulk, and the original is kept so citations can open the real page."
  2. How do citations work? — "Answers are generated only from passages retrieved out of your documents. Each claim carries a numbered marker that links to the source file and page, with the passage highlighted in the viewer."
  3. Who can see which documents? — "Access is set per document and per role. Retrieval runs inside the asker's permissions, so an unauthorized document is never read by the model and never appears as a source."
  4. Is my data used to train a model? — "No. Documents are indexed for retrieval inside your deployment and are not used to train any public model."
  5. How is this different from a public chatbot? — "A public chatbot answers from what it was trained on and has never read your handbook. Knowra answers only from documents you uploaded, and shows you which ones. If your documents do not say it, Knowra does not answer it."
  6. Can Knowra edit or rewrite my documents? — "No. It reads and cites your files. It does not rewrite, version or reformat them, and it is not a document editor."
  7. Is this a commercial product? — "Not yet. There is no billing, no plans and no customer list. This is a working single-organization build you can try as a demo."
  8. How do I try it? — "Open the demo workspace. It is preloaded with sample policy documents, so you can ask a question and follow a citation without uploading anything."

### 15. Closing CTA

- Inset dark panel: radius `var(--k-r-panel)`, `linear-gradient(140deg, #211d52 0%, #191735 46%, #2b2170 100%)`, white text. Dark in both themes.
- Centered column, padding `clamp(48px,7vw,88px)` / `clamp(24px,4vw,48px)`.
- H2 "Stop searching. Start asking." `clamp(32px,5.6vw,60px)`, weight 800, `line-height: 1.04`, `letter-spacing: -0.04em`, `max-width: 18ch`.
- Body 18px/1.55 `#c5c1e2`, `max-width: 54ch` — "Open the demo workspace, ask it something, and click a citation. That is the whole product in about a minute."
- Buttons 15px 28px, radius `var(--k-r-btn)`: "Try the demo" (`var(--k-surface)` fill, `var(--k-ink)` text, 700) and "Sign in" (transparent, `1px solid rgba(255,255,255,0.35)`, white 600). Stack full-width below 480px.
- Reveal: rise.

### 16. Footer

- `grid-template-columns: 1.4fr 1fr 1fr 1fr`, `gap: 48px`, padding 64px 0 40px. Two columns below 760px, one below 480px.
- Brand block: logo mark + wordmark, then 15px/1.6 `var(--k-body)`, `max-width: 30ch` — "Turn your organization's knowledge into answers you can check."
- Three link columns, headings 11.5px/700 uppercase `letter-spacing: 0.14em` `var(--k-faint)`, links 15px `var(--k-body)`, `gap: 11px`:
  - Product: How it works, Access and security, What you can upload
  - Solutions: HR and People, Finance, Employees, Admins
  - Company: About, Contact, Privacy, Terms
- Legal bar: `1px solid var(--k-rule)` top, 22px 0 44px, 13.5px `var(--k-muted)`, "© 2026 Knowra" left and "Demo deployment — not a commercial service" right. Stacks below 480px.
- **Pricing and Status were deliberately removed.** Do not re-add them unless those pages exist.

## Interactions & Behavior

### Hero citation demo
Clicking the `[1]` chip or the first source row sets `heroSourceOpen = true`, which renders the source viewer panel with the highlighted passage; the chip darkens to `var(--k-deep)` and the "Click a source to open the page" hint empties. "Close" reverses it. This is the page's primary interaction — make it obvious and keep the hover affordance on both triggers.

### Role switcher
Four tabs, single selection, default Employee. Changing role swaps the answer text, the "Asked by {role}" label, and the four source rows with their authorized/unauthorized states. No animation on switch — the content change is the point.

### FAQ accordion
Single-open. Index 0 open on load. Clicking the open item closes all.

### Theme toggle
Flips a `theme` value between `"light"` and `"dark"`, writes it to `localStorage["knowra-theme"]`, and rewrites the token set on the root element. **Read the stored value where state is initialized, not in a mount lifecycle hook** — reading it after first render causes a light flash before dark applies. Also set `color-scheme` on the root so form controls and scrollbars follow.

### Mobile menu
Hamburger toggles a slide-down panel. Any link click closes it. The panel includes Sign in, which is hidden from the bar below 1024px.

### Scroll-in motion
Nine containers carry a reveal, one per section — six `stagger`, three `rise`. Two variants:

- **rise:** the container moves `translateY(26px) → none` with `opacity 0 → 1`.
- **stagger:** each direct child animates `translateY(18px) scale(0.985) → none`, delayed 80ms per index.

Timing: `opacity 0.62s cubic-bezier(0.16,0.8,0.3,1)`, `transform 0.68s` same easing. Trigger line is 88% of viewport height. Fires once per element.

Four requirements the prototype's driver satisfies, all worth keeping:

1. **Fail safe.** Content is visible by default and only hidden once the driver has proven it can run. A driver that never fires must leave the page fully readable, never blank.
2. **Never hide and reveal in the same tick.** Set the hidden state, flush layout, return. Revealing in the same tick means no start frame and no transition.
3. **Reveal anything already passed.** Test `rect.top < viewportHeight * 0.88` only — do not also require `rect.bottom > 0`, or anchor jumps and restored scroll positions leave sections stranded invisible.
4. **Respect `prefers-reduced-motion: reduce`** by skipping the hide step entirely.

In a React codebase this is an `IntersectionObserver` with a `once: true` flag per element — cleaner than the scroll handler used here, which exists only because the prototype's preview frame does not deliver observer callbacks. Keep requirements 1, 3 and 4 regardless of mechanism.

### Hero entrance
Three staged animations on load: card `heroIn 0.85s`, answer `slotA 1.1s`, sources `slotB 1.5s`. **The keyframes animate transform only — no opacity.** Stagger comes from held keyframe segments (`0%, 30% { transform: translateY(10px) }`) rather than `animation-delay`, so an animation that never starts cannot leave content invisible. Fill mode is `forwards`, never `both`.

### Hover states
Play placeholders scale to 1.09 / 1.10 over 0.3s. Links go `var(--k-deep)` → a darker mix. Focus is a 2px `var(--k-accent)` outline at 3px offset — never leave the browser default.

## State Management

Six values, all local to the page. No data fetching.

| State | Type | Default | Drives |
|---|---|---|---|
| `theme` | `"light" \| "dark"` | from `localStorage`, else `"light"` | the entire token set |
| `role` | `0–3` | `0` (Employee) | role card answer + sources |
| `openFaq` | `number` | `0` | accordion; `-1` = all closed |
| `heroSourceOpen` | `boolean` | `false` | hero source viewer |
| `menuOpen` | `boolean` | `false` | mobile panel + hamburger glyph |
| reveal bookkeeping | — | — | which elements have been revealed |

## Design Tokens

The whole theme is these custom properties on the root element. Light is the default; the dark column is what the toggle writes. Values marked *derived* are computed from the accent with `color-mix()` — keep that so a palette change stays coherent.

### Accent ramp

| Token | Light | Dark | Notes |
|---|---|---|---|
| `--k-accent` | `#7c3aed` | `#7c3aed` | base accent |
| `--k-deep` | `#6d28d9` | `#6d28d9` | accent text, links |
| `--k-tint` | `#f1e9ff` | *derived* `mix(accent 22%, surface)` | badge and pill fills |
| `--k-soft` | `#a78bfa` | `#a78bfa` | secondary accent marks |
| `--k-wash` | `#f6f0ff` | *derived* `mix(accent 12%, bg)` | tinted section grounds |
| `--k-panel` | `#f9f4ff` | *derived* `mix(accent 12%, surface)` | answer panel |
| `--k-panel2` | `#fcfaff` | *derived* `mix(accent 8%, surface)` | inset panels, sidebars |
| `--k-line` | `#e6d9fb` | *derived* `mix(accent 30%, surface)` | accent-tinted borders |
| `--k-line2` | `#f0e8fb` | *derived* `mix(accent 18%, surface)` | subtle inner rules |
| `--k-hi` | `#e9dcff` | *derived* `mix(accent 34%, surface)` | highlighted passage |
| `--k-ondark` | `#c4b1fb` | same | eyebrows on dark panels |
| `--k-net` | `#d6c9f2` | *derived* `mix(accent 40%, bg)` | constellation lines |
| `--k-netdot` | `#c3aeea` | *derived* `mix(accent 55%, bg)` | constellation dots |

### Neutrals and surfaces

| Token | Light | Dark |
|---|---|---|
| `--k-bg` | `#fdfcfa` | `#14121f` |
| `--k-surface` | `#ffffff` | `#1c1930` |
| `--k-surface2` | `#fcfaf7` | `#211d36` |
| `--k-ink` | `#191735` | `#f4f2ff` |
| `--k-ink2` | `#2c2949` | `#e4e0f6` |
| `--k-body` | `#5b5878` | `#a8a3c6` |
| `--k-muted` | `#8d8aa3` | `#8d88ac` |
| `--k-faint` | `#a6a3ba` | `#7b769a` |
| `--k-border` | `#eee7dc` | `#2e2947` |
| `--k-rule` | `#ece5da` | `#282340` |
| `--k-solid` | `#191735` | `#f1e9ff` (the tint) |
| `--k-onsolid` | `#ffffff` | `#191735` |
| `--k-mark` | `#1e1b4b` | `#7c3aed` (the accent) |

`--k-solid` / `--k-onsolid` invert as a pair — the primary button is dark-on-light in light mode and light-on-dark in dark mode.

### Radius

| Token | Value | Used for |
|---|---|---|
| `--k-r-panel` | `22px` | large panels, hero window |
| `--k-r-card` | `16px` | cards, media placeholders |
| `--k-r-sm` | `12px` | rows, inner panels |
| `--k-r-btn` | `8px` | buttons, logo mark |
| `--k-r-pill` | `999px` | pills, badges, dots |

The prototype also ships two alternate radius sets used by a design-time control — Soft (`12 / 10 / 8 / 6 / 999`) and Square (all `0`). Useful if you ever want a squarer treatment; not required.

### Fixed colors (theme-independent)

Dark panels stay dark in both themes: Demo Theater `linear-gradient(135deg, #1b1838, #191735 55%, #241d5c)`, closing CTA `linear-gradient(140deg, #211d52, #191735 46%, #2b2170)`, moment cards `linear-gradient(150deg, #221e4c, #191735 60%, #2a2270)`. On-dark body text `#b6b2ce` / `#c5c1e2`. Traffic lights `#ff5f57` / `#febc2e` / `#28c840`. Sparkle glyph `#6366f1`.

### Typography

- Family: **Plus Jakarta Sans**, weights 400–800, fallback `system-ui, sans-serif`. `-webkit-font-smoothing: antialiased`.
- H1 `clamp(34px, 7.2vw, 70px)` / 800 / 1.05 / `-0.04em`
- H2 large `clamp(28px, 4.4vw, 42px)` / 800 / 1.08 / `-0.035em`
- H2 medium `clamp(27px, 4.2vw, 40px)` / 800 / `-0.035em`
- H2 small `clamp(25px, 3.6vw, 36px)` / 800 / `-0.03em`
- CTA display `clamp(32px, 5.6vw, 60px)` / 800 / 1.04 / `-0.04em`
- Card title 17–19px / 700 / `-0.02em`
- Body 14.5–16.5px / 400–500 / 1.55–1.65
- Eyebrow 11.5–12.5px / 700 / uppercase / `letter-spacing: 0.12–0.16em`
- Micro-label 10.5–11.5px / 700 / uppercase / `0.1–0.12em`

### Spacing

- Section bands 60 / 64 / 72 / 76px vertical (compact 40px and generous 112px variants exist behind a design-time control)
- Grid gaps 12 / 16 / 20 / 24 / 48 / 56 / 60px
- Card padding 22 / 24 / 26 / 28px
- Container padding `clamp(20px, 4vw, 32px)`
- Content width 1180px, header 1240px

### Shadows

| Use | Value |
|---|---|
| hero window | `0 34px 80px rgba(52,40,120,0.18)` |
| role card | `0 20px 46px rgba(40,32,90,0.08)` |
| primary button | `0 10px 24px rgba(25,23,53,0.2)` |
| mobile menu | `0 18px 30px rgba(40,32,90,0.08)` |
| pill / play button | `0 2px 8px color-mix(in srgb, var(--k-accent) 8%, transparent)` / `0 10px 30px rgba(0,0,0,0.35)` |

### Breakpoints

| Max width | Changes |
|---|---|
| 1024 | nav hides, hamburger appears; two-column splits stack; 3- and 4-up grids go 2-up; FAQ and use-case rows go single column; journey becomes a divided vertical list with its gradient rules hidden |
| 760 | hero card drops its sidebar; 2-up grids go 1-up; stat strip goes 2-up; Demo Theater stacks and its chapter row goes 2-up; role card stacks with its divider flipping to a top border; role tabs scroll horizontally; footer goes 2-up; Product Moments hides |
| 480 | footer single column; CTA rows stack full width; legal bar stacks |

Verified at 390, 430, 768, 1024 and 1280+.

## Assets

No raster images or icon libraries. Everything is inline SVG or CSS:

- **Logo mark** — CSS square with a text "K". Replace with the real Knowra mark.
- **Sparkle glyph** — inline SVG, two four-point stars, `#6366f1`.
- **Constellation** — inline SVG, six paths and ten circles on a 1440×900 viewBox.
- **Theme icons** — inline SVG, single path plus a circle whose radius toggles between 3.6 and 0.
- **Play glyphs** — CSS triangles via asymmetric borders.
- **Checks and crosses** — text characters (✓ / ✕).
- **Font** — Plus Jakarta Sans from Google Fonts. Self-host in production.
- **Video** — four placeholders awaiting real recordings.

Consider swapping the inline glyphs for your icon library (Lucide matches the weight) if you already have one.

## Files

- `Knowra Landing Page.dc.html` — the final design. Opens directly in a browser; all styling is inline plus the token block and keyframes in the head.
- `Knowra Landing Page (Modernist).dc.html` — an earlier version of the same content in a different visual system (flat, red accent, square corners, 2px rules). Reference only; not the direction being shipped.
- `support.js` — the prototype's runtime. **Not part of the design.** It exists so the HTML file renders standalone; do not port it.

The design file's logic class holds all copy and data as plain arrays — audiences, problems, steps, verify points, role data, security cards, upload types, features, use cases, FAQ, footer columns. That is the fastest place to read exact strings.

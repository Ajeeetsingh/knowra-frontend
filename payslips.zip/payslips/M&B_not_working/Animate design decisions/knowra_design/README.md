# Knowra — design files

Two self-contained HTML files. Both open directly in a browser, no build step, no server.

| File | What it is |
|---|---|
| `Knowra Landing Page.dc.html` | Public marketing page. 16 sections, light/dark, responsive. |
| `Knowra App Screens.dc.html` | The product: 13 screens in one navigable prototype. |
| `support.js` | Runtime the two HTML files load. Not part of the design — do not port it. |
| `handoff/README.md` | Full developer spec for the landing page (sections, tokens, states, breakpoints). |

## Running them

Open either `.dc.html` file in a browser. `support.js` must sit beside them, so keep the folder together.

## App screens

Starts on Login — click **Sign in** to enter. After that the sidebar navigates. A collapsed **Screens** launcher sits bottom-right and jumps straight to any of the 13; it is a review control, not product UI, and should be removed before handoff.

Workspace — Dashboard, Chat, Documents
Manage — Admin overview, Upload Center, Collections, Users
Analytics — User, Knowledge, Error
System — System Monitoring, Reports & Export, Profile

Plus the Assign Role modal, reachable from any Users row.

## Shared design system

Both files use the same CSS custom properties on the root element — one accent ramp, one neutral set, one radius scale. Light and dark are the same tokens with different values, written by JS on toggle and persisted to `localStorage["knowra-theme"]`. Violet is the default.

The landing page handoff README documents the full token table; the app screens use the same names plus status colours (`--k-ok`, `--k-warn`, `--k-bad` and their `-bg` pairs) and two density tokens (`--k-pad`, `--k-row`).

## Responsive

One implementation each, no separate mobile files.

Landing page breaks at 1024 / 760 / 480. App screens break at 1100 / 900 / 760 / 480 — the sidebar becomes an off-canvas drawer below 900, chat collapses to a single pane with the conversation list as a slide-over, and every table swaps to stacked cards below 760.

## Placeholder content to replace

- Landing page stat strip: 14 documents / 312 pages / 40s / 4 roles.
- Landing page video: four empty players marked "drop clip here".
- App screens: all analytics figures and charts are plausible sample data, not real telemetry. The document corpus is 33 files derived from one array, so all counts agree.
- Contractor spend figures in the landing page role demo ($412,800) are illustrative.

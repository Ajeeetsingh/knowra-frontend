// Knowra — "One layer" trailer. 90s. Every frame is a pure function of T.
// Palette and type come from the Nocturne tokens; the six industry hues are
// the accent hue rotated in OKLCH at the accent's own lightness/chroma, so
// each one carries the same perceptual weight as the accent itself.

const P = {
  bg: '#161826',
  surface: '#1d2032',
  surface2: '#232639',
  text: '#e9e9ed',
  dim: 'rgba(233,233,237,0.58)',
  faint: '#8b8d9c',
  line: 'rgba(233,233,237,0.13)',
  accent: '#9184d9',
};
const FONT = "'Inter', system-ui, -apple-system, sans-serif";
const HU = (h, a) => 'oklch(0.72 0.15 ' + h + (a == null ? '' : ' / ' + a) + ')';
const px = (n) => n + 'px';

const MOTION = {
  enter: Easing.easeOutQuart,
  draw: Easing.easeInOutCubic,
  pop: Easing.easeOutBack,
};
const inOut = (T, a, b, rise, fall) => {
  const up = animate({ from: 0, to: 1, start: a, end: a + rise, ease: MOTION.enter })(T);
  const dn = animate({ from: 1, to: 0, start: b - fall, end: b, ease: MOTION.draw })(T);
  return Math.min(up, dn);
};

const PANEL_LEAD = 0.3; // industry panels (and the hue that follows them) start this early

const INDUSTRIES = [
  { name: 'Healthcare', hue: 172, holds: 'Protocols · formularies · care pathways',
    ask: 'What is the current sepsis escalation protocol?' },
  { name: 'Finance', hue: 250, holds: 'Treasury reports · controls · filings',
    ask: 'What does Q3 say about our liquidity cover?' },
  { name: 'Education', hue: 62, holds: 'Handbooks · accreditation · curricula',
    ask: 'Which courses meet the new accreditation rule?' },
  { name: 'Logistics', hue: 28, holds: 'Carrier contracts · SOPs · customs rules',
    ask: 'What is the penalty clause on late Rotterdam freight?' },
  { name: 'IT / Engineering', hue: 285, holds: 'Runbooks · RFCs · incident reports',
    ask: 'How do we roll back a failed schema migration?' },
  { name: 'Manufacturing', hue: 330, holds: 'Work instructions · QA specs · safety',
    ask: 'Which torque spec applies to the revised housing?' },
];

function rng(seed) { let s = seed; return () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; }; }
const R = rng(20260909);
const DOCS = Array.from({ length: 190 }, () => {
  const w = 7 + R() * 30;
  return {
    x: R() * 1920, y: 60 + R() * 960, w, h: Math.max(3, w * 0.4),
    hu: INDUSTRIES[Math.floor(R() * 6)].hue, ph: R() * 6.283,
    tx: 250 + R() * 1420, row: Math.floor(R() * 4), jit: R() * 12, sp: 0.6 + R() * 0.8,
  };
});
const FILES = [
  { n: 'Employee_Handbook_v7', e: 'pdf' }, { n: 'Q3_Treasury_Review', e: 'xlsx' },
  { n: 'Sepsis_Pathway_RevC', e: 'docx' }, { n: 'Carrier_Master_Agreement', e: 'pdf' },
  { n: 'Incident_2471_Postmortem', e: 'md' }, { n: 'QA_Spec_Housing_RevC', e: 'pdf' },
].map((f, i) => ({ ...f, x: 190 + (i % 3) * 560, y: 250 + Math.floor(i / 3) * 420, hue: INDUSTRIES[i].hue }));

// ── shared type ────────────────────────────────────────────────────────────
function Statement({ text, sub, T, from, to, hue, top }) {
  const o = inOut(T, from, to, 1.0, 0.6);
  const y = animate({ from: 26, to: 0, start: from, end: from + 1.1, ease: MOTION.enter })(T);
  return (
    <div style={{ position: 'absolute', left: 250, top: top == null ? 470 : top, width: 1420, opacity: o, transform: 'translateY(' + px(y) + ')' }}>
      <div style={{ font: '600 76px ' + FONT, letterSpacing: '-0.025em', lineHeight: 1.08, color: P.text, textWrap: 'balance' }}>{text}</div>
      {sub ? <div style={{ marginTop: 22, font: '400 30px ' + FONT, letterSpacing: '0.01em', color: hue ? HU(hue) : P.dim }}>{sub}</div> : null}
    </div>
  );
}

// ── the data field ─────────────────────────────────────────────────────────
function Field({ T, C, hue }) {
  const settle = animate({ from: 0, to: 1, start: C.Layer + 0.2, end: C.Layer + 3.4, ease: MOTION.draw })(T);
  const push = animate({ from: 0, to: 1, start: C.Scatter, end: C.Scatter + 3.6, ease: MOTION.draw })(T);
  const fade = animate({ from: 1, to: 0, start: C.Industries - 1.2, end: C.Industries + 0.4, ease: MOTION.draw })(T);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: fade }}>
      {DOCS.map((d, i) => {
        const born = 0.2 + (d.ph / 6.283) * 2.0;
        const o = animate({ from: 0, to: 0.55, start: born, end: born + 1.4, ease: MOTION.enter })(T);
        const drift = Math.sin(T * 0.35 * d.sp + d.ph) * 9;
        const sx = d.x + (d.x - 960) * 0.34 * push + drift;
        const sy = d.y + (d.y - 540) * 0.34 * push + Math.cos(T * 0.3 * d.sp + d.ph) * 7;
        const ty = 322 + d.row * 46 + d.jit;
        const x = sx + (d.tx - sx) * settle;
        const y = sy + (ty - sy) * settle;
        const op = o * (1 - settle * 0.15) + settle * 0.28;
        return <div key={i} style={{
          position: 'absolute', left: 0, top: 0, width: px(d.w), height: px(d.h), borderRadius: 2,
          transform: 'translate(' + px(x) + ',' + px(y) + ')',
          background: HU(settle > 0.5 ? hue : d.hu, Math.min(0.85, op)),
        }} />;
      })}
      <Shot from={C.Scatter + 0.4} to={C.Layer + 1.6}>
        {FILES.map((f, i) => {
          const a = C.Scatter + 0.5 + i * 0.22;
          const o = inOut(T, a, C.Layer + 1.4, 0.7, 0.9);
          const s = animate({ from: 0.86, to: 1, start: a, end: a + 0.8, ease: MOTION.pop })(T);
          const dx = Math.sin(T * 0.4 + i) * 14 + (f.x - 960) * 0.18 * push;
          const dy = Math.cos(T * 0.33 + i) * 10 + (f.y - 540) * 0.18 * push;
          return (
            <div key={i} style={{
              position: 'absolute', left: px(f.x + dx), top: px(f.y + dy), opacity: o,
              transform: 'scale(' + s + ')', display: 'flex', alignItems: 'center', gap: 12,
              padding: '12px 18px', borderRadius: 8, background: P.surface,
              border: '1px solid ' + HU(f.hue, 0.35), boxShadow: '0 18px 40px rgba(0,0,0,0.45)',
            }}>
              <div style={{ width: 8, height: 8, borderRadius: 2, background: HU(f.hue) }} />
              <div style={{ font: '500 22px ' + FONT, color: P.text, letterSpacing: '-0.01em' }}>{f.n}</div>
              <div style={{ font: '500 24px ' + FONT, color: P.faint, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{f.e}</div>
            </div>
          );
        })}
      </Shot>
    </div>
  );
}

// ── the layer ──────────────────────────────────────────────────────────────
function Layer({ T, C, hue }) {
  const draw = animate({ from: 0, to: 1, start: C.Layer + 1.4, end: C.Layer + 3.6, ease: MOTION.draw })(T);
  const seat = animate({ from: 40, to: 0, start: C.Plug, end: C.Plug + 1.2, ease: MOTION.pop })(T);
  const lit = animate({ from: 0.25, to: 1, start: C.Plug + 0.6, end: C.Plug + 2.2, ease: MOTION.enter })(T);
  const out = animate({ from: 1, to: 0, start: C.Glimpse - 0.8, end: C.Glimpse, ease: MOTION.draw })(T);
  const w = 1420 * draw;
  return (
    <div style={{ position: 'absolute', left: 250, top: 660, opacity: out, transform: 'translateY(' + px(seat) + ')' }}>
      <div style={{
        width: px(w), height: 12, borderRadius: 6,
        background: 'linear-gradient(90deg,' + HU(hue, 0.35) + ',' + HU(hue) + ' 50%,' + HU(hue, 0.35) + ')',
        boxShadow: '0 0 ' + px(30 + 70 * lit) + ' ' + HU(hue, 0.16 + 0.3 * lit),
      }} />
      <div style={{
        width: px(w), height: 92, marginTop: 2, borderRadius: '0 0 10px 10px',
        background: 'linear-gradient(180deg,' + HU(hue, 0.12 * lit) + ', rgba(0,0,0,0))',
      }} />
    </div>
  );
}

function Connectors({ T, C, hue }) {
  return (
    <Shot from={C.Plug - 0.2} to={C.Industries + 0.6}>
      {Array.from({ length: 26 }).map((_, i) => {
        const x = 300 + i * 52;
        const a = C.Plug + 0.3 + (i % 7) * 0.09 + Math.floor(i / 7) * 0.16;
        const h = animate({ from: 0, to: 190, start: a, end: a + 0.7, ease: MOTION.enter })(T);
        const o = inOut(T, a, C.Industries + 0.4, 0.5, 1.0) * (0.3 + 0.35 * (0.5 + 0.5 * Math.sin(T * 2 + i)));
        return <div key={i} style={{
          position: 'absolute', left: px(x), top: px(660 - h), width: 1, height: px(h), opacity: o,
          background: 'linear-gradient(180deg, rgba(0,0,0,0),' + HU(hue) + ')',
        }} />;
      })}
    </Shot>
  );
}

// ── the question ───────────────────────────────────────────────────────────
function AskBar({ T, C, hue }) {
  const q = 'How much parental leave do I get after 3 years?';
  const o = inOut(T, C.Ask + 0.2, C.Industries + 0.5, 0.8, 0.7);
  const p = clamp((T - (C.Ask + 0.6)) / 2.4, 0, 1);
  const n = Math.floor(p * q.length);
  const caret = T % 0.9 < 0.5 ? 1 : 0.15;
  const pulse = clamp((T - (C.Ask + 3.6)) / 1.6, 0, 1);
  return (
    <div style={{ position: 'absolute', left: 250, top: 300, opacity: o }}>
      <div style={{
        width: 1080, padding: '26px 32px', borderRadius: 12, background: P.surface,
        border: '1px solid ' + HU(hue, 0.4), boxShadow: '0 30px 70px rgba(0,0,0,0.5)',
        font: '400 38px ' + FONT, color: P.text, letterSpacing: '-0.015em',
      }}>
        {q.slice(0, n)}<span style={{ opacity: n < q.length ? caret : 0, color: HU(hue) }}>|</span>
        <span style={{ visibility: 'hidden' }}>{q.slice(n)}</span>
      </div>
      {pulse > 0 && pulse < 1 ? <div style={{
        position: 'absolute', left: 60, top: px(110 + 240 * pulse), width: 10, height: 10, borderRadius: 5,
        background: HU(hue), boxShadow: '0 0 24px ' + HU(hue), opacity: 1 - pulse * 0.4,
      }} /> : null}
    </div>
  );
}

// ── industries ─────────────────────────────────────────────────────────────
function Industry({ T, C, d, i, mono }) {
  const a = C.Industries + i * 3;
  const b = a + 3;
  const o = inOut(T, a - PANEL_LEAD, b - PANEL_LEAD, 0.3, 0.3);
  const x = animate({ from: 70, to: 0, start: a, end: a + 0.9, ease: MOTION.enter })(T)
    + animate({ from: 0, to: -60, start: b - 0.5, end: b, ease: MOTION.draw })(T);
  const hue = mono ? 285 : d.hue;
  const bar = animate({ from: 0, to: 1, start: a + 0.15, end: a + 1.1, ease: MOTION.draw })(T);
  return (
    <div style={{ position: 'absolute', left: 250, top: 200, width: 1500, opacity: o, transform: 'translateX(' + px(x) + ')' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 20, marginBottom: 26 }}>
        <div style={{ width: px(56 * bar), height: 3, background: HU(hue), borderRadius: 2 }} />
        <div style={{ font: '500 20px ' + FONT, letterSpacing: '0.22em', textTransform: 'uppercase', color: HU(hue) }}>
          {'0' + (i + 1)} / 06
        </div>
      </div>
      <div style={{ font: '600 112px ' + FONT, letterSpacing: '-0.035em', lineHeight: 1, color: P.text }}>{d.name}</div>
      <div style={{ marginTop: 26, font: '400 26px ' + FONT, letterSpacing: '0.14em', textTransform: 'uppercase', color: P.dim }}>{d.holds}</div>
      <div style={{
        marginTop: 54, display: 'inline-block', padding: '20px 30px', borderRadius: 10,
        background: HU(hue, 0.09), border: '1px solid ' + HU(hue, 0.42),
        font: '400 36px ' + FONT, color: P.text, letterSpacing: '-0.015em',
      }}>{d.ask}</div>
    </div>
  );
}

// ── grounded answer ────────────────────────────────────────────────────────
function Grounded({ T, C, hue }) {
  const o = inOut(T, C.Grounded + 0.2, C.Boundaries + 0.2, 0.7, 0.6);
  const c1 = 'Revision C calls for 42 Nm ±2, on dry threads.';
  const c2 = 'Lubricated threads drop to 34 Nm.';
  const t1 = clamp((T - (C.Grounded + 0.8)) / 1.5, 0, 1);
  const t2 = clamp((T - (C.Grounded + 2.4)) / 1.2, 0, 1);
  const chip = animate({ from: 0, to: 1, start: C.Grounded + 3.5, end: C.Grounded + 4.1, ease: MOTION.pop })(T);
  const card = animate({ from: 0, to: 1, start: C.Grounded + 4.4, end: C.Grounded + 5.4, ease: MOTION.enter })(T);
  const type = (s, p) => <span>{s.slice(0, Math.floor(p * s.length))}<span style={{ visibility: 'hidden' }}>{s.slice(Math.floor(p * s.length))}</span></span>;
  return (
    <div style={{ position: 'absolute', left: 250, top: 160, width: 1440, opacity: o }}>
      <div style={{ font: '400 26px ' + FONT, letterSpacing: '0.14em', textTransform: 'uppercase', color: P.dim }}>
        Every answer carries its evidence
      </div>
      <div style={{ marginTop: 44, font: '500 54px ' + FONT, lineHeight: 1.28, letterSpacing: '-0.02em', color: P.text }}>
        {type(c1, t1)}{' '}{type(c2, t2)}
        <span style={{
          display: 'inline-block', marginLeft: 14, transform: 'scale(' + chip + ')',
          padding: '4px 14px', borderRadius: 6, background: HU(hue, 0.16),
          border: '1px solid ' + HU(hue, 0.5), font: '500 30px ' + FONT, color: HU(hue),
          verticalAlign: 'middle',
        }}>1</span>
      </div>
      <div style={{
        marginTop: 48, width: 1080, opacity: card, transform: 'translateY(' + px(24 - 24 * card) + ')',
        padding: '28px 32px', borderRadius: 12, background: P.surface, border: '1px solid ' + P.line,
        boxShadow: '0 30px 70px rgba(0,0,0,0.5)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, font: '500 22px ' + FONT, color: HU(hue), letterSpacing: '0.04em' }}>
          <span>QA_Spec_Housing_RevC.pdf</span><span style={{ color: P.faint }}>page 12</span>
        </div>
        <div style={{ marginTop: 18, font: '400 28px ' + FONT, lineHeight: 1.5, color: P.dim }}>
          “Fasteners shall be torqued to <span style={{ color: P.text, background: HU(hue, 0.2), padding: '2px 6px', borderRadius: 4 }}>42 Nm ±2</span> with threads dry; lubricated threads require 34 Nm.”
        </div>
      </div>
    </div>
  );
}

// ── access boundary ────────────────────────────────────────────────────────
function Boundaries({ T, C, mono }) {
  const o = inOut(T, C.Boundaries + 0.3, C.Glimpse - 0.3, 0.7, 0.7);
  const cols = [
    { role: 'Finance', hue: mono ? 285 : 250, src: ['Q3_Treasury_Review.xlsx', 'Liquidity_Controls.pdf', 'Board_Pack_Q3.pdf'], held: 0 },
    { role: 'Employee', hue: mono ? 285 : 172, src: ['Employee_Handbook_v7.pdf'], held: 2 },
  ];
  return (
    <div style={{ position: 'absolute', left: 250, top: 155, width: 1440, opacity: o }}>
      <div style={{ font: '400 26px ' + FONT, letterSpacing: '0.14em', textTransform: 'uppercase', color: P.dim }}>
        And only the evidence you are cleared to see
      </div>
      <div style={{ marginTop: 34, font: '500 46px ' + FONT, letterSpacing: '-0.02em', color: P.text }}>
        “What does Q3 say about our liquidity cover?”
      </div>
      <div style={{ marginTop: 56, display: 'flex', gap: 40 }}>
        {cols.map((c, i) => {
          const a = C.Boundaries + 1.4 + i * 0.5;
          const y = animate({ from: 40, to: 0, start: a, end: a + 0.9, ease: MOTION.enter })(T);
          const op = animate({ from: 0, to: 1, start: a, end: a + 0.8, ease: MOTION.enter })(T);
          return (
            <div key={i} style={{
              flex: 1, opacity: op, transform: 'translateY(' + px(y) + ')',
              padding: 30, borderRadius: 12, background: P.surface,
              border: '1px solid ' + HU(c.hue, 0.3),
            }}>
              <div style={{ font: '500 22px ' + FONT, letterSpacing: '0.18em', textTransform: 'uppercase', color: HU(c.hue) }}>{c.role}</div>
              <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 12 }}>
                {c.src.map((s, j) => (
                  <div key={j} style={{
                    display: 'flex', alignItems: 'center', gap: 12, padding: '12px 16px', borderRadius: 8,
                    background: HU(c.hue, 0.1), font: '400 24px ' + FONT, color: P.text,
                  }}>
                    <div style={{ width: 6, height: 6, borderRadius: 3, background: HU(c.hue) }} />{s}
                  </div>
                ))}
                {c.held ? (
                  <div style={{ padding: '12px 16px', borderRadius: 8, border: '1px dashed ' + P.line, font: '400 24px ' + FONT, color: P.faint }}>
                    {c.held} sources withheld
                  </div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ── the product, for three seconds ─────────────────────────────────────────
function Glimpse({ T, C, hue }) {
  const o = inOut(T, C.Glimpse + 0.3, C.Glimpse + 3.9, 0.5, 0.6);
  const s = animate({ from: 0.95, to: 1, start: C.Glimpse + 0.3, end: C.Glimpse + 1.6, ease: MOTION.enter })(T);
  const line = (w, c, h) => <div style={{ width: px(w), height: px(h || 10), borderRadius: 5, background: c }} />;
  return (
    <div style={{
      position: 'absolute', left: 410, top: 230, width: 1100, opacity: o,
      transform: 'scale(' + s + ')', transformOrigin: '550px 310px',
      borderRadius: 14, overflow: 'hidden', background: P.surface,
      border: '1px solid ' + P.line, boxShadow: '0 50px 120px rgba(0,0,0,0.6)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '16px 22px', borderBottom: '1px solid ' + P.line }}>
        <div style={{ width: 22, height: 22, borderRadius: 6, background: HU(hue) }} />
        <div style={{ font: '600 20px ' + FONT, letterSpacing: '-0.01em', color: P.text }}>Knowra</div>
      </div>
      <div style={{ display: 'flex', height: 560 }}>
        <div style={{ width: 250, padding: 22, borderRight: '1px solid ' + P.line, display: 'flex', flexDirection: 'column', gap: 16 }}>
          {[0, 1, 2, 3, 4].map((i) => line(i === 1 ? 150 : 110 + i * 14, i === 1 ? HU(hue, 0.6) : P.line))}
        </div>
        <div style={{ flex: 1, padding: 34, display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div style={{ alignSelf: 'flex-end', padding: '16px 22px', borderRadius: 10, background: HU(hue, 0.14), font: '400 24px ' + FONT, color: P.text }}>
            Which torque spec applies to the revised housing?
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {line(700, P.surface2, 14)}{line(620, P.surface2, 14)}{line(480, P.surface2, 14)}
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            {[1, 2].map((n) => (
              <div key={n} style={{ padding: '6px 14px', borderRadius: 6, background: HU(hue, 0.16), border: '1px solid ' + HU(hue, 0.45), font: '500 20px ' + FONT, color: HU(hue) }}>{n}</div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── scale ──────────────────────────────────────────────────────────────────
function ScaleField({ T, C, mono }) {
  const o = inOut(T, C.Scale + 0.2, C.Poster + 0.4, 0.9, 0.7);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      {Array.from({ length: 28 }).map((_, i) => {
        const row = Math.floor(i / 7), col = i % 7;
        const a = C.Scale + 0.3 + row * 0.22 + col * 0.06;
        const op = animate({ from: 0, to: 1, start: a, end: a + 0.8, ease: MOTION.enter })(T);
        const sc = animate({ from: 0.7, to: 1, start: a, end: a + 1.0, ease: MOTION.pop })(T);
        const hue = mono ? 285 : INDUSTRIES[(i * 5) % 6].hue;
        const depth = 1 - row * 0.13;
        return <div key={i} style={{
          position: 'absolute', left: px(210 + col * 220 + row * 26), top: px(700 + row * 82),
          width: px(190 * depth), height: 7, borderRadius: 4, opacity: op * depth,
          transform: 'scaleX(' + sc + ')',
          background: HU(hue), boxShadow: '0 0 26px ' + HU(hue, 0.35),
        }} />;
      })}
    </div>
  );
}

// ── poster + close ─────────────────────────────────────────────────────────
const SPECTRUM = 'linear-gradient(90deg,' + INDUSTRIES.map((d) => HU(d.hue)).join(',') + ')';

function Poster({ T, C, mono }) {
  const o = inOut(T, C.Poster + 0.2, 999, 1.0, 0.5);
  const ls = animate({ from: 0.42, to: 0.06, start: C.Poster + 0.2, end: C.Poster + 2.6, ease: MOTION.draw })(T);
  const rule = animate({ from: 0, to: 1, start: C.Poster + 1.4, end: C.Poster + 3.4, ease: MOTION.draw })(T);
  const lift = animate({ from: 0, to: -178, start: C.Close, end: C.Close + 1.6, ease: MOTION.draw })(T);
  const scale = animate({ from: 1, to: 0.6, start: C.Close, end: C.Close + 1.6, ease: MOTION.draw })(T);
  return (
    <div style={{ position: 'absolute', left: 250, top: 430, opacity: o, transform: 'translateY(' + px(lift) + ')' }}>
      <div style={{
        font: '600 ' + px(176 * scale) + ' ' + FONT, letterSpacing: ls + 'em', color: P.text,
        lineHeight: 1, transformOrigin: '0 50%',
      }}>KNOWRA</div>
      <div style={{
        marginTop: px(34 * scale), width: px(1000 * rule), height: 4, borderRadius: 2,
        background: mono ? P.accent : SPECTRUM,
      }} />
    </div>
  );
}

function Close({ T, C }) {
  const o = inOut(T, C.Close + 1.2, 999, 1.1, 0.5);
  const y = animate({ from: 24, to: 0, start: C.Close + 1.2, end: C.Close + 2.4, ease: MOTION.enter })(T);
  const o2 = animate({ from: 0, to: 1, start: C.Close + 2.6, end: C.Close + 3.8, ease: MOTION.enter })(T);
  return (
    <div style={{ position: 'absolute', left: 250, top: 470, width: 1420, opacity: o, transform: 'translateY(' + px(y) + ')' }}>
      <div style={{ font: '500 88px ' + FONT, letterSpacing: '-0.03em', lineHeight: 1.1, color: P.text }}>
        Ask your organization anything.
      </div>
      <div style={{ marginTop: 30, font: '400 34px ' + FONT, lineHeight: 1.4, color: P.dim, opacity: o2 }}>
        Feed Knowra your documents. Every answer comes back with its source —<br />and never crosses a permission you did not grant.
      </div>
    </div>
  );
}

// ── the film ───────────────────────────────────────────────────────────────
function Trailer({ mono }) {
  const { T, CUES: C } = useComposition();

  let hue = 285;
  if (T >= C.Industries - PANEL_LEAD && T < C.Grounded) {
    const t = T - C.Industries + PANEL_LEAD;
    const i = clamp(Math.floor(t / 3), 0, 5);
    const prev = i === 0 ? 285 : INDUSTRIES[i - 1].hue;
    const b = clamp((t - i * 3) / 0.3, 0, 1);
    hue = prev + (INDUSTRIES[i].hue - prev) * b;
  } else if (T >= C.Grounded) {
    hue = interpolate([C.Grounded, C.Grounded + 2.2], [330, 285], MOTION.draw)(T);
  }
  if (mono) hue = 285;

  const vig = 0.12 + 0.1 * (T >= C.Industries && T < C.Grounded ? 1 : 0);

  return (
    <div style={{ position: 'absolute', inset: 0, background: P.bg, overflow: 'hidden', fontFamily: FONT }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(1200px 800px at 22% 62%, ' + HU(hue, vig) + ', rgba(0,0,0,0) 70%)',
      }} />

      <Shot from={0} to={C.Industries + 0.8}><Field T={T} C={C} hue={hue} /></Shot>
      <Shot from={C.Layer} to={C.Glimpse}><Layer T={T} C={C} hue={hue} /></Shot>
      <Connectors T={T} C={C} hue={hue} />
      <Shot from={C.Ask} to={C.Industries + 0.8}><AskBar T={T} C={C} hue={hue} /></Shot>

      <Shot from={0} to={C.Layer}>
        <Statement T={T} C={C} from={1.7} to={C.Scatter + 0.5} text="Your organization already knows the answer." />
        <Statement T={T} C={C} from={C.Scatter + 1.3} to={C.Layer} text="It just cannot be asked." sub="Thousands of files. Six formats. Forty folders deep." />
      </Shot>
      <Shot from={C.Layer} to={C.Industries}>
        <Statement top={840} T={T} C={C} from={C.Layer + 1.6} to={C.Plug + 0.7} text="Knowra is one layer." />
        <Statement top={840} T={T} C={C} from={C.Plug + 0.9} to={C.Ask + 0.7} text="Plug it in. Feed it your data." />
        <Statement top={840} T={T} C={C} from={C.Ask + 1.1} to={C.Industries} text="Then ask, in your own words." />
      </Shot>

      <Shot from={C.Industries - 0.3} to={C.Grounded + 0.3}>
        {INDUSTRIES.map((d, i) => <Industry key={i} T={T} C={C} d={d} i={i} mono={mono} />)}
      </Shot>

      <Shot from={C.Grounded} to={C.Boundaries + 0.5}><Grounded T={T} C={C} hue={hue} /></Shot>
      <Shot from={C.Boundaries} to={C.Glimpse}><Boundaries T={T} C={C} mono={mono} /></Shot>
      <Shot from={C.Glimpse} to={C.Scale + 0.5}><Glimpse T={T} C={C} hue={hue} /></Shot>
      <Shot from={C.Scale} to={C.Poster + 0.8}>
        <ScaleField T={T} C={C} mono={mono} />
        <Statement T={T} C={C} from={C.Scale + 0.8} to={C.Poster + 0.4} text="Any industry that runs on documents." sub="Healthcare · Finance · Education · Logistics · IT · Manufacturing" />
      </Shot>
      <Shot from={C.Poster} to={999}><Poster T={T} C={C} mono={mono} /></Shot>
      <Shot from={C.Close} to={999}><Close T={T} C={C} /></Shot>
    </div>
  );
}

function KnowraTrailer() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS || { spectrum: true, motionEditor: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} bg={P.bg}
        scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Trailer mono={!tw.spectrum} />
      </CompositionStage>
      <window.TweaksPanel title="Trailer">
        <window.TweakSection label="Look">
          <window.TweakToggle label="Industry spectrum" value={tw.spectrum} onChange={(v) => setTweak('spectrum', v)} />
          <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

window.KnowraTrailer = KnowraTrailer;

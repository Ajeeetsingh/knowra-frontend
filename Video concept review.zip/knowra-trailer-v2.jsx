// Knowra trailer v2 — "It becomes what your data is". 94s.
// Act I  (0–30)  three real, sourced industry problems, told as data graphics
// Act II (30–46) convergence and the reveal: retrieval + a reasoning model
// Act III(46–66) fast-forward: feed it, ask it, and the permission boundary
// Act IV (66–94) what it becomes per industry, then the poster and the close
// Everything renders from T. No local clocks, no CSS transitions.

const P = {
  bg: '#12141f',
  ground: '#161826',
  surface: '#1d2032',
  surface2: '#252940',
  text: '#e9e9ed',
  dim: '#a5a7b6',
  mid: '#8b8d9c',
  line: 'rgba(233,233,237,0.13)',
  accent: '#9184d9',
};
const DISP = "'Archivo', system-ui, sans-serif";
const BODY = "'Archivo', system-ui, sans-serif";
const MONO = "'Chivo Mono', ui-monospace, monospace";
const HU = (h, a) => 'oklch(0.74 0.15 ' + h + (a == null ? '' : ' / ' + a) + ')';
const px = (n) => n + 'px';
const wdth = (w) => "'wdth' " + w;

const MOTION = {
  enter: Easing.easeOutQuart,
  draw: Easing.easeInOutCubic,
  pop: Easing.easeOutBack,
};
const inOut = (T, a, b, rise, fall) => Math.min(
  animate({ from: 0, to: 1, start: a, end: a + rise, ease: MOTION.enter })(T),
  animate({ from: 1, to: 0, start: b - fall, end: b, ease: MOTION.draw })(T)
);
const ramp = (T, a, b, ease) => animate({ from: 0, to: 1, start: a, end: b, ease: ease || MOTION.draw })(T);
const HUES = { health: 172, fin: 250, edu: 62, log: 28, it: 285, mfg: 330 };
const SPECTRUM = 'linear-gradient(90deg,' + [HUES.health, HUES.fin, HUES.edu, HUES.log, HUES.it, HUES.mfg].map((h) => HU(h)).join(',') + ')';

// ── the repeating frame for the three problem beats ───────────────────────
function Kicker({ n, label, hue, T, from }) {
  const w = ramp(T, from, from + 0.7);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
      <div style={{ width: px(48 * w), height: 3, background: HU(hue), borderRadius: 2 }} />
      <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.24em', color: HU(hue) }}>{n}  {label}</div>
    </div>
  );
}

function Fact({ T, from, to, hue, n, label, figure, unit, claim, source, children }) {
  const o = inOut(T, from, to, 0.7, 0.5);
  const y = animate({ from: 22, to: 0, start: from, end: from + 1.0, ease: MOTION.enter })(T);
  const fo = ramp(T, from + 0.35, from + 1.1, MOTION.enter);
  const co = ramp(T, from + 1.2, from + 2.0, MOTION.enter);
  const so = ramp(T, from + 2.4, from + 3.2, MOTION.enter);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 150, top: 150, width: 850, transform: 'translateY(' + px(y) + ')' }}>
        <Kicker n={n} label={label} hue={hue} T={T} from={from} />
        <div style={{ marginTop: 62, display: 'flex', alignItems: 'baseline', gap: 16, opacity: fo }}>
          <div style={{ font: '300 168px ' + MONO, letterSpacing: '-0.05em', lineHeight: 0.86, color: P.text }}>{figure}</div>
          <div style={{ font: '400 34px ' + BODY, color: HU(hue) }}>{unit}</div>
        </div>
        <div style={{
          marginTop: 42, font: '500 46px ' + DISP, fontVariationSettings: wdth(90),
          letterSpacing: '-0.015em', lineHeight: 1.2, color: P.text, opacity: co, textWrap: 'pretty',
        }}>{claim}</div>
        <div style={{ marginTop: 40, font: '400 24px ' + MONO, letterSpacing: '0.03em', lineHeight: 1.45, color: P.dim, opacity: so }}>
          SOURCE: {source}
        </div>
      </div>
      <div style={{ position: 'absolute', left: 1055, top: 220, width: 800 }}>{children}</div>
    </div>
  );
}

// ── 01 healthcare: one shift, ticked out ──────────────────────────────────
function ShiftTrack({ T, C }) {
  const a = C.Ward + 0.8;
  const rev = ramp(T, a, a + 1.6);
  const lit = ramp(T, a + 1.6, a + 3.6);
  const N = 72;
  const docIdx = [];
  for (let c = 0; c < 6; c++) for (let k = 0; k < 5; k++) docIdx.push(c * 12 + k);
  return (
    <div>
      <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.18em', color: P.dim }}>ONE 12-HOUR SHIFT</div>
      <div style={{ marginTop: 30, display: 'flex', gap: 4, alignItems: 'flex-end', height: 190 }}>
        {Array.from({ length: N }).map((_, i) => {
          const on = i / N <= rev;
          const isDoc = docIdx.indexOf(i) >= 0;
          const l = isDoc ? lit : 0;
          return <div key={i} style={{
            width: 6, height: px(on ? (isDoc ? 118 + 60 * l : 118) : 0), borderRadius: 3,
            background: isDoc ? HU(HUES.health, 0.28 + 0.72 * l) : 'rgba(233,233,237,0.30)',
            boxShadow: isDoc && l > 0.5 ? '0 0 14px ' + HU(HUES.health, 0.4) : 'none',
          }} />;
        })}
      </div>
      <div style={{ marginTop: 34, display: 'flex', gap: 40, opacity: lit }}>
        {[['documentation', HU(HUES.health)], ['at the bedside', 'rgba(233,233,237,0.30)']].map((k, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 14, height: 14, borderRadius: 3, background: k[1] }} />
            <div style={{ font: '400 22px ' + BODY, color: P.dim }}>{k[0]}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── 02 finance: compliance as a share of payroll ──────────────────────────
function PayrollBars({ T, C }) {
  const rows = [
    { k: 'SMALLEST BANKS', lo: 11, hi: 15.5, a: 0.9 },
    { k: 'LARGEST BANKS', lo: 6, hi: 10, a: 1.5 },
  ];
  const TRACK = 600, LABEL = 170;
  const scale = TRACK / 20;
  return (
    <div>
      <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.16em', color: P.dim }}>SHARE OF PAYROLL SPENT ON COMPLIANCE</div>
      <div style={{ marginTop: 44, display: 'flex', flexDirection: 'column', gap: 46 }}>
        {rows.map((r, i) => {
          const g = ramp(T, C.Ledger + r.a, C.Ledger + r.a + 1.7);
          const o = ramp(T, C.Ledger + r.a, C.Ledger + r.a + 0.6, MOTION.enter);
          return (
            <div key={i} style={{ opacity: o }}>
              <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.14em', color: P.dim }}>{r.k}</div>
              <div style={{ marginTop: 16, position: 'relative', height: 44 }}>
                <div style={{ position: 'absolute', left: 0, top: 0, width: px(TRACK), height: 44, borderRadius: 4, background: 'rgba(233,233,237,0.05)' }} />
                <div style={{
                  position: 'absolute', left: px(r.lo * scale * g), top: 0,
                  width: px((r.hi - r.lo) * scale * g), height: 44, borderRadius: 4,
                  background: HU(HUES.fin, 0.3), border: '1px solid ' + HU(HUES.fin, 0.55),
                }} />
                <div style={{ position: 'absolute', left: 0, top: 0, width: px(r.lo * scale * g), height: 44, borderRadius: '4px 0 0 4px', background: HU(HUES.fin) }} />
                <div style={{
                  position: 'absolute', left: px(TRACK + 24), top: 4, width: px(LABEL), opacity: g,
                  font: '400 30px ' + MONO, color: P.text, whiteSpace: 'nowrap',
                }}>{r.lo}–{r.hi}%</div>
              </div>
            </div>
          );
        })}
      </div>
      <div style={{ marginTop: 40, display: 'flex', gap: 0, opacity: ramp(T, C.Ledger + 3.4, C.Ledger + 4.0, MOTION.enter) }}>
        {[0, 5, 10, 15, 20].map((v) => (
          <div key={v} style={{ width: px(5 * scale), font: '400 24px ' + MONO, color: P.dim, borderLeft: '1px solid ' + P.line, paddingLeft: 10 }}>{v}%</div>
        ))}
      </div>
    </div>
  );
}

// ── 03 manufacturing: the line stops ──────────────────────────────────────
function StoppedLine({ T, C }) {
  const stop = C.Line + 2.4;
  const dead = ramp(T, stop, stop + 0.5, MOTION.enter);
  const hours = Math.round(interpolate([stop + 0.3, stop + 3.4], [0, 800], MOTION.draw)(T));
  const flow = ((T - C.Line) * (1 - dead) * 90) % 60;
  return (
    <div>
      <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.18em', color: P.dim }}>PRODUCTION LINE</div>
      <div style={{ marginTop: 34, position: 'relative', height: 130 }}>
        <div style={{ position: 'absolute', left: 0, top: 58, width: 720, height: 6, borderRadius: 3, background: 'rgba(233,233,237,0.09)', overflow: 'hidden' }}>
          {Array.from({ length: 13 }).map((_, i) => (
            <div key={i} style={{
              position: 'absolute', left: px(i * 60 + flow - 60), top: 0, width: 26, height: 6, borderRadius: 3,
              background: HU(HUES.mfg, 0.75 * (1 - dead)),
            }} />
          ))}
        </div>
        {Array.from({ length: 8 }).map((_, i) => {
          const on = ramp(T, C.Line + 0.6 + i * 0.09, C.Line + 1.1 + i * 0.09, MOTION.enter);
          const isDead = i === 4;
          return <div key={i} style={{
            position: 'absolute', left: px(i * 92), top: 0, width: 66, height: 122, borderRadius: 8,
            opacity: on, background: isDead ? 'rgba(233,233,237,0.04)' : P.surface,
            border: '1px solid ' + (isDead && dead > 0.5 ? HU(HUES.mfg, 0.7) : P.line),
            boxShadow: isDead && dead > 0.5 ? '0 0 40px ' + HU(HUES.mfg, 0.3) : 'none',
          }}>
            <div style={{
              position: 'absolute', left: 14, top: 16, width: 38, height: 8, borderRadius: 4,
              background: isDead ? HU(HUES.mfg, 0.25 + 0.75 * (1 - dead)) : HU(HUES.mfg, 0.55),
            }} />
          </div>;
        })}
      </div>
      <div style={{ marginTop: 46, display: 'flex', gap: 70, opacity: ramp(T, stop + 0.3, stop + 1.0, MOTION.enter) }}>
        {[[hours.toLocaleString(), 'HOURS LOST / YEAR'], ['$1.4T', 'ACROSS THE GLOBAL 500']].map((k, i) => (
          <div key={i}>
            <div style={{ font: '300 76px ' + MONO, letterSpacing: '-0.04em', color: HU(HUES.mfg) }}>{k[0]}</div>
            <div style={{ marginTop: 12, font: '400 24px ' + MONO, letterSpacing: '0.12em', color: P.dim }}>{k[1]}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── convergence ───────────────────────────────────────────────────────────
function rng(seed) { let s = seed; return () => { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; }; }
const CR = rng(770211);
const SHARDS = Array.from({ length: 110 }, () => ({
  x: 120 + CR() * 1680, y: 140 + CR() * 800, w: 6 + CR() * 26,
  hu: [HUES.health, HUES.fin, HUES.mfg][Math.floor(CR() * 3)], d: CR() * 0.9,
}));

function Converge({ T, C }) {
  const o = inOut(T, C.Converge - 0.4, C.Reveal + 0.15, 0.5, 0.35);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      {SHARDS.map((s, i) => {
        const p = ramp(T, C.Converge + 0.2 + s.d, C.Converge + 3.0 + s.d);
        const x = s.x + (958 - s.x) * p;
        const y = s.y + (536 - s.y) * p;
        const w = s.w * (1 - p * 0.8);
        return <div key={i} style={{
          position: 'absolute', left: 0, top: 0, width: px(w), height: px(Math.max(3, w * 0.4)), borderRadius: 2,
          transform: 'translate(' + px(x) + ',' + px(y) + ')',
          background: HU(s.hu, 0.25 + 0.6 * p),
        }} />;
      })}
      <div style={{
        position: 'absolute', left: 250, top: 830, width: 1420,
        opacity: inOut(T, C.Converge + 1.0, C.Reveal + 0.2, 0.8, 0.5),
        font: '500 56px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.02em', color: P.text,
      }}>Every one of those answers was already written down.</div>
    </div>
  );
}

// ── the reveal ────────────────────────────────────────────────────────────
function Mark({ T, C, size, hue }) {
  const s = size;
  const bars = [0, 1, 2];
  return (
    <div style={{ position: 'relative', width: px(s), height: px(s) }}>
      {bars.map((i) => {
        const g = ramp(T, C.Reveal + 0.3 + i * 0.18, C.Reveal + 1.2 + i * 0.18, MOTION.pop);
        return <div key={i} style={{
          position: 'absolute', left: px(s * 0.16), top: px(s * (0.2 + i * 0.24)),
          width: px(s * (0.68 - i * 0.16) * g), height: px(s * 0.11), borderRadius: px(s * 0.055),
          background: HU(hue), boxShadow: '0 0 ' + px(s * 0.3) + ' ' + HU(hue, 0.4),
        }} />;
      })}
      <div style={{
        position: 'absolute', inset: 0, borderRadius: px(s * 0.24),
        border: '2px solid ' + HU(hue, 0.4 * ramp(T, C.Reveal + 0.1, C.Reveal + 0.9, MOTION.enter)),
      }} />
    </div>
  );
}

function Reveal({ T, C }) {
  // one continuous element: the shards' seed grows at centre, travels to the mark slot,
  // opens into the mark, and the wordmark unwraps out of its right edge
  const o = inOut(T, C.Converge + 1.2, C.What + 0.6, 1.1, 0.6);
  const t0 = C.Reveal;
  const grow = ramp(T, C.Converge + 1.4, C.Converge + 3.2, MOTION.enter);
  const mv = ramp(T, t0, t0 + 0.95, MOTION.draw);
  const S0 = 30 + 100 * grow, S1 = 150;
  const size = S0 + (S1 - S0) * mv;
  const cx = 960 + (225 - 960) * mv;
  const cy = 540 + (455 - 540) * mv;
  const rad = (10 + 20 * grow) * (1 - mv) + 36 * mv;
  const open = ramp(T, t0 + 0.85, t0 + 1.5, MOTION.draw);   // solid box → outlined frame
  const wipe = ramp(T, t0 + 1.15, t0 + 2.3, MOTION.draw);   // wordmark unwraps
  const w = interpolate([t0 + 1.15, t0 + 3.4], [70, 100], MOTION.draw)(T);
  const rule = ramp(T, t0 + 2.6, t0 + 4.4);
  const bar = (i) => ramp(T, t0 + 1.0 + i * 0.16, t0 + 1.8 + i * 0.16, MOTION.pop);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{
        position: 'absolute', left: px(cx - size / 2), top: px(cy - size / 2),
        width: px(size), height: px(size), borderRadius: px(rad),
        background: HU(HUES.it, 1 - open),
        border: '2px solid ' + HU(HUES.it, 0.25 + 0.35 * open),
        boxShadow: '0 0 ' + px(60 + 110 * grow * (1 - 0.5 * open)) + ' ' + HU(HUES.it, 0.5 - 0.2 * open),
      }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{
            position: 'absolute', left: px(size * 0.16), top: px(size * (0.2 + i * 0.24)),
            width: px(size * (0.68 - i * 0.16) * bar(i)), height: px(size * 0.11),
            borderRadius: px(size * 0.055), background: HU(HUES.it),
            boxShadow: '0 0 ' + px(size * 0.3) + ' ' + HU(HUES.it, 0.4),
          }} />
        ))}
      </div>
      <div style={{
        position: 'absolute', left: 344, top: 380, height: 150, overflow: 'hidden',
        width: px(1100 * wipe),
      }}>
        <div style={{
          font: '600 178px ' + DISP, fontVariationSettings: wdth(w), letterSpacing: '-0.04em',
          lineHeight: '150px', color: P.text, whiteSpace: 'nowrap',
        }}>Knowra</div>
      </div>
      <div style={{ position: 'absolute', left: 150, top: 576, width: px(1180 * rule), height: 4, borderRadius: 2, background: SPECTRUM }} />
    </div>
  );
}

// ── what it actually is ───────────────────────────────────────────────────
function WhatItIs({ T, C }) {
  const o = inOut(T, C.What + 0.4, C.Feed + 0.2, 0.7, 0.6);
  const cols = [
    { k: 'RETRIEVAL', h: HUES.health, t: 'It reads your documents. Every answer is pulled from them and cited back to the page.' },
    { k: 'REASONING', h: HUES.it, t: 'A language model on top, so it explains, compares and holds a conversation, not just returns search results.' },
  ];
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{
        position: 'absolute', left: 150, top: 170, width: 1300,
        font: '500 72px ' + DISP, fontVariationSettings: wdth(88), letterSpacing: '-0.03em', lineHeight: 1.06, color: P.text,
      }}>Not a search box.<br />Not a general chatbot.</div>
      <div style={{ position: 'absolute', left: 150, top: 470, display: 'flex', gap: 40 }}>
        {cols.map((c, i) => {
          const a = C.What + 1.4 + i * 0.6;
          const y = animate({ from: 36, to: 0, start: a, end: a + 0.9, ease: MOTION.enter })(T);
          const op = ramp(T, a, a + 0.8, MOTION.enter);
          return (
            <div key={i} style={{
              width: 700, padding: 40, borderRadius: 14, opacity: op, transform: 'translateY(' + px(y) + ')',
              background: P.surface, border: '1px solid ' + HU(c.h, 0.32),
            }}>
              <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.22em', color: HU(c.h) }}>{c.k}</div>
              <div style={{ marginTop: 26, font: '400 30px ' + BODY, lineHeight: 1.45, color: P.dim }}>{c.t}</div>
            </div>
          );
        })}
      </div>
      <div style={{
        position: 'absolute', left: 150, top: 810, opacity: ramp(T, C.What + 3.4, C.What + 4.4, MOTION.enter),
        font: '400 34px ' + BODY, color: P.text,
      }}>Both halves, inside your walls.</div>
    </div>
  );
}

// ── fast-forward: feed it ─────────────────────────────────────────────────
const PIPE = ['PARSE', 'CHUNK', 'EMBED', 'INDEX', 'SEARCHABLE'];
const FEEDFILES = ['Care_Pathways_RevC.pdf', 'Q3_Treasury_Review.xlsx', 'Carrier_Master_Agreement.pdf', 'Work_Instruction_4471.docx', 'Runbook_Schema_Rollback.md', 'Accreditation_Handbook.pdf'];

function Feed({ T, C }) {
  const o = inOut(T, C.Feed - 0.2, C.Ask + 0.2, 0.5, 0.5);
  const conv = ((T - C.Feed) * 620) % 340;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 150, top: 150, display: 'flex', alignItems: 'center', gap: 22 }}>
        <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.2em', color: HU(HUES.it) }}>▶▶ ×8</div>
        <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.2em', color: P.mid }}>FEED IT EVERYTHING YOU HAVE</div>
      </div>
      <div style={{ position: 'absolute', left: 0, top: 300, width: 1920, height: 92, overflow: 'hidden' }}>
        {Array.from({ length: 8 }).map((_, i) => {
          const f = FEEDFILES[i % 6];
          const x = 1920 - ((i * 340 + conv) % 2260);
          return <div key={i} style={{
            position: 'absolute', left: px(x), top: 14, display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 22px', borderRadius: 8, background: P.surface, border: '1px solid ' + P.line, whiteSpace: 'nowrap',
          }}>
            <div style={{ width: 9, height: 9, borderRadius: 2, background: HU(HUES.it) }} />
            <div style={{ font: '400 24px ' + MONO, color: P.dim }}>{f}</div>
          </div>;
        })}
      </div>
      <div style={{ position: 'absolute', left: 150, top: 500, display: 'flex', alignItems: 'center', gap: 18 }}>
        {PIPE.map((s, i) => {
          const cyc = ((T - C.Feed) * 2.2) % PIPE.length;
          const on = clamp(1 - Math.abs(cyc - i) * 1.4, 0, 1);
          return (
            <React.Fragment key={i}>
              <div style={{
                padding: '18px 28px', borderRadius: 8, font: '400 26px ' + MONO, letterSpacing: '0.1em',
                color: on > 0.4 ? P.text : P.mid,
                background: HU(HUES.it, 0.05 + 0.22 * on), border: '1px solid ' + HU(HUES.it, 0.14 + 0.5 * on),
                boxShadow: on > 0.6 ? '0 0 30px ' + HU(HUES.it, 0.25) : 'none',
              }}>{s}</div>
              {i < PIPE.length - 1 ? <div style={{ width: 26, height: 1, background: P.line }} /> : null}
            </React.Fragment>
          );
        })}
      </div>
      <div style={{
        position: 'absolute', left: 150, top: 680, width: 1500, opacity: ramp(T, C.Feed + 1.6, C.Feed + 2.6, MOTION.enter),
        font: '500 62px ' + DISP, fontVariationSettings: wdth(88), letterSpacing: '-0.025em', lineHeight: 1.12, color: P.text,
      }}>PDFs, spreadsheets, handbooks, reports.<br />Six formats, fifty megabytes a file, no schema to design.</div>
    </div>
  );
}

// ── the product, for real ─────────────────────────────────────────────────
function AskPanel({ T, C }) {
  const o = inOut(T, C.Ask + 0.1, C.Guard + 0.2, 0.5, 0.5);
  const q = 'Which torque spec applies to the revised housing?';
  const tq = clamp((T - (C.Ask + 0.5)) / 1.0, 0, 1);
  const ans = 'Revision C calls for 42 Nm ±2 on dry threads. Lubricated threads drop to 34 Nm.';
  const ta = clamp((T - (C.Ask + 1.8)) / 1.6, 0, 1);
  const chip = ramp(T, C.Ask + 3.4, C.Ask + 3.9, MOTION.pop);
  const src = ramp(T, C.Ask + 4.2, C.Ask + 5.2, MOTION.enter);
  const hl = ramp(T, C.Ask + 5.2, C.Ask + 5.9, MOTION.enter);
  const cut = (s, p) => <span>{s.slice(0, Math.floor(p * s.length))}<span style={{ visibility: 'hidden' }}>{s.slice(Math.floor(p * s.length))}</span></span>;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 150, top: 160, font: '400 24px ' + MONO, letterSpacing: '0.2em', color: HU(HUES.mfg) }}>
        ASK IT LIKE YOU WOULD ASK A COLLEAGUE
      </div>
      <div style={{
        position: 'absolute', left: 150, top: 250, width: 1000, borderRadius: 14, overflow: 'hidden',
        background: P.surface, border: '1px solid ' + P.line, boxShadow: '0 40px 100px rgba(0,0,0,0.55)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, padding: '18px 26px', borderBottom: '1px solid ' + P.line }}>
          <div style={{ width: 20, height: 20, borderRadius: 6, background: HU(HUES.it) }} />
          <div style={{ font: '500 22px ' + DISP, fontVariationSettings: wdth(100), color: P.text }}>Knowra</div>
        </div>
        <div style={{ padding: 34, display: 'flex', flexDirection: 'column', gap: 26, minHeight: 420 }}>
          <div style={{
            alignSelf: 'flex-end', maxWidth: 700, padding: '18px 24px', borderRadius: 12,
            background: HU(HUES.mfg, 0.16), font: '400 27px ' + BODY, color: P.text,
          }}>{cut(q, tq)}</div>
          <div style={{ maxWidth: 800, font: '400 27px ' + BODY, lineHeight: 1.5, color: P.text }}>
            {cut(ans, ta)}
            <span style={{
              display: 'inline-block', marginLeft: 10, transform: 'scale(' + chip + ')', padding: '2px 12px',
              borderRadius: 6, background: HU(HUES.mfg, 0.18), border: '1px solid ' + HU(HUES.mfg, 0.5),
              font: '400 24px ' + MONO, color: HU(HUES.mfg), verticalAlign: 'middle',
            }}>1</span>
          </div>
        </div>
      </div>
      <div style={{
        position: 'absolute', left: 1210, top: 300, width: 560, opacity: src,
        transform: 'translateX(' + px(50 - 50 * src) + ')',
        padding: 32, borderRadius: 14, background: P.surface2, border: '1px solid ' + HU(HUES.mfg, 0.3),
      }}>
        <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.12em', color: HU(HUES.mfg) }}>WORK_INSTRUCTION_4471.DOCX</div>
        <div style={{ marginTop: 12, font: '400 24px ' + MONO, color: P.dim }}>PAGE 12</div>
        <div style={{ marginTop: 26, font: '400 25px ' + BODY, lineHeight: 1.55, color: P.dim }}>
          “Fasteners shall be torqued to <span style={{ color: P.text, background: HU(HUES.mfg, 0.28 * hl), padding: '2px 6px', borderRadius: 4 }}>42 Nm ±2</span> with threads dry; lubricated threads require 34 Nm.”
        </div>
      </div>
      <div style={{
        position: 'absolute', left: 150, top: 830, opacity: ramp(T, C.Ask + 4.6, C.Ask + 5.4, MOTION.enter),
        font: '400 34px ' + BODY, color: P.text,
      }}>It shows you the page it read.</div>
    </div>
  );
}

// ── the boundary ──────────────────────────────────────────────────────────
function Guard({ T, C }) {
  const o = inOut(T, C.Guard + 0.2, C.Becomes + 0.2, 0.5, 0.5);
  const cols = [
    { role: 'FINANCE LEAD', hue: HUES.fin, src: ['Q3_Treasury_Review.xlsx', 'Liquidity_Controls.pdf', 'Board_Pack_Q3.pdf'], held: 0 },
    { role: 'EMPLOYEE', hue: HUES.health, src: ['Employee_Handbook_v7.pdf'], held: 2 },
  ];
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 150, top: 150, font: '400 24px ' + MONO, letterSpacing: '0.2em', color: P.mid }}>
        ONE QUESTION, TWO PEOPLE
      </div>
      <div style={{
        position: 'absolute', left: 150, top: 226, width: 1520,
        font: '500 56px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.02em', color: P.text,
      }}>“What does Q3 say about our liquidity cover?”</div>
      <div style={{ position: 'absolute', left: 150, top: 380, display: 'flex', gap: 40 }}>
        {cols.map((c, i) => {
          const a = C.Guard + 1.0 + i * 0.4;
          const op = ramp(T, a, a + 0.7, MOTION.enter);
          const y = animate({ from: 34, to: 0, start: a, end: a + 0.8, ease: MOTION.enter })(T);
          return (
            <div key={i} style={{
              width: 700, padding: 34, borderRadius: 14, opacity: op, transform: 'translateY(' + px(y) + ')',
              background: P.surface, border: '1px solid ' + HU(c.hue, 0.3),
            }}>
              <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.2em', color: HU(c.hue) }}>{c.role}</div>
              <div style={{ marginTop: 24, display: 'flex', flexDirection: 'column', gap: 12 }}>
                {c.src.map((s, j) => (
                  <div key={j} style={{
                    display: 'flex', alignItems: 'center', gap: 12, padding: '14px 18px', borderRadius: 8,
                    background: HU(c.hue, 0.11), font: '400 24px ' + MONO, color: P.text,
                  }}>
                    <div style={{ width: 7, height: 7, borderRadius: 4, background: HU(c.hue) }} />{s}
                  </div>
                ))}
                {c.held ? (
                  <div style={{
                    padding: '14px 18px', borderRadius: 8, border: '1px dashed rgba(233,233,237,0.22)',
                    font: '400 24px ' + MONO, color: P.dim,
                  }}>◈ {c.held} SOURCES WITHHELD</div>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>
      <div style={{
        position: 'absolute', left: 150, top: 830, width: 1500, opacity: ramp(T, C.Guard + 3.2, C.Guard + 4.2, MOTION.enter),
        font: '400 36px ' + BODY, lineHeight: 1.35, color: P.text,
      }}>Retrieval is filtered before the model ever sees a word. Unauthorised pages cannot become evidence.</div>
    </div>
  );
}

// ── what it becomes ───────────────────────────────────────────────────────
const ROLES = [
  { where: 'In a hospital', becomes: 'a clinical reference', read: 'that has read every protocol you have', hue: HUES.health, g: 'hospital' },
  { where: 'In a bank', becomes: 'a compliance analyst', read: 'that has read every filing and control', hue: HUES.fin, g: 'bank' },
  { where: 'In a school', becomes: 'a tutor', read: 'that has read the whole curriculum', hue: HUES.edu, g: 'school' },
  { where: 'In a freight desk', becomes: 'a contracts reader', read: 'that has read every carrier agreement', hue: HUES.log, g: 'freight' },
  { where: 'In engineering', becomes: 'an on-call engineer', read: 'that has read every runbook and postmortem', hue: HUES.it, g: 'servers' },
  { where: 'On a factory floor', becomes: 'a line engineer', read: 'that has read every work instruction', hue: HUES.mfg, g: 'factory' },
];

function Scene({ kind, hue, T, from }) {
  // Each vignette is two layers: neutral structure that fades up, and a hue-coloured
  // "ink" layer revealed by a clipping box that wipes left to right.
  const g = ramp(T, from, from + 0.55, MOTION.enter);
  const d = ramp(T, from + 0.35, from + 1.4, MOTION.draw);
  const W = 800, H = 480, VB = '20 20 640 384';
  const N = 'rgba(233,233,237,0.40)';
  const NF = 'rgba(233,233,237,0.055)';
  const A = HU(hue);
  const st = { stroke: N, strokeWidth: 5, fill: NF, strokeLinejoin: 'round' };
  const ln = { stroke: N, strokeWidth: 5, strokeLinecap: 'round' };
  const ink = { stroke: A, strokeWidth: 7, fill: 'none', strokeLinecap: 'round', strokeLinejoin: 'round' };
  const chip = { fill: HU(hue, 0.32), stroke: A, strokeWidth: 4 };

  const S = {
    hospital: {
      base: (
        <g>
          <rect x="352" y="30" width="308" height="200" rx="14" {...st} />
          <rect x="40" y="272" width="450" height="66" rx="16" {...st} />
          <rect x="58" y="234" width="126" height="44" rx="12" {...st} />
          <line x1="80" y1="338" x2="80" y2="392" {...ln} />
          <line x1="462" y1="338" x2="462" y2="392" {...ln} />
          <line x1="600" y1="264" x2="600" y2="392" {...ln} />
        </g>
      ),
      ink: (
        <g>
          <path d="M378 152 H430 l16 -48 18 96 20 -70 14 22 h172" {...ink} />
          <rect x="574" y="228" width="52" height="46" rx="8" {...chip} />
        </g>
      ),
    },
    bank: {
      base: (
        <g>
          <path d="M36 130 L330 36 L624 130 Z" {...st} />
          <rect x="36" y="130" width="588" height="20" rx="6" {...st} />
          {[76, 188, 300, 412, 524].map((x) => <rect key={x} x={x} y="164" width="50" height="164" rx="6" {...st} />)}
          <rect x="36" y="336" width="588" height="22" rx="8" {...st} />
        </g>
      ),
      ink: (
        <g>
          <path d="M110 306 L236 248 L362 278 L488 186 L572 212" {...ink} />
          <circle cx="488" cy="186" r="13" fill={A} />
        </g>
      ),
    },
    school: {
      base: (
        <g>
          <rect x="40" y="26" width="566" height="196" rx="10" {...st} />
          <rect x="28" y="222" width="590" height="16" rx="5" {...st} />
          {[40, 244, 448].map((x) => (
            <g key={x}>
              <rect x={x + 48} y="256" width="64" height="50" rx="7" {...st} />
              <rect x={x} y="306" width="160" height="16" rx="5" {...st} />
              <line x1={x + 18} y1="322" x2={x + 18} y2="392" {...ln} />
              <line x1={x + 142} y1="322" x2={x + 142} y2="392" {...ln} />
            </g>
          ))}
        </g>
      ),
      ink: (
        <g>
          <path d="M82 84 H430" {...ink} />
          <path d="M82 132 H540" {...ink} />
          <path d="M82 180 H330" {...ink} />
        </g>
      ),
    },
    freight: {
      base: (
        <g>
          <rect x="34" y="112" width="342" height="170" rx="12" {...st} />
          <path d="M388 172 h100 l68 70 v40 H388 Z" {...st} />
          <rect x="402" y="188" width="70" height="48" rx="8" {...st} />
          <circle cx="136" cy="300" r="36" {...st} />
          <circle cx="312" cy="300" r="36" {...st} />
          <circle cx="500" cy="300" r="36" {...st} />
        </g>
      ),
      ink: (
        <g>
          <path d="M20 366 H636" {...ink} />
          <rect x="120" y="152" width="164" height="92" rx="8" {...chip} />
          <path d="M144 180 h94" {...ink} strokeWidth="6" />
          <path d="M144 204 h116" {...ink} strokeWidth="6" />
          <path d="M144 226 h68" {...ink} strokeWidth="6" />
        </g>
      ),
    },
    servers: {
      base: (
        <g>
          <rect x="34" y="34" width="240" height="336" rx="14" {...st} />
          {[0, 1, 2, 3, 4].map((i) => <rect key={i} x="58" y={64 + i * 64} width="192" height="46" rx="8" {...st} />)}
          <rect x="326" y="86" width="330" height="228" rx="12" {...st} />
          <line x1="326" y1="134" x2="656" y2="134" {...ln} />
        </g>
      ),
      ink: (
        <g>
          {[0, 1, 2, 3, 4].map((i) => <circle key={i} cx="86" cy={87 + i * 64} r="9" fill={A} />)}
          <path d="M356 180 h92" {...ink} />
          <path d="M356 230 h196" {...ink} />
          <path d="M356 280 h130" {...ink} />
        </g>
      ),
    },
    factory: {
      base: (
        <g>
          <rect x="34" y="284" width="136" height="74" rx="10" {...st} />
          <rect x="204" y="334" width="440" height="22" rx="8" {...st} />
          {[232, 356, 480].map((x) => <rect key={x} x={x} y="272" width="86" height="62" rx="8" {...st} />)}
          <line x1="244" y1="356" x2="244" y2="398" {...ln} />
          <line x1="604" y1="356" x2="604" y2="398" {...ln} />
        </g>
      ),
      ink: (
        <g>
          <path d="M104 288 L200 148 L374 106" {...ink} strokeWidth="18" />
          <rect x="356" y="84" width="52" height="46" rx="8" {...chip} />
        </g>
      ),
    },
  }[kind];

  return (
    <div style={{ position: 'relative', width: px(W), height: px(H), opacity: g, transform: 'translateY(' + px(18 * (1 - g)) + ')' }}>
      <svg width={W} height={H} viewBox={VB} style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }}>{S.base}</svg>
      <div style={{ position: 'absolute', left: 0, top: 0, width: px(W * d), height: px(H), overflow: 'hidden' }}>
        <svg width={W} height={H} viewBox={VB} style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }}>{S.ink}</svg>
      </div>
    </div>
  );
}

function Becomes({ T, C }) {
  const o = inOut(T, C.Becomes - 0.2, C.Bounded + 0.2, 0.5, 0.5);
  const head = inOut(T, C.Becomes + 0.1, C.Bounded, 0.7, 0.5);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{
        position: 'absolute', left: 150, top: 150, opacity: head,
        font: '400 24px ' + MONO, letterSpacing: '0.2em', color: P.dim,
      }}>FEED IT YOUR DATA. IT BECOMES WHAT YOUR DATA IS</div>
      {ROLES.map((r, i) => {
        const a = C.Becomes + 0.6 + i * 1.9;
        const op = inOut(T, a - 0.35, a + (i === 5 ? 2.1 : 1.6), 0.3, 0.3);
        const x = animate({ from: 54, to: 0, start: a - 0.35, end: a + 0.5, ease: MOTION.enter })(T);
        return (
          <div key={i} style={{ position: 'absolute', inset: 0, opacity: op }}>
            <div style={{ position: 'absolute', left: 150, top: 320, width: 820, transform: 'translateX(' + px(x) + ')' }}>
              <div style={{ font: '400 40px ' + BODY, color: P.dim }}>{r.where}, it becomes</div>
              <div style={{
                marginTop: 14, font: '600 92px ' + DISP, fontVariationSettings: wdth(84),
                letterSpacing: '-0.03em', lineHeight: 1.04, color: HU(r.hue),
              }}>{r.becomes}</div>
              <div style={{ marginTop: 24, font: '400 34px ' + BODY, lineHeight: 1.35, color: P.text, textWrap: 'pretty' }}>{r.read}.</div>
            </div>
            <div style={{ position: 'absolute', left: 1000, top: 280 }}>
              <Scene kind={r.g} hue={r.hue} T={T} from={a - 0.25} />
            </div>
          </div>
        );
      })}
      <div style={{ position: 'absolute', left: 150, top: 830, display: 'flex', gap: 12, opacity: head }}>
        {ROLES.map((r, i) => {
          const on = clamp(1 - Math.abs((T - C.Becomes - 0.6) / 1.9 - i) * 1.2, 0, 1);
          return <div key={i} style={{
            width: 120, height: 4, borderRadius: 2,
            background: HU(r.hue, 0.18 + 0.82 * on),
          }} />;
        })}
      </div>
    </div>
  );
}

// ── bounded ───────────────────────────────────────────────────────────────
function Bounded({ T, C }) {
  const o = inOut(T, C.Bounded + 0.2, C.Poster + 0.2, 0.6, 0.5);
  const ring = ramp(T, C.Bounded + 0.3, C.Bounded + 1.4, MOTION.enter);
  const CX = 960, CY = 440, RAD = 220;
  const p = clamp((T - (C.Bounded + 1.5)) / 1.9, 0, 1);
  const hit = p > 0.55;
  const EDGE = CX + RAD + 24;               // the chip's left edge rests here, outside the ring
  const START = 1500, OUT = 1520;           // box is ~365px wide, so right edge stays < 1890
  const lead = hit
    ? EDGE + ((p - 0.55) / 0.45) * (OUT - EDGE)
    : START - (p / 0.55) * (START - EDGE);
  const flash = hit ? clamp(1 - (p - 0.55) * 5, 0, 1) : 0;
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{
        position: 'absolute', left: px(CX - RAD * ring), top: px(CY - RAD * ring),
        width: px(RAD * 2 * ring), height: px(RAD * 2 * ring), borderRadius: '50%',
        border: '2px solid ' + HU(HUES.it, 0.5 + 0.45 * flash),
        boxShadow: 'inset 0 0 110px ' + HU(HUES.it, 0.12) + ', 0 0 ' + px(50 + 90 * flash) + ' ' + HU(HUES.it, 0.14 + 0.4 * flash),
      }} />
      <div style={{
        position: 'absolute', left: px(CX), top: px(CY), transform: 'translate(-50%,-50%)',
        opacity: ring, textAlign: 'center',
      }}>
        <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.22em', color: HU(HUES.it), whiteSpace: 'nowrap' }}>YOUR ORGANISATION</div>
        <div style={{ marginTop: 18, font: '400 26px ' + BODY, color: P.dim, whiteSpace: 'nowrap' }}>every document you fed it</div>
      </div>
      <div style={{
        position: 'absolute', left: px(lead), top: px(CY - 26),
        opacity: clamp(p / 0.12, 0, 1) * (1 - clamp((p - 0.7) / 0.2, 0, 1)),
        padding: '14px 22px', borderRadius: 10, background: P.surface,
        border: '1px solid ' + (hit ? HU(HUES.mfg, 0.65) : P.line),
        font: '400 24px ' + MONO, color: hit ? HU(HUES.mfg) : P.dim, whiteSpace: 'nowrap',
      }}>“Who won the World Cup?”</div>
      <div style={{
        position: 'absolute', left: px(CX + RAD + 40), top: px(CY + 40), opacity: flash,
        font: '400 24px ' + MONO, letterSpacing: '0.18em', color: HU(HUES.mfg), whiteSpace: 'nowrap',
      }}>◈ OUT OF SCOPE</div>
      <div style={{
        position: 'absolute', left: 150, top: 810, width: 1620,
        opacity: ramp(T, C.Bounded + 3.4, C.Bounded + 4.4, MOTION.enter),
        font: '500 56px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.02em', color: P.text,
      }}>It reasons like a model. It answers like an employee.</div>
    </div>
  );
}

// ── poster and close ──────────────────────────────────────────────────────
function Poster({ T, C }) {
  const o = inOut(T, C.Poster + 0.1, 999, 0.8, 0.5);
  const w = interpolate([C.Poster + 0.1, C.Poster + 3.0], [72, 100], MOTION.draw)(T);
  const rule = ramp(T, C.Poster + 1.2, C.Poster + 3.2);
  const lift = animate({ from: 0, to: -150, start: C.Close, end: C.Close + 1.5, ease: MOTION.draw })(T);
  const sc = animate({ from: 1, to: 0.56, start: C.Close, end: C.Close + 1.5, ease: MOTION.draw })(T);
  return (
    <div style={{ position: 'absolute', left: 150, top: 400, opacity: o, transform: 'translateY(' + px(lift) + ')' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: px(48 * sc) }}>
        <Mark T={T} C={C} size={190 * sc} hue={HUES.it} />
        <div style={{
          font: '600 ' + px(200 * sc) + ' ' + DISP, fontVariationSettings: wdth(w, 96),
          letterSpacing: '-0.045em', lineHeight: 0.9, color: P.text,
        }}>Knowra</div>
      </div>
      <div style={{ marginTop: px(44 * sc), width: px(1180 * rule), height: 4, borderRadius: 2, background: SPECTRUM }} />
    </div>
  );
}

function Close({ T, C }) {
  const o = ramp(T, C.Close + 1.1, C.Close + 2.2, MOTION.enter);
  const y = animate({ from: 26, to: 0, start: C.Close + 1.1, end: C.Close + 2.3, ease: MOTION.enter })(T);
  const o2 = ramp(T, C.Close + 2.4, C.Close + 3.6, MOTION.enter);
  return (
    <div style={{ position: 'absolute', left: 150, top: 500, width: 1620, opacity: o, transform: 'translateY(' + px(y) + ')' }}>
      <div style={{
        font: '500 96px ' + DISP, fontVariationSettings: wdth(88),
        letterSpacing: '-0.035em', lineHeight: 1.06, color: P.text,
      }}>Ask your organisation anything.</div>
      <div style={{ marginTop: 34, font: '400 34px ' + BODY, lineHeight: 1.45, color: P.dim, opacity: o2 }}>
        Any industry that runs on documents. Deployed in your own environment,<br />answering only from what you feed it, and only to the people you allow.
      </div>
    </div>
  );
}

// ── composition ───────────────────────────────────────────────────────────
function Film({ mono }) {
  const { T, CUES: C } = useComposition();
  let hue = HUES.it;
  if (T < C.Ledger) hue = HUES.health;
  else if (T < C.Line) hue = HUES.fin;
  else if (T < C.Converge) hue = HUES.mfg;
  else if (T >= C.Becomes && T < C.Bounded) {
    const i = clamp(Math.floor((T - C.Becomes - 0.3) / 1.9), 0, 5);
    hue = ROLES[i].hue;
  }
  if (mono) hue = HUES.it;
  const vig = 0.14;

  return (
    <div style={{ position: 'absolute', inset: 0, background: P.bg, overflow: 'hidden', fontFamily: BODY, color: P.text }}>
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(1300px 900px at 26% 55%, ' + HU(hue, vig) + ', rgba(0,0,0,0) 72%)',
      }} />

      <Shot from={0} to={C.Ward + 0.6}>
        <Opening T={T} C={C} />
      </Shot>
      <Shot from={C.Ward - 0.3} to={C.Ledger + 0.3}>
        <Fact T={T} C={C} from={C.Ward} to={C.Ledger} hue={HUES.health} n="01" label="HEALTHCARE"
          figure="40" unit="% of a shift"
          claim="Nurses spend about forty per cent of a shift on documentation instead of patients."
          source="U.S. Surgeon General’s Advisory on Health Worker Burnout">
          <ShiftTrack T={T} C={C} />
        </Fact>
      </Shot>
      <Shot from={C.Ledger - 0.3} to={C.Line + 0.3}>
        <Fact T={T} C={C} from={C.Ledger} to={C.Line} hue={HUES.fin} n="02" label="FINANCE"
          figure="15.5" unit="% of payroll"
          claim="The smallest banks put up to 15.5% of payroll into compliance work. Regulation does not scale down."
          source="Conference of State Bank Supervisors, ten years of survey data">
          <PayrollBars T={T} C={C} />
        </Fact>
      </Shot>
      <Shot from={C.Line - 0.3} to={C.Converge + 0.3}>
        <Fact T={T} C={C} from={C.Line} to={C.Converge} hue={HUES.mfg} n="03" label="MANUFACTURING"
          figure="11" unit="% of revenue"
          claim="Unplanned downtime costs the world’s 500 largest companies 11% of revenue. When a line stops, the answer is in a document somewhere."
          source="Siemens, True Cost of Downtime 2024">
          <StoppedLine T={T} C={C} />
        </Fact>
      </Shot>

      <Shot from={C.Converge - 0.5} to={C.Reveal + 1.6}><Converge T={T} C={C} /></Shot>
      <Shot from={C.Converge + 1.0} to={C.What + 0.8}><Reveal T={T} C={C} /></Shot>
      <Shot from={C.What} to={C.Feed + 0.4}><WhatItIs T={T} C={C} /></Shot>
      <Shot from={C.Feed - 0.3} to={C.Ask + 0.4}><Feed T={T} C={C} /></Shot>
      <Shot from={C.Ask} to={C.Guard + 0.4}><AskPanel T={T} C={C} /></Shot>
      <Shot from={C.Guard} to={C.Becomes + 0.4}><Guard T={T} C={C} /></Shot>
      <Shot from={C.Becomes - 0.3} to={C.Bounded + 0.4}><Becomes T={T} C={C} /></Shot>
      <Shot from={C.Bounded} to={C.Poster + 0.4}><Bounded T={T} C={C} /></Shot>
      <Shot from={C.Poster} to={999}><Poster T={T} C={C} /></Shot>
      <Shot from={C.Close} to={999}><Close T={T} C={C} /></Shot>
    </div>
  );
}

// ── act I opener ──────────────────────────────────────────────────────────
const BARS = Array.from({ length: 96 }, (_, i) => ({ h: 40 + ((i * 137) % 97) * 3.4, d: (i % 12) * 0.035 + Math.floor(i / 12) * 0.06 }));

function Opening({ T, C }) {
  const o = inOut(T, 0.1, C.Ward + 0.5, 0.8, 0.5);
  const pct = Math.round(interpolate([1.5, 3.4], [0, 20], MOTION.draw)(T));
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{ position: 'absolute', left: 0, bottom: 0, width: 1920, height: 420, display: 'flex', alignItems: 'flex-end', gap: 8, padding: '0 150px' }}>
        {BARS.map((b, i) => {
          const g = ramp(T, 0.2 + b.d, 1.4 + b.d, MOTION.enter);
          return <div key={i} style={{
            flex: 1, height: px(b.h * g), borderRadius: 2,
            background: 'linear-gradient(180deg, rgba(233,233,237,0.20), rgba(233,233,237,0.04))',
          }} />;
        })}
      </div>
      <div style={{ position: 'absolute', left: 150, top: 210, width: 1500 }}>
        <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.22em', color: P.mid }}>EVERY ORGANISATION RUNS ON DOCUMENTS</div>
        <div style={{ marginTop: 54, display: 'flex', alignItems: 'baseline', gap: 20 }}>
          <div style={{ font: '300 200px ' + MONO, letterSpacing: '-0.05em', lineHeight: 0.86, color: P.text }}>{pct}%</div>
          <div style={{ font: '400 36px ' + BODY, color: P.accent }}>of the working week</div>
        </div>
        <div style={{
          marginTop: 44, width: 1400, opacity: ramp(T, 2.6, 3.6, MOTION.enter),
          font: '500 58px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.02em', lineHeight: 1.14, color: P.text,
        }}>goes to looking for internal information, or for the colleague who has it.</div>
        <div style={{ marginTop: 34, font: '400 24px ' + MONO, letterSpacing: '0.03em', color: P.dim, opacity: ramp(T, 3.4, 4.2, MOTION.enter) }}>
          SOURCE: McKinsey Global Institute
        </div>
      </div>
    </div>
  );
}

function KnowraTrailerV2() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS || { spectrum: true, motionEditor: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} bg={P.bg}
        scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Film mono={!tw.spectrum} />
      </CompositionStage>
      <window.TweaksPanel title="Trailer v2">
        <window.TweakSection label="Look">
          <window.TweakToggle label="Industry spectrum" value={tw.spectrum} onChange={(v) => setTweak('spectrum', v)} />
          <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

window.KnowraTrailerV2 = KnowraTrailerV2;

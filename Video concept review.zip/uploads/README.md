# Knowra launch film — source bundle

Everything the film is made of. There are no image, video, or audio assets to
ship: every frame is DOM and CSS, drawn live from code. The only external
resource is Plus Jakarta Sans from Google Fonts (self-host it in production).

## Getting the video file

Open `Knowra Promo Film.dc.html` and use **Share → Export → Video**. Pick the
resolution you want; the film is authored at 1920×1080 and exports 16:9 at any
scale. The exporter walks the timeline frame by frame and renders each one
deterministically, so the output matches the preview exactly — it is not a
screen recording.

The timeline bar under the preview is where you change timing before exporting:
drag a section's edge to trim it, or set a section's speed. Choreography retimes
rather than cutting off. The Tweaks panel has a **Motion editor** toggle that
hides the bar without touching the animation or the export.

## Files

| File | What it is |
|---|---|
| `Knowra Promo Film.dc.html` | The film. Open this. It declares the scene list, the playback setting and the tweak defaults, and mounts the composition. |
| `knowra-promo-film.jsx` | **The film itself** — every frame, every object, all the copy and data. This is the file to read and edit. |
| `animations-v3.jsx` | The animation engine. Not written for this project; owns the clock, the scrubber, the seek/export contract and the easing library. Don't edit. |
| `tweaks-panel.jsx` | The Tweaks panel shell. Don't edit. |
| `support.js` | Runtime the `.dc.html` files load so they open standalone. Not part of the design; do not port it. |
| `Knowra Launch Film - Script.dc.html` | The shooting script — shot list, times, on-screen copy, motion spec, derivative cuts. Printable. |
| `doc-page.js` | Paged-document shell the script document prints through. |
| `_ds/modernist-…/` | Stylesheet and bundle the script document is typeset in. The film itself does not use these. |

Keep the folder together — the HTML files load their siblings by relative path.

## How the film is built

The whole piece is **one element tree rendered as a pure function of one
authored clock**. Nothing mounts or unmounts at a section boundary, which is why
it reads as a continuous take rather than a sequence of scenes.

**Structure lives in one place.** `window.OM_SCENES` in the HTML file is a JSON
string of twelve named sections with durations:

```
Question 4 · Scatter 5 · Stranger 5 · Reveal 6 · Upload 6 · Ask 7
Answer 8 · Verify 9 · Access 7 · Audience 9 · Ships 6 · Close 8   = 80s
```

The engine derives the cue table from that literal, so section starts have
exactly one source and cannot drift. Editing timing on the host timeline writes
back into this string.

**Everything is keyed to `T` and `CUES`.** `useComposition()` returns `T`
(authored seconds) and `CUES.SectionName` (that section's authored start).
Every position, opacity, scale and character count in the film is computed from
`T` — never from a local clock, a CSS transition, or a `useEffect`. That is what
makes any timestamp render deterministically, which is what makes the export
frame-accurate.

**Three motion helpers, no exceptions.** `MOTION.enter` (easeOutQuart),
`MOTION.draw` (easeInOutCubic), `MOTION.pop` (easeOutBack). No easing or
transform is authored outside them. The only overshoot in the film is 6% on the
citation chips.

**The camera is one transform.** A single wrapping div gets
`translate(960,540) scale(s) translate(-fx,-fy)` with `transform-origin: 0 0`,
where `s`, `fx`, `fy` are interpolated across fifteen keyframes tied to cues.
Three real moves: push in at Ask, pull back at Access, recede at Audience.

**Objects persist across boundaries.** Each of these is one element whose motion
straddles a cue:

- The opening question → shrinks into a chat bubble → is buried by tiles →
  slides off the bottom edge → flies back up into the thread at Ask and retypes
  into the policy question.
- The eleven document tiles → fly into one aligned stack at Reveal → compress
  into the K mark.
- The mark → travels into the window's title bar as the window unfolds from it.
- The `[1]` citation chip → detaches at the click and expands into the source
  viewer.
- The window → mitoses into the Finance and Employee pair at Access.

**Two implementation details worth knowing before you edit:**

1. **`<Typed>`** types text on without ever reflowing: the untyped remainder
   stays in the layout as `visibility: hidden`. This is why the citation chip
   never moves, which is why the cursor can be aimed at it.
2. **The cursor position is measured, not guessed.** A layout effect walks the
   chip's `offsetParent` chain to get its position in stage coordinates
   (`offsetLeft`/`offsetTop` are layout, so they ignore the camera transform —
   `getBoundingClientRect` would not). The cursor then travels to that measured
   point.

**Hard cuts are content, not structure.** `<Shot from={CUES.X} to={CUES.Y}>`
flips visibility at two cues while keeping children mounted. The film has only
two authored cuts, both in the first fifteen seconds.

## Copy and data

All of it sits in named constants at the top of `knowra-promo-film.jsx` —
`TILES`, `UPLOADS`, `AUDIENCE`, `SHIPS`, `ROLE_FIN`, `ROLE_EMP`, the three
questions, the two answer clauses. Captions are one array at the bottom of
`Film()`. Change a string there and it changes everywhere it appears.

## Numbers to replace

Realistic, but invented:

- 33 documents indexed (sidebar and Upload Center)
- Q3 contractor spend $384,200, up 7% on Q2; engineering line $206,500
- Six filenames and sizes in the Upload Center

## Tokens

The film uses the product's own palette, not the Modernist system the script
document is typeset in. The `P` object at the top of the jsx is the same token
set as the landing page and app screens — accent `#7c3aed`, ground `#fdfcfa`,
ink `#191735`, and the tint/wash/line ramp derived from the accent. Type is
Plus Jakarta Sans 400–800 throughout.

## Audio

Unscored, by design: the film plays muted with burned-in captions, so it works
in an autoplaying page player. Adding a track later needs no re-animation. Two
recommended additions if you do score it: a sparse electronic bed around 92bpm
entering at 0:04 and stepping up at 0:20 and 0:56, and three accents only — the
tile burial (0:07), the citation click (0:41), the field flood (1:12).

Open-source and royalty-free sources: Free Music Archive (filter CC0), Pixabay
Music, Uppbeat (free tier, credit required), incompetech.com (CC-BY). Search
"minimal tech ambient" or "corporate technology pulse". UI clicks and risers
from freesound.org.

## Derivative cuts

Planned but not built — each is a trim of this master, not a rebuild:

| Cut | Length | From |
|---|---|---|
| Social teaser | 0:20 | Question → Reveal → Verify → Close |
| Moment loops ×3 | 45–55s each | Upload, Ask+Answer, Verify — the three Product Moments players on the landing page |
| Access explainer | 0:15 | The Access beat alone |

A 9:16 vertical master needs the Access and Ships beats restaged, not cropped.

/* knowra-promo-film.jsx — the Knowra launch film, authored on animations-v3.
   One element tree, one authored clock. Every object below persists for the
   whole 80s and earns its position by interpolation from T. */

const P = {
  bg: '#fdfcfa', surface: '#ffffff', surface2: '#fcfaf7',
  ink: '#191735', ink2: '#2c2949', body: '#5b5878', muted: '#8d8aa3', faint: '#a6a3ba',
  border: '#eee7dc', rule: '#ece5da', solid: '#191735', onsolid: '#ffffff', mark: '#1e1b4b',
  accent: '#7c3aed', deep: '#6d28d9', tint: '#f1e9ff', soft: '#a78bfa',
  wash: '#f6f0ff', panel: '#f9f4ff', panel2: '#fcfaff',
  line: '#e6d9fb', line2: '#f0e8fb', hi: '#e9dcff',
  grey1: '#f4f4f5', grey2: '#e4e4e7', greyInk: '#3f3f46', greyMuted: '#a1a1aa',
};
const FONT = 'Plus Jakarta Sans, system-ui, sans-serif';

/* exactly three motion helpers — no easing or transform is authored outside them */
const MOTION = {
  enter: (from, to, start, end) => animate({ from, to, start, end, ease: Easing.easeOutQuart }),
  draw:  (from, to, start, end) => animate({ from, to, start, end, ease: Easing.easeInOutCubic }),
  pop:   (from, to, start, end) => animate({ from, to, start, end, ease: Easing.easeOutBack }),
};

/* utilities (not motion): colour mixing and layout-stable typing */
function hx(c) { return [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)]; }
function mix(a, b, t) {
  const A = hx(a), B = hx(b), k = clamp(t, 0, 1);
  return 'rgb(' + Math.round(A[0] + (B[0] - A[0]) * k) + ',' + Math.round(A[1] + (B[1] - A[1]) * k) + ',' + Math.round(A[2] + (B[2] - A[2]) * k) + ')';
}
/* types text on without ever reflowing: the untyped remainder still occupies
   its space, so anything measured by ref (the citation chip) never moves. */
function Typed({ text, t, start, end }) {
  const n = Math.round(clamp((t - start) / (end - start), 0, 1) * text.length);
  return <React.Fragment>{text.slice(0, n)}<span style={{ visibility: 'hidden' }}>{text.slice(n)}</span></React.Fragment>;
}

const WIN = { x: 320, y: 150, w: 1280, h: 800 };
const BAR = 56;
const SIDE = 268;
const PANE = { x: WIN.x + SIDE, y: WIN.y + BAR, w: WIN.w - SIDE, h: WIN.h - BAR };

const TILES = [
  { n: 'Handbook v3 FINAL.pdf', x: 120, y: 300, r: -4 },
  { n: 'Leave Policy 2024.docx', x: 430, y: 208, r: 3 },
  { n: 'wiki / hr / leave-and-absence', x: 760, y: 320, r: -2 },
  { n: 'Re: quick question', x: 1080, y: 236, r: 5 },
  { n: 'Onboarding deck.pptx', x: 1380, y: 330, r: -3 },
  { n: 'policy_old.pdf', x: 250, y: 560, r: 2 },
  { n: 'HR-FAQ (2022).docx', x: 600, y: 624, r: -5 },
  { n: 'Benefits summary.pdf', x: 930, y: 560, r: 3 },
  { n: 'attachment_2.pdf', x: 1250, y: 612, r: -2 },
  { n: 'Team drive / People', x: 480, y: 830, r: 4 },
  { n: 'Employee Handbook.pdf', x: 1010, y: 842, r: -3 },
];

const UPLOADS = [
  ['Employee Handbook.pdf', '2.4 MB'], ['Remote Work Policy.pdf', '480 KB'],
  ['Leave and Absence Policy.docx', '212 KB'], ['Expense Procedure 2026.pdf', '1.1 MB'],
  ['Onboarding Handbook.docx', '3.8 MB'], ['Contractor Roster Q3.docx', '96 KB'],
];

const AUDIENCE = [
  ['Employees', 'Ask the handbook instead of asking a colleague.'],
  ['HR', 'Answer the same policy question once, not forty times.'],
  ['Finance', 'Pull figures from reports only your team can open.'],
  ['Admins', 'Manage users, roles and what each document exposes.'],
];

const SHIPS = ['Cited chat', 'Document upload', 'Source viewer', 'Roles and permissions', 'Admin console', 'Usage dashboard'];

const ROLE_FIN = {
  role: 'FINANCE',
  answer: 'Contractor spend for Q3 was $384,200, up 7% on Q2. The largest line is engineering contract work at $206,500.',
  rows: [
    ['Q3 Contractor Spend.xlsx', 'Cited [1]', 1], ['Vendor Contracts 2026.pdf', 'Cited [2]', 1],
    ['Employee Handbook.pdf', 'Readable', 1], ['Personnel Files.pdf', 'Not visible', 0],
  ],
};
const ROLE_EMP = {
  role: 'EMPLOYEE',
  answer: 'You do not have access to finance reporting. Knowra could not find an authorized source for this question and did not answer it.',
  rows: [
    ['Employee Handbook.pdf', 'Readable', 1], ['Remote Work Policy.pdf', 'Readable', 1],
    ['Q3 Contractor Spend.xlsx', 'Not visible', 0], ['Vendor Contracts 2026.pdf', 'Not visible', 0],
  ],
};

const Q_OPEN = 'How many days of leave do I have left this year?';
const Q_ASK = 'What is the remote work policy for new joiners?';
const Q_ROLE = 'How much did we spend on contractors last quarter?';

const A1 = 'New joiners work from the office for their first 30 days, then move to the standard hybrid schedule of three days on site.';
const A2 = ' Requests for full remote go through your manager and HR.';

/* ── document tile ───────────────────────────────────────────────────────── */
function Tile({ tile, i, T, C }) {
  const edge = [[-420, 0], [0, -300], [420, 0], [0, 300]][i % 4];
  const s = C.Scatter + i * 0.09;
  const inx = MOTION.enter(tile.x + edge[0], tile.x, s, s + 0.85)(T);
  const iny = MOTION.enter(tile.y + edge[1], tile.y, s, s + 0.85)(T);
  const o = MOTION.enter(0, 1, s, s + 0.4)(T);
  /* fly home into the stack, then compress into the mark */
  const g = C.Reveal + (10 - i) * 0.045;
  const hx2 = MOTION.draw(0, 1, g, g + 0.9)(T);
  const x = inx + (200 - inx) * hx2, y = iny + (380 - iny) * hx2;
  const k = MOTION.draw(1, 0.06, C.Reveal + 1.2, C.Reveal + 2.0)(T);
  const fade = MOTION.draw(1, 0, C.Reveal + 1.5, C.Reveal + 2.0)(T);
  const grey = MOTION.draw(0, 1, C.Stranger, C.Stranger + 0.7)(T) * (1 - hx2);
  const drift = Math.sin(T * 0.55 + i * 1.7) * 4 * (1 - hx2);
  return (
    <div style={{
      position: 'absolute', left: x, top: y + drift, width: 340, height: 96,
      background: P.surface, border: '1px solid ' + P.border, borderRadius: 12,
      padding: '18px 20px', boxSizing: 'border-box', opacity: o * fade,
      transform: 'rotate(' + tile.r * (1 - hx2) + 'deg) scale(' + k + ')',
      filter: 'grayscale(' + grey + ') saturate(' + (1 - grey * 0.7) + ')',
      boxShadow: '0 8px 20px rgba(40,32,90,0.06)',
    }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
        <div style={{ width: 10, height: 10, borderRadius: 999, background: mix(P.soft, P.faint, grey), flex: 'none' }} />
        <div style={{ font: '600 22px ' + FONT, color: mix(P.ink2, P.greyMuted, grey), whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tile.n}</div>
      </div>
      <div style={{ font: '500 17px ' + FONT, color: P.faint, marginTop: 8 }}>last opened — nobody remembers</div>
    </div>
  );
}

/* ── the question: headline → buried bubble → the asked question ─────────── */
function Question({ T, C }) {
  const toB = MOTION.draw(0, 1, C.Scatter - 0.3, C.Scatter + 0.9)(T);      /* headline → bubble */
  const sink = MOTION.draw(0, 1, C.Stranger - 0.4, C.Stranger + 1.0)(T);   /* slides off frame */
  const back = MOTION.enter(0, 1, C.Ask + 0.5, C.Ask + 1.5)(T);           /* returns into the thread */
  const gone = MOTION.draw(0, 1, C.Access, C.Access + 0.5)(T);

  const x = 200 + (928 - 200) * back;
  const y = (400 + (730 - 400) * toB) + 520 * sink * (1 - back) + (240 - 730) * back;
  const w = 1420 + (640 - 1420) * toB;
  const fs = 88 + (28 - 88) * toB;
  const bg = toB;
  const ask = T > C.Ask + 1.0;
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w,
      background: 'rgba(25,23,53,' + bg + ')', color: mix(P.ink, P.onsolid, bg),
      padding: (20 * bg) + 'px ' + (26 * bg) + 'px', boxSizing: 'border-box',
      borderRadius: '16px 16px ' + (4 + 12 * (1 - bg)) + 'px 16px',
      zIndex: T > C.Ask ? 6 : 0, font: (800 - 300 * toB) + ' ' + fs + 'px ' + FONT,
      lineHeight: 1.06 + 0.34 * toB, letterSpacing: -0.04 + 0.03 * toB + 'em',
      opacity: 1 - gone, textWrap: 'pretty',
    }}>
      {ask ? <Typed text={Q_ASK} t={T} start={C.Ask + 1.6} end={C.Ask + 3.6} />
           : <Typed text={Q_OPEN} t={T} start={0.5} end={3.0} />}
      <span style={{
        display: 'inline-block', width: 5, height: fs * 0.9, marginLeft: 8,
        background: mix(P.accent, P.onsolid, bg), verticalAlign: 'baseline',
        opacity: (T < 3.2 || (T > C.Ask + 1.4 && T < C.Ask + 3.8)) ? (Math.floor(T * 2) % 2 ? 0.15 : 1) : 0,
      }} />
    </div>
  );
}

/* ── the confident stranger ──────────────────────────────────────────────── */
function Stranger({ T, C }) {
  const wipe = MOTION.draw(0, 1, C.Stranger, C.Stranger + 0.7)(T);
  const die = MOTION.draw(0, 1, C.Stranger + 3.4, C.Stranger + 4.6)(T);
  return (
    <div style={{
      position: 'absolute', left: 470, top: 290, width: 980, height: 470,
      background: P.grey1, border: '1px solid ' + P.grey2, borderRadius: 14,
      clipPath: 'inset(0 ' + (100 - wipe * 100) + '% 0 0)',
      opacity: 1 - die, filter: 'blur(' + die * 14 + 'px)',
      transform: 'translateY(' + die * -30 + 'px)',
      boxShadow: '0 20px 50px rgba(0,0,0,0.07)', boxSizing: 'border-box', padding: 40,
    }}>
      <div style={{ font: '700 18px ' + FONT, letterSpacing: '0.14em', color: P.greyMuted }}>GENERIC ASSISTANT</div>
      <div style={{ font: '500 32px ' + FONT, lineHeight: 1.5, color: P.greyInk, marginTop: 26 }}>
        <Typed text="You are typically entitled to 25 days of annual leave per year, which may accrue monthly depending on your employer's policy." t={T} start={C.Stranger + 0.7} end={C.Stranger + 2.6} />
      </div>
      <div style={{ position: 'absolute', left: 40, right: 40, bottom: 40 }}>
        <div style={{ height: 1, background: P.grey2 }} />
        <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 16 }}>
          <div style={{ font: '700 17px ' + FONT, letterSpacing: '0.12em', color: P.greyMuted }}>SOURCES</div>
          <div style={{ font: '500 17px ' + FONT, color: P.greyMuted, opacity: MOTION.draw(0, 1, C.Stranger + 2.7, C.Stranger + 3.2)(T) }}>—</div>
        </div>
      </div>
    </div>
  );
}

/* ── mark and wordmark ───────────────────────────────────────────────────── */
function Mark({ T, C }) {
  const born = MOTION.pop(0, 1, C.Reveal + 1.7, C.Reveal + 2.5)(T);
  const go = MOTION.draw(0, 1, C.Upload, C.Upload + 1.0)(T);
  const size = 132 + (32 - 132) * go;
  const x = (266 - size / 2) + (WIN.x + 24 - (266 - size / 2)) * go;
  const y = (446 - size / 2) + (WIN.y + 12 - (446 - size / 2)) * go;
  const off = MOTION.draw(1, 0, C.Access, C.Access + 0.5)(T);
  const word = MOTION.draw(0, 1, C.Reveal + 2.3, C.Reveal + 3.3)(T);
  const wordOut = MOTION.draw(0, 1, C.Upload - 0.4, C.Upload + 0.4)(T);
  return (
    <React.Fragment>
      <div style={{
        position: 'absolute', left: x, top: y, width: size, height: size,
        background: P.mark, borderRadius: 8 * (size / 132) + 4, transform: 'scale(' + born + ')', opacity: off, zIndex: 7,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        font: '800 ' + size * 0.58 + 'px ' + FONT, color: '#fff',
      }}>K</div>
      <div style={{
        position: 'absolute', left: 358, top: 376, opacity: 1 - wordOut,
        font: '800 96px ' + FONT, letterSpacing: '-0.035em', color: P.ink,
        clipPath: 'inset(0 ' + (100 - word * 100) + '% 0 0)',
      }}>Knowra</div>
      <div style={{
        position: 'absolute', left: 200, top: 620, width: 1520, opacity: (1 - wordOut) * MOTION.enter(0, 1, C.Reveal + 3.2, C.Reveal + 4.0)(T),
        transform: 'translateY(' + MOTION.enter(28, 0, C.Reveal + 3.2, C.Reveal + 4.0)(T) + 'px)',
        font: '800 62px ' + FONT, letterSpacing: '-0.035em', color: P.ink,
      }}>Your organization already has the answers.</div>
    </React.Fragment>
  );
}

/* ── window chrome ───────────────────────────────────────────────────────── */
function Chrome({ label }) {
  return (
    <React.Fragment>
      <div style={{
        position: 'absolute', left: 0, top: 0, width: WIN.w, height: BAR,
        background: P.panel2, borderBottom: '1px solid ' + P.line2, boxSizing: 'border-box',
        display: 'flex', alignItems: 'center', gap: 14, paddingLeft: 72,
      }}>
        <div style={{ font: '600 20px ' + FONT, color: P.muted }}>{label}</div>
      </div>
      <div style={{ position: 'absolute', left: SIDE, top: BAR, width: 1, bottom: 0, background: P.line2 }} />
      <div style={{ position: 'absolute', left: 0, top: BAR, width: SIDE, bottom: 0, background: P.panel2 }} />
    </React.Fragment>
  );
}

const NAV = [['WORKSPACE', 0], ['Ask', 296], ['Documents', 348], ['Sources', 400], ['Admin', 452], ['MANAGE', 0], ['Upload Center', 566], ['Collections', 618], ['Users', 670]];

function Sidebar({ T, C }) {
  const pill = MOTION.draw(348, 296, C.Ask, C.Ask + 0.6)(T);
  const pill2 = MOTION.draw(566, pill, C.Ask - 0.6, C.Ask)(T);
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 16, top: pill2 - WIN.y - 8, width: SIDE - 32, height: 44, background: P.tint, borderRadius: 10 }} />
      {NAV.map((it, i) => it[1] === 0 ? (
        <div key={i} style={{ position: 'absolute', left: 28, top: (i === 0 ? 250 : 520) - WIN.y, font: '700 16px ' + FONT, letterSpacing: '0.12em', color: P.faint }}>{it[0]}</div>
      ) : (
        <div key={i} style={{ position: 'absolute', left: 28, top: it[1] - WIN.y, font: '500 22px ' + FONT, color: Math.abs(it[1] - pill2) < 4 ? P.deep : P.body }}>{it[0]}</div>
      ))}
      <div style={{ position: 'absolute', left: 28, top: 880 - WIN.y, width: SIDE - 56, borderTop: '1px solid ' + P.line2, paddingTop: 14, font: '500 17px ' + FONT, color: P.faint }}>33 documents indexed</div>
    </React.Fragment>
  );
}

/* ── upload pane ─────────────────────────────────────────────────────────── */
function UploadPane({ T, C }) {
  const o = MOTION.draw(0, 1, C.Upload + 0.8, C.Upload + 1.3)(T) * (1 - MOTION.draw(0, 1, C.Ask, C.Ask + 0.6)(T));
  return (
    <div style={{ position: 'absolute', left: SIDE + 32, top: BAR + 44, width: PANE.w - 64, opacity: o }}>
      <div style={{ font: '800 40px ' + FONT, letterSpacing: '-0.03em', color: P.ink }}>Upload Center</div>
      <div style={{ font: '500 22px ' + FONT, color: P.body, marginTop: 10 }}>PDF · DOCX · TXT — one file or a folder of them.</div>
      <div style={{ marginTop: 34, display: 'flex', flexDirection: 'column', gap: 14 }}>
        {UPLOADS.map((f, i) => {
          const s = C.Upload + 1.4 + i * 0.14;
          const dur = 1.5 + (i % 3) * 0.35;
          const p = MOTION.draw(0, 1, s + 0.2, s + 0.2 + dur)(T);
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 20, padding: '14px 18px',
              background: P.surface, border: '1px solid ' + P.border, borderRadius: 12,
              opacity: MOTION.enter(0, 1, s, s + 0.4)(T),
              transform: 'translateY(' + MOTION.enter(-22, 0, s, s + 0.5)(T) + 'px)',
            }}>
              <div style={{ font: '600 21px ' + FONT, color: P.ink2, width: 420, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{f[0]}</div>
              <div style={{ font: '500 18px ' + FONT, color: P.faint, width: 80 }}>{f[1]}</div>
              <div style={{ flex: 1, height: 8, background: P.line2, borderRadius: 999, overflow: 'hidden' }}>
                <div style={{ width: p * 100 + '%', height: '100%', background: P.accent }} />
              </div>
              <div style={{ font: '700 18px ' + FONT, color: p > 0.999 ? P.deep : P.faint, width: 96, textAlign: 'right' }}>{p > 0.999 ? 'Indexed' : Math.round(p * 100) + '%'}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── chat pane: answer, chips, sources, viewer ───────────────────────────── */
function ChatPane({ T, C, chipRef }) {
  const o = MOTION.draw(0, 1, C.Ask + 0.2, C.Ask + 0.8)(T) * (1 - MOTION.draw(0, 1, C.Access, C.Access + 0.5)(T));
  const panel = MOTION.enter(0, 1, C.Answer, C.Answer + 0.7)(T);
  const chip1 = MOTION.pop(0, 1, C.Answer + 2.4, C.Answer + 3.0)(T);
  const chip2 = MOTION.pop(0, 1, C.Answer + 4.4, C.Answer + 5.0)(T);
  const open = T > C.Verify + 2.8;
  const view = MOTION.enter(0, 1, C.Verify + 2.8, C.Verify + 3.6)(T);
  const hl = MOTION.draw(0, 1, C.Verify + 4.0, C.Verify + 5.0)(T);
  const Chip = ({ n, k, r }) => (
    <span ref={r} style={{
      display: 'inline-block', padding: '2px 10px', margin: '0 2px', borderRadius: 6,
      background: n === 1 && open ? P.deep : P.accent, color: '#fff',
      font: '700 20px ' + FONT, transform: 'scale(' + k + ')', verticalAlign: 3,
    }}>[{n}]</span>
  );
  return (
    <div style={{ position: 'absolute', left: 0, top: 0, right: 0, bottom: 0, opacity: o }}>
      {/* answer panel */}
      <div style={{
        position: 'absolute', left: SIDE + 32, top: 366 - WIN.y, width: PANE.w - 64,
        background: P.panel, border: '1px solid ' + P.line, borderRadius: 16, padding: 28,
        boxSizing: 'border-box', opacity: panel, transform: 'translateY(' + (1 - panel) * 24 + 'px)',
      }}>
        <div style={{ font: '400 28px ' + FONT, lineHeight: 1.6, color: P.ink2 }}>
          <Typed text={A1} t={T} start={C.Answer + 0.6} end={C.Answer + 2.4} />
          <Chip n={1} k={chip1} r={chipRef} />
          <Typed text={A2} t={T} start={C.Answer + 2.8} end={C.Answer + 4.4} />
          <Chip n={2} k={chip2} />
        </div>
      </div>
      {/* sources */}
      <div style={{ position: 'absolute', left: SIDE + 32, top: 566 - WIN.y, width: PANE.w - 64, borderTop: '1px solid ' + P.line2, paddingTop: 14, opacity: MOTION.draw(0, 1, C.Answer + 5.0, C.Answer + 5.5)(T) }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'baseline' }}>
          <div style={{ font: '700 17px ' + FONT, letterSpacing: '0.12em', color: P.faint }}>SOURCES</div>
          <div style={{ font: '600 18px ' + FONT, color: P.deep, opacity: open ? 0 : 1 }}>Click a source to open the page</div>
        </div>
      </div>
      {[['1', 'Remote Work Policy.pdf', 'page 5'], ['2', 'Onboarding Handbook.docx', 'page 12']].map((r, i) => {
        const s = C.Answer + 5.4 + i * 0.12;
        return (
          <div key={i} style={{
            position: 'absolute', left: SIDE + 32, top: (600 + i * 62) - WIN.y, width: PANE.w - 64,
            display: 'flex', alignItems: 'center', gap: 14, padding: '12px 18px', boxSizing: 'border-box',
            background: P.surface, border: '1px solid ' + (i ? P.line2 : P.line), borderRadius: 12,
            opacity: MOTION.enter(0, 1, s, s + 0.5)(T), transform: 'translateY(' + MOTION.enter(26, 0, s, s + 0.6)(T) + 'px)',
          }}>
            <div style={{ font: '700 21px ' + FONT, color: i ? P.soft : P.accent }}>[{r[0]}]</div>
            <div style={{ font: '600 21px ' + FONT, color: i ? P.body : P.ink, whiteSpace: 'nowrap' }}>{r[1]}</div>
            <div style={{ font: '500 20px ' + FONT, color: P.muted, whiteSpace: 'nowrap' }}>{r[2]}</div>
            <div style={{ marginLeft: 'auto', font: '700 19px ' + FONT, color: i ? P.faint : P.deep }}>Open</div>
          </div>
        );
      })}
      {/* source viewer */}
      <div style={{
        position: 'absolute', left: SIDE + 32, top: 726 - WIN.y, width: PANE.w - 64,
        background: P.surface, border: '1px solid ' + P.line, borderRadius: 12, overflow: 'hidden',
        opacity: view, transform: 'translateY(' + (1 - view) * -18 + 'px) scaleY(' + (0.4 + 0.6 * view) + ')',
        transformOrigin: 'top center',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', padding: '12px 18px', background: P.panel2, borderBottom: '1px solid ' + P.line2 }}>
          <div style={{ font: '700 17px ' + FONT, letterSpacing: '0.1em', color: P.faint }}>REMOTE WORK POLICY.PDF — PAGE 5</div>
          <div style={{ marginLeft: 'auto', font: '700 18px ' + FONT, color: P.deep }}>Close</div>
        </div>
        <div style={{ padding: '14px 20px', font: '400 20px ' + FONT, lineHeight: 1.7, color: P.muted }}>
          <div>5.2 Onboarding period</div>
          <div style={{ position: 'relative', display: 'inline-block', margin: '6px 0', padding: '6px 8px' }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: hl * 100 + '%', background: P.hi, borderRadius: 6 }} />
            <span style={{ position: 'relative', font: '600 20px ' + FONT, color: mix(P.muted, P.ink2, hl) }}>New joiners are office-based for the first thirty days, after which the standard hybrid schedule of three on-site days applies.</span>
          </div>
          <div>5.3 Full-remote arrangements require manager and People team approval.</div>
        </div>
      </div>
    </div>
  );
}

/* ── role pane (Access) ──────────────────────────────────────────────────── */
function RolePane({ T, C, data, drain }) {
  const o = MOTION.draw(0, 1, C.Access + 0.1, C.Access + 0.7)(T);
  return (
    <div style={{ position: 'absolute', left: SIDE + 32, top: BAR + 32, width: PANE.w - 64, opacity: o }}>
      <div style={{ font: '700 19px ' + FONT, letterSpacing: '0.12em', color: P.faint }}>ASKED BY {data.role}</div>
      <div style={{ display: 'inline-block', maxWidth: 640, marginTop: 16, padding: '18px 24px', background: P.wash, borderRadius: '16px 16px 16px 4px', font: '600 28px ' + FONT, color: P.ink, lineHeight: 1.4 }}>
        <Typed text={Q_ROLE} t={T} start={C.Access + 0.7} end={C.Access + 2.2} />
      </div>
      <div style={{ font: '700 19px ' + FONT, letterSpacing: '0.12em', color: P.faint, marginTop: 30 }}>ANSWER</div>
      <div style={{ font: '400 26px ' + FONT, lineHeight: 1.6, color: P.ink2, marginTop: 10, minHeight: 112 }}>
        <Typed text={data.answer} t={T} start={C.Access + 2.4} end={C.Access + 4.0} />
      </div>
      <div style={{ font: '700 19px ' + FONT, letterSpacing: '0.12em', color: P.faint, marginTop: 24 }}>SOURCES VISIBLE TO THIS ROLE</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 12 }}>
        {data.rows.map((r, i) => {
          const s = C.Access + 2.6 + i * 0.12;
          const d = drain && i >= 2 ? MOTION.draw(0, 1, C.Access + 3.6, C.Access + 4.6)(T) : 0;
          const ok = r[2] === 1 && d < 0.5 ? 1 : 0;
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', gap: 16, padding: '14px 18px', borderRadius: 12,
              background: ok ? P.surface : mix(P.surface, P.surface2, 1), border: '1px solid ' + (ok ? P.line : P.line2),
              opacity: MOTION.enter(0, 1, s, s + 0.5)(T), transform: 'translateY(' + MOTION.enter(20, 0, s, s + 0.5)(T) + 'px)',
            }}>
              <div style={{
                width: 30, height: 30, borderRadius: 999, flex: 'none',
                background: ok ? P.tint : P.border, color: ok ? P.accent : P.faint,
                display: 'flex', alignItems: 'center', justifyContent: 'center', font: '700 18px ' + FONT,
              }}>{ok ? '\u2713' : '\u2715'}</div>
              <div style={{ font: '500 24px ' + FONT, color: ok ? P.ink : P.faint, whiteSpace: 'nowrap' }}>{r[0]}</div>
              <div style={{ marginLeft: 'auto', font: '700 19px ' + FONT, color: ok ? P.deep : P.faint }}>{ok ? r[1] : 'Not visible'}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── the window itself (persistent; splits in two at Access) ─────────────── */
function Windows({ T, C, chipRef }) {
  const born = MOTION.enter(0, 1, C.Upload, C.Upload + 1.0)(T);
  const scale = 0.08 + 0.92 * born;
  const away = MOTION.draw(0, 1, C.Audience, C.Audience + 1.0)(T);
  const split = MOTION.draw(0, 1, C.Access + 0.2, C.Access + 1.6)(T) * 660;
  const bIn = MOTION.draw(0, 1, C.Access + 0.6, C.Access + 1.6)(T);
  const shell = {
    position: 'absolute', left: WIN.x, top: WIN.y, width: WIN.w, height: WIN.h,
    background: P.surface, border: '2px solid ' + P.accent, borderRadius: 22,
    boxShadow: '0 34px 80px rgba(52,40,120,0.18)', overflow: 'hidden', boxSizing: 'border-box',
  };
  const label = (t, o) => (
    <div style={{ position: 'absolute', left: 0, top: -54, font: '700 26px ' + FONT, letterSpacing: '0.16em', color: P.deep, opacity: o }}>{t}</div>
  );
  return (
    <React.Fragment>
      {/* window A — the whole demo, then FINANCE */}
      <div style={{
        position: 'absolute', left: 0, top: 0, right: 0, bottom: 0,
        transform: 'translateX(' + -split + 'px) scale(' + scale * (1 - away * 0.12) + ')',
        transformOrigin: '360px 178px', opacity: born * (1 - away),
      }}>
        <div style={shell}>
          <Chrome label="Knowra — Ask" />
          <Sidebar T={T} C={C} />
          <UploadPane T={T} C={C} />
          <ChatPane T={T} C={C} chipRef={chipRef} />
          <RolePane T={T} C={C} data={ROLE_FIN} drain={false} />
        </div>
        <div style={{ position: 'absolute', left: WIN.x, top: WIN.y }}>{label('FINANCE', split / 660)}</div>
      </div>
      {/* window B — EMPLOYEE */}
      <div style={{
        position: 'absolute', left: 0, top: 0, right: 0, bottom: 0,
        transform: 'translateX(' + split + 'px) scale(' + scale * (1 - away * 0.12) + ')',
        transformOrigin: '360px 178px', opacity: bIn * (1 - away),
      }}>
        <div style={Object.assign({}, shell, { border: '2px solid ' + P.line })}>
          <Chrome label="Knowra — Ask" />
          <Sidebar T={T} C={C} />
          <RolePane T={T} C={C} data={ROLE_EMP} drain={true} />
        </div>
        <div style={{ position: 'absolute', left: WIN.x, top: WIN.y }}>{label('EMPLOYEE', bIn)}</div>
      </div>
    </React.Fragment>
  );
}

/* ── cursor: travels to the chip, presses, and the chip becomes the viewer ─ */
function Cursor({ T, C, pt }) {
  const inn = MOTION.enter(0, 1, C.Verify, C.Verify + 0.3)(T);
  const trav = MOTION.draw(0, 1, C.Verify + 0.3, C.Verify + 2.2)(T);
  const x = 1690 + (pt.x - 1690) * trav;
  const y = 930 + (pt.y - 930) * trav;
  const press = T > C.Verify + 2.5 && T < C.Verify + 2.9 ? 1 : 0;
  const ring = MOTION.draw(0, 1, C.Verify + 2.6, C.Verify + 3.4)(T);
  const out = MOTION.draw(0, 1, C.Verify + 5.6, C.Verify + 6.4)(T);
  const fly = MOTION.draw(0, 1, C.Verify + 2.9, C.Verify + 3.7)(T);
  return (
    <React.Fragment>
      {/* the chip detaching into the viewer header */}
      <div style={{
        position: 'absolute', left: pt.x - 26 + (700 - pt.x) * fly, top: pt.y - 18 + (750 - pt.y) * fly,
        padding: '2px 10px', borderRadius: 6, background: P.deep, color: '#fff', font: '700 20px ' + FONT,
        opacity: (fly > 0.02 ? 1 : 0) * (1 - fly) * 1.0, transform: 'scale(' + (1 + fly * 1.6) + ')',
      }}>[1]</div>
      <div style={{
        position: 'absolute', left: pt.x - 34 - ring * 26, top: pt.y - 34 - ring * 26,
        width: 68 + ring * 52, height: 68 + ring * 52, borderRadius: 999,
        border: '3px solid ' + P.accent, opacity: (1 - ring) * 0.9,
      }} />
      <div style={{
        position: 'absolute', left: x, top: y, opacity: inn * (1 - out),
        transform: 'scale(' + (1 - press * 0.16) + ')', transformOrigin: '0 0',
      }}>
        <svg width="46" height="60" viewBox="0 0 46 60">
          <path d="M4 2 L4 44 L15 34 L23 52 L31 48 L23 30 L38 30 Z" fill="#ffffff" stroke="#191735" strokeWidth="3" strokeLinejoin="round" />
        </svg>
      </div>
    </React.Fragment>
  );
}

/* ── audience / ships / close ────────────────────────────────────────────── */
function Audience({ T, C }) {
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 100, top: 330, font: '700 24px ' + FONT, letterSpacing: '0.16em', color: P.muted, opacity: MOTION.enter(0, 1, C.Audience + 0.3, C.Audience + 0.9)(T) }}>WHO GETS THEIR DAY BACK</div>
      {AUDIENCE.map((a, i) => {
        const s = C.Audience + 0.9 + i * 0.26;
        return (
          <div key={i} style={{
            position: 'absolute', left: 100 + i * 440, top: 400, width: 400,
            opacity: MOTION.enter(0, 1, s, s + 0.6)(T),
            transform: 'translateY(' + MOTION.enter(46, 0, s, s + 0.8)(T) + 'px)',
          }}>
            <div style={{ height: 3, background: P.accent, transform: 'scaleX(' + MOTION.draw(0, 1, s, s + 0.7)(T) + ')', transformOrigin: 'left' }} />
            <div style={{ font: '800 74px ' + FONT, letterSpacing: '-0.035em', color: P.ink, marginTop: 26 }}>{a[0]}</div>
            <div style={{ font: '400 30px ' + FONT, lineHeight: 1.45, color: P.body, marginTop: 18, textWrap: 'pretty' }}>{a[1]}</div>
          </div>
        );
      })}
    </React.Fragment>
  );
}

function Ships({ T, C }) {
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 140, top: 270, font: '700 24px ' + FONT, letterSpacing: '0.16em', color: P.muted, opacity: MOTION.enter(0, 1, C.Ships + 0.2, C.Ships + 0.7)(T) }}>WHAT SHIPS TODAY</div>
      <div style={{ position: 'absolute', left: 140, top: 340, font: '800 60px ' + FONT, letterSpacing: '-0.035em', color: P.ink, opacity: MOTION.enter(0, 1, C.Ships + 0.3, C.Ships + 0.9)(T) }}>Six things you can actually use.</div>
      {SHIPS.map((s, i) => {
        const t0 = C.Ships + 1.2 + i * 0.11;
        const col = i % 3, row = Math.floor(i / 3);
        const on = T >= t0 ? 1 : 0;
        return (
          <div key={i} style={{ position: 'absolute', left: 140 + col * 560, top: 470 + row * 190, width: 520 }}>
            <div style={{ height: 2, background: P.rule, transform: 'scaleX(' + MOTION.draw(0, 1, t0, t0 + 0.5)(T) + ')', transformOrigin: 'left' }} />
            <div style={{ font: '700 21px ' + FONT, color: P.accent, marginTop: 18, opacity: on }}>0{i + 1}</div>
            <div style={{ font: '700 40px ' + FONT, letterSpacing: '-0.03em', color: P.ink, marginTop: 8, opacity: on }}>{s}</div>
          </div>
        );
      })}
    </React.Fragment>
  );
}

function Close({ T, C }) {
  const flood = MOTION.draw(0, 1, C.Close, C.Close + 0.9)(T);
  const a = MOTION.enter(0, 1, C.Close + 0.7, C.Close + 1.4)(T);
  const b = MOTION.enter(0, 1, C.Close + 1.5, C.Close + 2.2)(T);
  const c = MOTION.enter(0, 1, C.Close + 2.4, C.Close + 3.1)(T);
  return (
    <React.Fragment>
      <div style={{ position: 'absolute', left: 0, top: 0, width: 1920, height: 1080, background: P.accent, clipPath: 'inset(' + (50 - flood * 50) + '% ' + (50 - flood * 50) + '% ' + (50 - flood * 50) + '% ' + (50 - flood * 50) + '%)' }} />
      <div style={{ position: 'absolute', left: 160, top: 300, width: 1500, opacity: a, transform: 'translateY(' + MOTION.enter(34, 0, C.Close + 0.7, C.Close + 1.4)(T) + 'px)', font: '800 130px ' + FONT, lineHeight: 1.02, letterSpacing: '-0.045em', color: '#fff' }}>
        Stop searching.<br />Start asking.
      </div>
      <div style={{ position: 'absolute', left: 160, top: 620, width: 1060, opacity: b, transform: 'translateY(' + MOTION.enter(26, 0, C.Close + 1.5, C.Close + 2.2)(T) + 'px)', font: '500 36px ' + FONT, lineHeight: 1.5, color: '#efe7ff' }}>
        Open the demo workspace, ask it something, and click a citation.
      </div>
      <div style={{ position: 'absolute', left: 160, top: 850, display: 'flex', alignItems: 'center', gap: 20, opacity: c }}>
        <div style={{ width: 56, height: 56, background: '#fff', borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', font: '800 32px ' + FONT, color: P.accent }}>K</div>
        <div style={{ font: '800 44px ' + FONT, letterSpacing: '-0.03em', color: '#fff' }}>Knowra</div>
        <div style={{ marginLeft: 24, paddingLeft: 24, borderLeft: '2px solid rgba(255,255,255,0.4)', font: '500 26px ' + FONT, color: '#e2d5ff' }}>Demo deployment — not a commercial service.</div>
      </div>
    </React.Fragment>
  );
}

/* ── the piece ───────────────────────────────────────────────────────────── */
function Film() {
  const { T, CUES: C } = useComposition();
  const chipRef = React.useRef(null);
  const rootRef = React.useRef(null);
  const [pt, setPt] = React.useState({ x: 1042, y: 470 });

  React.useLayoutEffect(() => {
    const measure = () => {
      const el = chipRef.current, root = rootRef.current;
      if (!el || !root) return;
      let x = 0, y = 0, n = el;
      while (n && n !== root) { x += n.offsetLeft; y += n.offsetTop; n = n.offsetParent; }
      if (!x && !y) return;
      setPt({ x: x + el.offsetWidth / 2, y: y + el.offsetHeight / 2 });
    };
    measure();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(measure);
    const id = setTimeout(measure, 400);
    return () => clearTimeout(id);
  }, []);

  /* camera — three moves and a slow drift, nothing else */
  const keys = [0, C.Scatter, C.Stranger, C.Reveal, C.Upload, C.Ask, C.Ask + 2, C.Answer, C.Verify, C.Verify + 3, C.Verify + 9, C.Access + 3, C.Audience, C.Audience + 2, 80];
  const s = interpolate(keys, [1, 1, 1.03, 1.0, 1.0, 1.05, 1.14, 1.16, 1.20, 1.34, 1.30, 0.58, 0.58, 1.0, 1.0], Easing.easeInOutCubic)(T);
  const fx = interpolate(keys, [960, 960, 960, 960, 960, 1000, 1060, 1070, 1080, 1120, 1110, 960, 960, 960, 960], Easing.easeInOutCubic)(T);
  const fy = interpolate(keys, [540, 540, 540, 540, 540, 520, 480, 500, 560, 620, 760, 540, 540, 540, 540], Easing.easeInOutCubic)(T);

  return (
    <div ref={rootRef} data-screen-label={Math.floor(T) + 's'} style={{
      position: 'absolute', inset: 0, width: 1920, height: 1080, overflow: 'hidden',
      background: P.bg, fontFamily: FONT,
    }}>
      {/* hero wash, always present, always drifting */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(900px 480px at ' + (12 + Math.sin(T * 0.09) * 4) + '% 22%, rgba(124,58,237,0.16), transparent 60%), radial-gradient(760px 420px at ' + (88 - Math.sin(T * 0.07) * 4) + '% 8%, rgba(167,139,250,0.15), transparent 60%)',
        opacity: 1 - MOTION.draw(0, 1, C.Close, C.Close + 0.9)(T),
      }} />
      <div style={{ position: 'absolute', inset: 0, transformOrigin: '0px 0px', transform: 'translate(960px,540px) scale(' + s + ') translate(' + -fx + 'px,' + -fy + 'px)' }}>
        <Shot from={0} to={C.Upload + 1.2}>
          {TILES.map((tl, i) => <Tile key={i} tile={tl} i={i} T={T} C={C} />)}
        </Shot>
        <Shot from={C.Stranger} to={C.Reveal}><Stranger T={T} C={C} /></Shot>
        <Shot from={0} to={C.Audience + 1.2}><Question T={T} C={C} /></Shot>
        <Shot from={C.Upload} to={C.Audience + 1.2}><Windows T={T} C={C} chipRef={chipRef} /></Shot>
        <Shot from={C.Reveal + 1.6} to={C.Audience}><Mark T={T} C={C} /></Shot>
        <Shot from={C.Verify} to={C.Access}><Cursor T={T} C={C} pt={pt} /></Shot>
        <Shot from={C.Audience} to={C.Ships}><Audience T={T} C={C} /></Shot>
        <Shot from={C.Ships} to={C.Close + 0.6}><Ships T={T} C={C} /></Shot>
        <Shot from={C.Close} to={999}><Close T={T} C={C} /></Shot>
      </div>
      <Captions style={{
        left: 100, right: 'auto', bottom: 48, textAlign: 'left', display: 'inline-block',
        font: '700 30px ' + FONT, color: P.deep, textShadow: 'none', letterSpacing: '0.02em',
        background: 'rgba(253,252,250,0.94)', padding: '12px 20px 12px 18px',
        borderLeft: '4px solid ' + P.accent, backdropFilter: 'blur(4px)',
      }} items={[
        { at: 4.6, until: 8.8, text: 'It is written down. Somewhere.' },
        { at: 10.2, until: 13.6, text: 'Generic AI has never read your handbook — and will still answer confidently.' },
        { at: 20.6, until: 25.6, text: '01 — Upload knowledge' },
        { at: 26.4, until: 32.6, text: '02 — Ask naturally' },
        { at: 33.4, until: 40.6, text: '03 — Get grounded answers, only from your own documents' },
        { at: 41.4, until: 49.6, text: '04 — Verify the source' },
        { at: 50.4, until: 56.6, text: '05 — The same question returns different sources' },
      ]} />
    </div>
  );
}

function KnowraPromoFilm() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} bg={P.bg}
        scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Film />
      </CompositionStage>
      <window.TweaksPanel title="Launch film">
        <window.TweakSection label="Review">
          <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

window.KnowraPromoFilm = KnowraPromoFilm;

// Knowra 04 — Who it's for, and what it won't do. 41s.
// Brand layer (Archivo + the industry hue system) with small product cards inside it.

const P = { bg: '#12141f', text: '#e9e9ed', dim: '#a5a7b6', mid: '#8b8d9c' };
const K = {
  surface: '#1c1930', surface2: '#211d36', panel: '#231f3c',
  ink: '#f4f2ff', ink2: '#e4e0f6', body: '#a8a3c6', muted: '#8d88ac', faint: '#7b769a',
  border: '#2e2947', rule: '#282340', accent: '#7c3aed', soft: '#a78bfa', ok: '#34d399', bad: '#f87171',
};
const DISP = "'Archivo', system-ui, sans-serif";
const APP = "'Plus Jakarta Sans', system-ui, sans-serif";
const MONO = "'Chivo Mono', ui-monospace, monospace";
const HUES = { emp: 172, hr: 62, fin: 250, adm: 285 };
const HU = (h, a) => 'oklch(0.74 0.15 ' + h + (a == null ? '' : ' / ' + a) + ')';
const px = (n) => n + 'px';
const wdth = (w) => "'wdth' " + w;
const MOTION = { enter: Easing.easeOutQuart, draw: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const inOut = (T, a, b, rise, fall) => Math.min(
  animate({ from: 0, to: 1, start: a, end: a + rise, ease: MOTION.enter })(T),
  animate({ from: 1, to: 0, start: b - fall, end: b, ease: MOTION.draw })(T)
);
const ramp = (T, a, b, ease) => animate({ from: 0, to: 1, start: a, end: b, ease: ease || MOTION.draw })(T);
const SPECTRUM = 'linear-gradient(90deg,' + [HUES.emp, HUES.hr, HUES.fin, HUES.adm].map((h) => HU(h)).join(',') + ')';

function Mark({ size, hue, grow }) {
  const s = size, g = grow == null ? 1 : grow;
  return (
    <div style={{ position: 'relative', width: px(s), height: px(s), borderRadius: px(s * 0.24), border: '2px solid ' + HU(hue, 0.45) }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{
          position: 'absolute', left: px(s * 0.16), top: px(s * (0.2 + i * 0.24)),
          width: px(s * (0.68 - i * 0.16) * clamp(g * 1.6 - i * 0.3, 0, 1)), height: px(s * 0.11),
          borderRadius: px(s * 0.055), background: HU(hue), boxShadow: '0 0 ' + px(s * 0.3) + ' ' + HU(hue, 0.4),
        }} />
      ))}
    </div>
  );
}

// ── the four roles ────────────────────────────────────────────────────────
const ROLES = [
  { who: 'Employees', hue: HUES.emp, line: 'Ask the handbook instead of asking a colleague.',
    q: 'How many days of leave do I have left this year?', a: 'Answered from the leave policy, with the accrual table cited by page.', src: 'Leave Policy.pdf · page 3' },
  { who: 'HR', hue: HUES.hr, line: 'Answer the same policy question once, not forty times.',
    q: 'What does the policy say about working abroad?', a: 'Answered from the remote work policy, including the approval path.', src: 'Remote Work Policy.pdf · page 5' },
  { who: 'Finance', hue: HUES.fin, line: 'Pull figures from reports only your team can open.',
    q: 'What was contractor spend last quarter?', a: 'Answered from finance reports that only the Finance role can open.', src: 'Q3 Contractor Spend.xlsx · page 4' },
  { who: 'Admins', hue: HUES.adm, line: 'Manage users, roles and what each document exposes.',
    q: 'Who has access to the personnel files?', a: 'Answered from the access configuration, with the role list shown.', src: 'Access configuration · live' },
];

function RolesBeat({ T, C }) {
  const o = inOut(T, C.Roles - 0.2, C.Same + 0.5, 0.5, 0.4);
  const head = inOut(T, C.Roles + 0.1, C.Same - 0.1, 0.6, 0.35);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{
        position: 'absolute', left: 150, top: 130, opacity: head,
        font: '400 24px ' + MONO, letterSpacing: '0.22em', color: P.mid,
      }}>ONE TOOL, FOUR JOBS</div>

      {ROLES.map((r, i) => {
        const a = C.Roles + 0.5 + i * 4.0;
        const end = i === 3 ? C.Same + 0.3 : a + 3.75;
        const op = inOut(T, a - 0.35, end, 0.35, 0.35);
        const x = animate({ from: 46, to: 0, start: a - 0.35, end: a + 0.55, ease: MOTION.enter })(T)
          + animate({ from: 0, to: -110, start: end - 0.4, end: end, ease: MOTION.draw })(T);
        const card = ramp(T, a + 0.5, a + 1.2, MOTION.enter);
        const ans = ramp(T, a + 1.3, a + 2.1, MOTION.enter);
        const cite = ramp(T, a + 2.2, a + 2.9, MOTION.enter);
        return (
          <div key={r.who} style={{ position: 'absolute', inset: 0, opacity: op }}>
            <div style={{ position: 'absolute', left: 150, top: 300, width: 720, transform: 'translateX(' + px(x) + ')' }}>
              <div style={{
                font: '600 108px ' + DISP, fontVariationSettings: wdth(86),
                letterSpacing: '-0.035em', lineHeight: 1, color: HU(r.hue),
              }}>{r.who}</div>
              <div style={{
                marginTop: 30, font: '400 40px ' + DISP, fontVariationSettings: wdth(94),
                lineHeight: 1.3, color: P.text, textWrap: 'pretty',
              }}>{r.line}</div>
            </div>

            <div style={{
              position: 'absolute', left: 1010, top: 268, width: 760, opacity: card,
              transform: 'translate(' + px(x * 0.6) + ',' + px(20 - 20 * card) + ')',
              padding: 34, borderRadius: 18, background: K.surface,
              border: '1px solid ' + K.border, boxShadow: '0 30px 70px rgba(0,0,0,0.45)', fontFamily: APP,
            }}>
              <div style={{
                marginLeft: 'auto', width: 'fit-content', maxWidth: 600, padding: '16px 22px',
                borderRadius: '14px 14px 4px 14px', background: HU(r.hue, 0.9),
                font: '500 26px ' + APP, lineHeight: 1.3, color: '#14121f',
              }}>{r.q}</div>
              <div style={{
                marginTop: 20, opacity: ans, padding: '20px 22px', borderRadius: 14,
                background: K.panel, border: '1px solid ' + K.border,
                font: '500 26px ' + APP, lineHeight: 1.5, color: K.ink2,
              }}>{r.a}</div>
              <div style={{
                marginTop: 16, opacity: cite, display: 'flex', alignItems: 'center', gap: 14,
                padding: '14px 20px', borderRadius: 12, background: K.surface2, border: '1px solid ' + K.border,
              }}>
                <div style={{ font: '700 24px ' + MONO, color: HU(r.hue) }}>[1]</div>
                <div style={{ font: '600 24px ' + APP, color: K.ink }}>{r.src}</div>
              </div>
            </div>
          </div>
        );
      })}

      <div style={{ position: 'absolute', left: 150, top: 880, display: 'flex', gap: 14, opacity: head }}>
        {ROLES.map((r, i) => {
          const act = clamp(Math.floor((T - C.Roles - 0.15) / 4.0), 0, 3);
          return <div key={r.who} style={{ width: 150, height: 4, borderRadius: 2, background: HU(r.hue, i === act ? 1 : 0.18) }} />;
        })}
      </div>
    </div>
  );
}

// ── one question, four answers ────────────────────────────────────────────
const COLS = [
  { role: 'EMPLOYEE', hue: HUES.emp, verdict: 'No authorised source. It does not answer.',
    src: [['Employee Handbook.pdf', 1], ['Remote Work Policy.pdf', 1], ['Q3 Contractor Spend.xlsx', 0], ['Vendor Contracts 2026.pdf', 0]] },
  { role: 'HR', hue: HUES.hr, verdict: '14 contractors. No cost figures.',
    src: [['Contractor Roster Q3.docx', 1], ['Employee Handbook.pdf', 1], ['Q3 Contractor Spend.xlsx', 0], ['Vendor Contracts 2026.pdf', 0]] },
  { role: 'FINANCE', hue: HUES.fin, verdict: '$412,800, up 9% on Q2.',
    src: [['Q3 Contractor Spend.xlsx', 2], ['Vendor Contracts 2026.pdf', 2], ['Employee Handbook.pdf', 1], ['Personnel Files.pdf', 0]] },
  { role: 'ADMIN', hue: HUES.adm, verdict: '$412,800 — and who else can see it.',
    src: [['Q3 Contractor Spend.xlsx', 2], ['Vendor Contracts 2026.pdf', 2], ['Contractor Roster Q3.docx', 2], ['Retrieval audit log', 1]] },
];

function SameBeat({ T, C }) {
  const o = inOut(T, C.Same - 0.7, C.Wont + 0.2, 0.5, 0.4);
  const q = ramp(T, C.Same - 0.5, C.Same + 0.3, MOTION.enter);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o }}>
      <div style={{
        position: 'absolute', left: 100, top: 118, font: '400 24px ' + MONO, letterSpacing: '0.22em', color: P.mid,
        opacity: ramp(T, C.Same - 0.05, C.Same + 0.45, MOTION.enter),
      }}>
        THE SAME QUESTION, FOUR PEOPLE
      </div>
      <div style={{
        position: 'absolute', left: 100, top: 178, width: 1720, opacity: q,
        transform: 'translateY(' + px(14 - 14 * q) + ')',
        font: '500 58px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.025em', color: P.text,
      }}>“How much did we spend on contractors last quarter?”</div>

      {COLS.map((c, i) => {
        const a = C.Same + 1.2 + i * 0.5;
        const op = ramp(T, a, a + 0.6, MOTION.enter);
        const y = animate({ from: 26, to: 0, start: a, end: a + 0.8, ease: MOTION.enter })(T);
        return (
          <div key={c.role} style={{
            position: 'absolute', left: px(100 + i * 430), top: 300, width: 410,
            opacity: op, transform: 'translateY(' + px(y) + ')', fontFamily: APP,
          }}>
            <div style={{ font: '400 24px ' + MONO, letterSpacing: '0.18em', color: HU(c.hue), marginBottom: 18 }}>{c.role}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {c.src.map(([name, state], j) => {
                const shown = ramp(T, a + 0.3 + j * 0.16, a + 0.7 + j * 0.16, MOTION.enter);
                const blocked = state === 0;
                return (
                  <div key={name} style={{
                    opacity: shown, display: 'flex', alignItems: 'center', gap: 12,
                    padding: '15px 16px', borderRadius: 11,
                    background: blocked ? 'rgba(255,255,255,0.02)' : K.surface,
                    border: '1px solid ' + (blocked ? K.rule : state === 2 ? HU(c.hue, 0.45) : K.border),
                  }}>
                    <div style={{
                      width: 26, height: 26, flex: 'none', borderRadius: 13, display: 'flex', alignItems: 'center', justifyContent: 'center',
                      background: blocked ? 'rgba(248,113,113,0.16)' : HU(c.hue, 0.18),
                      font: '700 18px ' + APP, color: blocked ? K.bad : HU(c.hue),
                    }}>{blocked ? '✕' : '✓'}</div>
                    <div style={{
                      flex: 1, minWidth: 0, font: '600 24px ' + APP, whiteSpace: 'nowrap',
                      overflow: 'hidden', textOverflow: 'ellipsis', color: blocked ? K.faint : K.ink,
                    }}>{name}</div>
                  </div>
                );
              })}
            </div>
            <div style={{
              marginTop: 20, opacity: ramp(T, a + 1.4, a + 2.0, MOTION.enter),
              padding: '18px 20px', borderRadius: 12, background: HU(c.hue, 0.1), border: '1px solid ' + HU(c.hue, 0.3),
              font: '600 25px ' + APP, lineHeight: 1.35, color: K.ink,
            }}>{c.verdict}</div>
          </div>
        );
      })}

      <div style={{
        position: 'absolute', left: 100, top: 900, width: 1720,
        opacity: ramp(T, C.Same + 6.4, C.Same + 7.2, MOTION.enter),
        font: '400 38px ' + DISP, fontVariationSettings: wdth(94), color: P.dim,
      }}>Same question. Same product. Four different sets of evidence.</div>
    </div>
  );
}

// ── what it won't do ──────────────────────────────────────────────────────
const WONT = [
  ['It will not answer without a source.', 'If nothing authorised is found, it says so.'],
  ['It will not read what you cannot.', 'Permissions are applied before retrieval, not after.'],
  ['It will not train a public model on your files.', 'Your documents are indexed inside your own deployment.'],
];

function WontBeat({ T, C }) {
  const o = inOut(T, C.Wont - 0.2, C.Close + 0.05, 0.5, 0.4);
  const ex = ramp(T, C.Close - 0.6, C.Close + 0.05, MOTION.draw);
  return (
    <div style={{ position: 'absolute', inset: 0, opacity: o, transform: 'translateY(' + px(-620 * ex) + ')' }}>
      <div style={{ position: 'absolute', left: 150, top: 150, font: '400 24px ' + MONO, letterSpacing: '0.22em', color: P.mid }}>
        AND WHAT IT WILL NOT DO
      </div>
      {WONT.map((w, i) => {
        const a = C.Wont + 0.6 + i * 1.9;
        const op = ramp(T, a, a + 0.7, MOTION.enter);
        const x = animate({ from: 40, to: 0, start: a, end: a + 0.8, ease: MOTION.enter })(T);
        const bar = ramp(T, a + 0.2, a + 1.0);
        return (
          <div key={w[0]} style={{
            position: 'absolute', left: 150, top: px(300 + i * 196), width: 1620,
            opacity: op, transform: 'translateX(' + px(x) + ')',
          }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', gap: 34 }}>
              <div style={{
                width: 56, height: 56, flex: 'none', borderRadius: 14, marginTop: 6,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: 'rgba(248,113,113,0.14)', border: '1px solid rgba(248,113,113,0.4)',
                font: '700 30px ' + APP, color: K.bad,
              }}>✕</div>
              <div>
                <div style={{
                  font: '500 56px ' + DISP, fontVariationSettings: wdth(90),
                  letterSpacing: '-0.02em', lineHeight: 1.1, color: P.text,
                }}>{w[0]}</div>
                <div style={{ marginTop: 14, font: '400 32px ' + DISP, fontVariationSettings: wdth(96), color: P.dim }}>{w[1]}</div>
                <div style={{ marginTop: 22, width: px(1200 * bar), height: 2, background: 'rgba(233,233,237,0.12)' }} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ── chrome ────────────────────────────────────────────────────────────────
function Title({ T, C }) {
  const o = inOut(T, 0.2, C.Roles + 0.3, 0.7, 0.5);
  const g = ramp(T, 0.3, 1.4, MOTION.enter);
  const w = interpolate([0.6, 2.6], [72, 100], MOTION.draw)(T);
  const rule = ramp(T, 1.3, 2.8);
  return (
    <div style={{ position: 'absolute', left: 150, top: 400, opacity: o }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        <Mark size={130} hue={HUES.adm} grow={g} />
        <div>
          <div style={{ font: '400 26px ' + MONO, letterSpacing: '0.24em', color: HU(HUES.adm) }}>04</div>
          <div style={{
            marginTop: 12, font: '600 132px ' + DISP, fontVariationSettings: wdth(w),
            letterSpacing: '-0.04em', lineHeight: 0.95, color: P.text,
          }}>Who it’s for</div>
        </div>
      </div>
      <div style={{ marginTop: 40, width: px(1180 * rule), height: 4, borderRadius: 2, background: SPECTRUM }} />
    </div>
  );
}

function Close({ T, C }) {
  const a = C.Close - 0.45;
  const o = ramp(T, a, a + 0.9, MOTION.enter);
  const rise = animate({ from: 140, to: 0, start: a, end: a + 1.1, ease: MOTION.enter })(T);
  const g = ramp(T, a + 0.1, a + 1.1, MOTION.enter);
  const rule = ramp(T, a + 0.8, a + 2.0);
  const set = ramp(T, a + 1.6, a + 2.4, MOTION.enter);
  const line = ramp(T, a + 2.6, a + 3.5, MOTION.enter);
  const ly = animate({ from: 20, to: 0, start: a + 2.6, end: a + 3.6, ease: MOTION.enter })(T);
  return (
    <div style={{ position: 'absolute', left: 150, top: 330, opacity: o, transform: 'translateY(' + px(rise) + ')' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        <Mark size={140} hue={HUES.adm} grow={g} />
        <div style={{ font: '600 150px ' + DISP, fontVariationSettings: wdth(100), letterSpacing: '-0.045em', lineHeight: 0.92, color: P.text }}>Knowra</div>
      </div>
      <div style={{ marginTop: 44, width: px(1180 * rule), height: 4, borderRadius: 2, background: SPECTRUM }} />
      <div style={{
        marginTop: 42, opacity: line, transform: 'translateY(' + px(ly) + ')', width: 1500,
        font: '400 44px ' + DISP, fontVariationSettings: wdth(94), lineHeight: 1.3, color: P.text, textWrap: 'pretty',
      }}>Every industry that runs on documents. Every role that has to ask.</div>
      <div style={{ marginTop: 46, opacity: set, display: 'flex', gap: 34, font: '400 30px ' + MONO, letterSpacing: '0.16em', color: P.mid }}>
        {['01 TRAILER', '02 HOW IT WORKS', '03 USING KNOWRA', '04 WHO IT’S FOR'].map((t, i) => (
          <span key={t} style={{ color: i === 3 ? HU(HUES.adm) : P.mid }}>{t}</span>
        ))}
      </div>
    </div>
  );
}

function Film() {
  const { T, CUES: C } = useComposition();
  let hue = HUES.adm;
  if (T >= C.Roles && T < C.Same) {
    hue = ROLES[clamp(Math.floor((T - C.Roles - 0.15) / 4.0), 0, 3)].hue;
  }
  return (
    <div style={{ position: 'absolute', inset: 0, background: P.bg, overflow: 'hidden', fontFamily: DISP, color: P.text }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(1300px 900px at 26% 45%, ' + HU(hue, 0.13) + ', rgba(0,0,0,0) 72%)' }} />
      <Shot from={0} to={C.Roles + 0.6}><Title T={T} C={C} /></Shot>
      <Shot from={C.Roles - 0.4} to={C.Same + 0.7}><RolesBeat T={T} C={C} /></Shot>
      <Shot from={C.Same - 0.9} to={C.Wont + 0.4}><SameBeat T={T} C={C} /></Shot>
      <Shot from={C.Wont - 0.4} to={C.Close + 1.1}><WontBeat T={T} C={C} /></Shot>
      <Shot from={C.Close - 1.0} to={999}><Close T={T} C={C} /></Shot>
    </div>
  );
}

function Knowra04() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} bg={P.bg} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Film />
      </CompositionStage>
      <window.TweaksPanel title="04 Who it’s for">
        <window.TweakSection label="Look">
          <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

window.Knowra04 = Knowra04;

// Knowra 02 — How it works. 55s.
// Chrome (titles, kicker, lockup) is brand: Archivo + the trailer's hue system.
// Everything inside the window is product-true: the app's own violet and Plus Jakarta Sans.
// Concept level only: no chunking, embedding, vector store or model vendor named.

const P = { bg: '#12141f', text: '#e9e9ed', dim: '#a5a7b6', mid: '#8b8d9c' };
const K = {
  bg: '#14121f', surface: '#1c1930', surface2: '#211d36', panel: '#231f3c',
  ink: '#f4f2ff', ink2: '#e4e0f6', body: '#a8a3c6', muted: '#8d88ac', faint: '#7b769a',
  border: '#2e2947', rule: '#282340', accent: '#7c3aed', soft: '#a78bfa',
  tint: 'rgba(124,58,237,0.20)', hi: 'rgba(124,58,237,0.34)',
  ok: '#34d399', bad: '#f87171',
};
const DISP = "'Archivo', system-ui, sans-serif";
const APP = "'Plus Jakarta Sans', system-ui, sans-serif";
const MONO = "'Chivo Mono', ui-monospace, monospace";
const HUE = 285;
const HU = (h, a) => 'oklch(0.74 0.15 ' + h + (a == null ? '' : ' / ' + a) + ')';
const px = (n) => n + 'px';
const wdth = (w) => "'wdth' " + w;
const MOTION = { enter: Easing.easeOutQuart, draw: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const inOut = (T, a, b, rise, fall) => Math.min(
  animate({ from: 0, to: 1, start: a, end: a + rise, ease: MOTION.enter })(T),
  animate({ from: 1, to: 0, start: b - fall, end: b, ease: MOTION.draw })(T)
);
const ramp = (T, a, b, ease) => animate({ from: 0, to: 1, start: a, end: b, ease: ease || MOTION.draw })(T);
const cut = (s, p) => (
  <span>{s.slice(0, Math.floor(p * s.length))}
    <span style={{ visibility: 'hidden' }}>{s.slice(Math.floor(p * s.length))}</span>
  </span>
);

// window geometry
const WX = 150, WY = 140, WW = 1620, WH = 690, BAR = 56, SBW = 300;
const MX = WX + SBW, MY = WY + BAR, MW = WW - SBW, MH = WH - BAR;

const NAV = [
  { group: 'WORKSPACE', items: [['dashboard', 'Dashboard'], ['chat', 'Chat'], ['documents', 'Documents']] },
  { group: 'MANAGE', items: [['uploads', 'Upload Center'], ['collections', 'Collections'], ['users', 'Users']] },
];

function Mark({ size, hue, grow }) {
  const s = size, g = grow == null ? 1 : grow;
  return (
    <div style={{ position: 'relative', width: px(s), height: px(s), borderRadius: px(s * 0.24), border: '2px solid ' + HU(hue, 0.45) }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{
          position: 'absolute', left: px(s * 0.16), top: px(s * (0.2 + i * 0.24)),
          width: px(s * (0.68 - i * 0.16) * clamp(g * 1.6 - i * 0.3, 0, 1)), height: px(s * 0.11),
          borderRadius: px(s * 0.055), background: HU(hue),
          boxShadow: '0 0 ' + px(s * 0.3) + ' ' + HU(hue, 0.4),
        }} />
      ))}
    </div>
  );
}

// ── the window, held for the whole film so the product never restages ─────
function AppShell({ T, C, active }) {
  const o = inOut(T, C.Ingest - 0.6, 999, 0.8, 0.4);
  const y = animate({ from: 30, to: 0, start: C.Ingest - 0.6, end: C.Ingest + 0.4, ease: MOTION.enter })(T);
  const out = ramp(T, C.Closed + 5.2, C.Closed + 6.2, MOTION.draw);
  return (
    <div style={{
      position: 'absolute', left: px(WX), top: px(WY), width: px(WW), height: px(WH),
      opacity: o * (1 - out), transform: 'translateY(' + px(y) + ') scale(' + (1 - 0.04 * out) + ')',
      borderRadius: 22, overflow: 'hidden', background: K.surface,
      border: '1px solid ' + K.border, boxShadow: '0 40px 100px rgba(0,0,0,0.55)', fontFamily: APP,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, height: px(BAR), padding: '0 24px', background: K.surface2, borderBottom: '1px solid ' + K.rule }}>
        {['#ff5f57', '#febc2e', '#28c840'].map((c) => <div key={c} style={{ width: 12, height: 12, borderRadius: 6, background: c }} />)}
        <div style={{ marginLeft: 10, font: '700 24px ' + APP, color: K.muted }}>Knowra</div>
      </div>
      <div style={{ display: 'flex', height: px(WH - BAR) }}>
        <div style={{ width: px(SBW), padding: '26px 20px', background: K.surface2, borderRight: '1px solid ' + K.rule }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 30 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: K.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', font: '800 22px ' + APP, color: '#fff' }}>K</div>
            <div style={{ font: '800 24px ' + APP, letterSpacing: '-0.03em', color: K.ink }}>Knowra</div>
          </div>
          {NAV.map((g) => (
            <div key={g.group} style={{ marginBottom: 26 }}>
              <div style={{ font: '700 20px ' + APP, letterSpacing: '0.12em', color: K.faint, marginBottom: 12 }}>{g.group}</div>
              {g.items.map(([id, label]) => {
                const on = id === active;
                return (
                  <div key={id} style={{
                    display: 'flex', alignItems: 'center', gap: 12, padding: '11px 14px', marginBottom: 4, borderRadius: 10,
                    background: on ? K.tint : 'transparent',
                    font: (on ? '700 23px ' : '500 23px ') + APP, color: on ? K.soft : K.body,
                  }}>
                    <div style={{ width: 8, height: 8, borderRadius: 4, background: on ? K.soft : K.border }} />{label}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
        <div style={{ position: 'relative', width: px(MW), height: px(MH), background: K.surface }} />
      </div>
    </div>
  );
}

function Pane({ children, style }) {
  return (
    <div style={{
      position: 'absolute', left: px(MX), top: px(MY), width: px(MW), height: px(MH),
      overflow: 'hidden', fontFamily: APP, ...style,
    }}>{children}</div>
  );
}

function PaneHead({ title, sub }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ font: '800 36px ' + APP, letterSpacing: '-0.025em', color: K.ink }}>{title}</div>
      <div style={{ marginTop: 8, font: '500 24px ' + APP, color: K.muted }}>{sub}</div>
    </div>
  );
}

// ── 01 ingest ─────────────────────────────────────────────────────────────
const FILES = [
  ['Employee Handbook.pdf', '2.4 MB', 84],
  ['Remote Work Policy.pdf', '640 KB', 12],
  ['Q3 Contractor Spend.xlsx', '1.1 MB', 26],
  ['Vendor Contracts 2026.pdf', '3.8 MB', 148],
  ['Onboarding Handbook.docx', '890 KB', 41],
];

function IngestPane({ T, C }) {
  const o = inOut(T, C.Ingest - 0.1, C.Read + 0.3, 0.5, 0.5);
  const docs = Math.round(interpolate([C.Ingest + 2.2, C.Ingest + 6.4], [8, 33], MOTION.draw)(T));
  const pages = Math.round(interpolate([C.Ingest + 2.2, C.Ingest + 6.8], [220, 1412], MOTION.draw)(T));
  return (
    <Pane style={{ opacity: o, padding: '34px 40px' }}>
      <PaneHead title="Upload Center" sub="PDF, DOCX and TXT. One file or a folder of them." />
      <div style={{ display: 'flex', gap: 16, marginBottom: 22 }}>
        {[['Documents', docs], ['Pages indexed', pages.toLocaleString()]].map((k) => (
          <div key={k[0]} style={{ flex: 1, padding: '16px 24px', borderRadius: 14, background: K.surface2, border: '1px solid ' + K.border }}>
            <div style={{ font: '800 38px ' + APP, letterSpacing: '-0.03em', color: K.ink }}>{k[1]}</div>
            <div style={{ marginTop: 6, font: '600 24px ' + APP, color: K.muted }}>{k[0]}</div>
          </div>
        ))}
        <div style={{ flex: 1.4, padding: '16px 24px', borderRadius: 14, background: K.tint, border: '1px dashed ' + K.soft, display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ font: '800 30px ' + APP, color: K.soft }}>+</div>
          <div style={{ font: '600 24px ' + APP, lineHeight: 1.35, color: K.ink2 }}>Drop files here.<br />The original is kept.</div>
        </div>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {FILES.map((f, i) => {
          const a = C.Ingest + 1.1 + i * 0.62;
          const op = ramp(T, a, a + 0.4, MOTION.enter);
          const x = animate({ from: 40, to: 0, start: a, end: a + 0.5, ease: MOTION.enter })(T);
          const prog = ramp(T, a + 0.35, a + 1.5);
          const done = prog > 0.999;
          return (
            <div key={i} style={{
              opacity: op, transform: 'translateX(' + px(x) + ')',
              display: 'flex', alignItems: 'center', gap: 18, padding: '14px 22px', borderRadius: 12,
              background: K.surface2, border: '1px solid ' + (done ? 'rgba(52,211,153,0.35)' : K.border),
            }}>
              <div style={{ width: 12, height: 12, borderRadius: 3, background: done ? K.ok : K.soft }} />
              <div style={{ flex: 1, font: '600 26px ' + APP, color: K.ink }}>{f[0]}</div>
              <div style={{ font: '500 24px ' + APP, color: K.faint }}>{f[1]}</div>
              <div style={{ width: 200, height: 8, borderRadius: 4, background: K.rule, overflow: 'hidden' }}>
                <div style={{ width: px(200 * prog), height: 8, borderRadius: 4, background: done ? K.ok : K.accent }} />
              </div>
              <div style={{ width: 156, textAlign: 'right', font: '700 24px ' + APP, color: done ? K.ok : K.soft }}>
                {done ? 'Ready' : 'Reading'}
              </div>
            </div>
          );
        })}
      </div>
    </Pane>
  );
}

// ── 02 read: pages become findable, the original stays ────────────────────
function ReadPane({ T, C }) {
  const o = inOut(T, C.Read - 0.1, C.Ask + 0.3, 0.5, 0.5);
  const fan = ramp(T, C.Read + 0.5, C.Read + 2.2, MOTION.enter);
  const lift = ramp(T, C.Read + 2.4, C.Read + 4.4, MOTION.draw);
  const HITS = [['page 5', 'Onboarding period'], ['page 12', 'Hybrid schedule'], ['page 18', 'Approval path']];
  return (
    <Pane style={{ opacity: o, padding: '34px 40px' }}>
      <PaneHead title="Remote Work Policy.pdf" sub="Every page read. Nothing rewritten." />
      <div style={{ display: 'flex', gap: 44 }}>
        <div style={{ position: 'relative', width: 500, height: 420 }}>
          {[3, 2, 1, 0].map((i) => (
            <div key={i} style={{
              position: 'absolute', left: px(i * 26 * fan), top: px(i * 16 * fan),
              width: 300, height: 400, borderRadius: 12, background: i === 0 ? K.panel : K.surface2,
              border: '1px solid ' + K.border, padding: 26, boxShadow: '0 20px 40px rgba(0,0,0,0.3)',
              opacity: i === 0 ? 1 : 0.35 + 0.2 * fan,
            }}>
              {i === 0 ? (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                  {[0.9, 1, 0.75, 1, 0.55].map((w, j) => (
                    <div key={j} style={{
                      height: 12, width: (w * 100) + '%', borderRadius: 6,
                      background: j === 2 ? 'rgba(124,58,237,' + (0.25 + 0.6 * lift) + ')' : K.rule,
                    }} />
                  ))}
                  <div style={{ marginTop: 16, font: '700 24px ' + APP, color: K.faint }}>PAGE 5</div>
                </div>
              ) : null}
            </div>
          ))}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ font: '700 24px ' + APP, letterSpacing: '0.12em', color: K.faint, marginBottom: 18 }}>FINDABLE PASSAGES</div>
          {HITS.map((h, i) => {
            const a = C.Read + 2.6 + i * 0.5;
            const op = ramp(T, a, a + 0.5, MOTION.enter);
            const x = animate({ from: -60, to: 0, start: a, end: a + 0.7, ease: MOTION.enter })(T);
            return (
              <div key={i} style={{
                opacity: op, transform: 'translateX(' + px(x) + ')',
                display: 'flex', alignItems: 'center', gap: 16, padding: '20px 22px', marginBottom: 12,
                borderRadius: 12, background: K.surface2, border: '1px solid ' + K.border,
              }}>
                <div style={{ padding: '6px 14px', borderRadius: 7, background: K.tint, font: '700 24px ' + APP, color: K.soft, whiteSpace: 'nowrap' }}>{h[0]}</div>
                <div style={{ font: '600 26px ' + APP, color: K.ink }}>{h[1]}</div>
              </div>
            );
          })}
          <div style={{
            marginTop: 24, opacity: ramp(T, C.Read + 4.6, C.Read + 5.4, MOTION.enter),
            padding: '20px 22px', borderRadius: 12, background: K.tint, border: '1px solid rgba(124,58,237,0.4)',
            font: '600 24px ' + APP, lineHeight: 1.45, color: K.ink2,
          }}>Your file is kept as it is, so any answer can point back to a real page.</div>
        </div>
      </div>
    </Pane>
  );
}

// ── the chat screen, held across ask / gate / answer / refusal ────────────
const Q = 'What was contractor spend last quarter?';
const ANS = 'Contractor spend for Q3 was $412,800, up 9% on Q2. The largest line is engineering contract work at $221,400.';

function ChatPane({ T, C }) {
  const o = inOut(T, C.Ask - 0.1, 999, 0.5, 0.4);
  const out = ramp(T, C.Closed + 5.2, C.Closed + 6.2);
  const tq = clamp((T - (C.Ask + 0.6)) / 1.3, 0, 1);
  const gate = T >= C.Gate - 0.2 && T < C.Answer + 0.3;
  const ta = clamp((T - (C.Answer + 0.5)) / 1.9, 0, 1);
  const chips = ramp(T, C.Answer + 2.5, C.Answer + 3.0, MOTION.pop);
  const view = ramp(T, C.Answer + 3.4, C.Answer + 4.4, MOTION.enter);
  const hl = ramp(T, C.Answer + 4.4, C.Answer + 5.1, MOTION.enter);
  const refuse = ramp(T, C.Closed + 0.45, C.Closed + 1.3, MOTION.enter);
  const audit = ramp(T, C.Closed + 2.6, C.Closed + 3.6, MOTION.enter);
  const swap = ramp(T, C.Closed + 0.05, C.Closed + 0.45, MOTION.enter); // finance answer → refusal
  return (
    <Pane style={{ opacity: o * (1 - out), padding: '34px 40px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
        <div>
          <div style={{ font: '800 32px ' + APP, letterSpacing: '-0.025em', color: K.ink }}>Chat</div>
          <div style={{ marginTop: 6, font: '600 24px ' + APP, color: K.muted }}>Connected to knowledge base</div>
        </div>
        <div style={{
          padding: '11px 22px', borderRadius: 999, background: K.surface2, border: '1px solid ' + K.border,
          font: '700 24px ' + APP, whiteSpace: 'nowrap', color: swap > 0.5 ? K.body : K.soft,
        }}>{swap > 0.5 ? 'Asked by Employee' : 'Asked by Finance'}</div>
      </div>

      <div style={{
        alignSelf: 'flex-end', marginLeft: 'auto', width: 'fit-content', maxWidth: 780,
        padding: '18px 24px', borderRadius: '14px 14px 4px 14px', background: K.accent,
        font: '500 28px ' + APP, color: '#fff',
      }}>{cut(Q, tq)}</div>

      {gate ? <Gate T={T} C={C} /> : null}

      {!gate && T >= C.Answer ? (
        <div style={{ marginTop: 24 }}>
          <div style={{
            padding: '24px 26px', borderRadius: 14, background: K.panel, border: '1px solid ' + K.border,
            font: '500 28px ' + APP, lineHeight: 1.55, color: K.ink2,
          }}>
            {swap > 0.5 ? (
              <span style={{ opacity: refuse }}>You do not have access to finance reporting. Knowra could not find an authorised source for this question, so it did not answer it.</span>
            ) : (
              <span style={{ opacity: 1 - swap }}>
                {cut(ANS, ta)}
                {[1, 2].map((n) => (
                  <span key={n} style={{
                    display: 'inline-block', marginLeft: 8, transform: 'scale(' + chips + ')',
                    padding: '2px 10px', borderRadius: 6, background: K.tint, border: '1px solid ' + K.soft,
                    font: '700 24px ' + MONO, color: K.soft, verticalAlign: 'middle',
                  }}>{n}</span>
                ))}
              </span>
            )}
          </div>

          {swap < 0.5 ? (
            <div style={{ marginTop: 20, opacity: view * (1 - swap), transform: 'translateY(' + px(18 - 18 * view) + ')', borderRadius: 12, overflow: 'hidden', border: '1px solid ' + K.border }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', padding: '15px 22px', background: K.surface2, font: '700 24px ' + APP, letterSpacing: '0.06em', color: K.faint }}>
                <span>Q3 CONTRACTOR SPEND.XLSX — PAGE 4</span><span style={{ color: K.soft }}>CLOSE</span>
              </div>
              <div style={{ padding: '20px 22px', background: K.surface, font: '500 26px ' + APP, lineHeight: 1.65, color: K.body }}>
                Q3 total contractor cost{' '}
                <span style={{ padding: '3px 8px', borderRadius: 6, background: 'rgba(124,58,237,' + (0.34 * hl) + ')', color: K.ink, fontWeight: 700 }}>$412,800</span>
                {' '}across 14 contractors, of which engineering contract work accounts for $221,400.
              </div>
            </div>
          ) : (
            <div style={{
              marginTop: 20, opacity: audit, display: 'flex', alignItems: 'center', gap: 16,
              padding: '20px 22px', borderRadius: 12, background: K.surface2, border: '1px solid ' + K.border,
              font: '600 26px ' + APP, color: K.body,
            }}>
              <div style={{ width: 10, height: 10, borderRadius: 5, background: K.soft }} />
              Retrieval log: 0 authorised sources. Admins can see every document an answer used.
            </div>
          )}
        </div>
      ) : null}
    </Pane>
  );
}

// ── the permission gate ───────────────────────────────────────────────────
const SRC = [
  ['Q3 Contractor Spend.xlsx', true],
  ['Vendor Contracts 2026.pdf', true],
  ['Personnel Files.pdf', false],
  ['Board Pack Q3.pdf', false],
];

function Gate({ T, C }) {
  const o = inOut(T, C.Gate - 0.2, C.Answer + 0.3, 0.5, 0.3);
  const CW = 580, LX = 620, PASSX = 640;
  return (
    <div style={{ position: 'relative', height: 396, marginTop: 18, opacity: o }}>
      <div style={{
        position: 'absolute', left: 20, top: 22, width: px(CW), height: 366, borderRadius: 14,
        background: 'rgba(255,255,255,0.02)', border: '1px dashed ' + K.border,
      }} />
      <div style={{
        position: 'absolute', left: px(PASSX), top: 22, width: px(CW), height: 240, borderRadius: 14,
        background: 'rgba(124,58,237,0.05)', border: '1px dashed rgba(124,58,237,0.35)',
      }} />
      <div style={{ position: 'absolute', left: 44, top: 38, font: '700 24px ' + APP, letterSpacing: '0.12em', color: K.faint }}>KNOWLEDGE BASE</div>
      <div style={{ position: 'absolute', left: px(PASSX + 24), top: 38, font: '700 24px ' + APP, letterSpacing: '0.12em', color: K.soft }}>THE ASKER’S PERMISSIONS</div>
      <div style={{
        position: 'absolute', left: px(LX), top: 6, width: 3, height: 384,
        background: 'linear-gradient(180deg, rgba(124,58,237,0), ' + K.soft + ', rgba(124,58,237,0))',
      }} />
      {SRC.map((s, i) => {
        const a = C.Gate + 0.5 + i * 0.45;
        const p = ramp(T, a + 0.9, a + 2.2, MOTION.draw);
        const pass = s[1];
        const judged = p > 0.2;
        const blocked = !pass && p > 0.62;
        // pass: all the way into the authorised lane. fail: a nudge forward, then back.
        const x = pass
          ? 20 + p * (PASSX - 20)
          : 20 + (p <= 0.62 ? (p / 0.62) * 70 : 70 - ((p - 0.62) / 0.38) * 70);
        const op = ramp(T, a, a + 0.35, MOTION.enter);
        const row = pass ? 78 + i * 78 : 156 + (i - 2) * 78;
        return (
          <div key={i} style={{
            position: 'absolute', left: px(x), top: px(pass ? row : 78 + i * 78), width: px(CW), opacity: op,
            display: 'flex', alignItems: 'center', gap: 16, padding: '17px 22px', borderRadius: 12,
            background: blocked ? K.surface2 : K.surface,
            border: '1px solid ' + (blocked ? 'rgba(248,113,113,0.45)' : pass && judged ? 'rgba(52,211,153,0.4)' : K.border),
          }}>
            <div style={{
              width: 32, height: 32, borderRadius: 16, flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center',
              background: blocked ? 'rgba(248,113,113,0.18)' : pass && judged ? K.tint : 'rgba(255,255,255,0.05)',
              font: '700 22px ' + APP, color: blocked ? K.bad : pass && judged ? K.ok : K.faint,
            }}>{blocked ? '✕' : pass && judged ? '✓' : '·'}</div>
            <div style={{ flex: 1, minWidth: 0, font: '600 26px ' + APP, whiteSpace: 'nowrap', color: blocked ? K.faint : K.ink }}>{s[0]}</div>
            <div style={{ width: 130, flex: 'none', textAlign: 'right', font: '700 24px ' + APP, color: blocked ? K.bad : pass && judged ? K.ok : K.faint, whiteSpace: 'nowrap' }}>
              {blocked ? 'Not visible' : pass && judged ? 'Readable' : 'Checking'}
            </div>
          </div>
        );
      })}
      <div style={{
        position: 'absolute', left: px(PASSX), top: 286, width: px(CW),
        opacity: ramp(T, C.Gate + 3.4, C.Gate + 4.2, MOTION.enter),
        padding: '20px 22px', borderRadius: 12, background: K.tint, border: '1px solid rgba(124,58,237,0.4)',
        font: '600 24px ' + APP, lineHeight: 1.45, color: K.ink2,
      }}>Only these passages reach the answer. The rest are never read.</div>
    </div>
  );
}

// ── chrome: kicker above, headline below ──────────────────────────────────
const CAPS = [
  ['Ingest', 'Add the documents you already have.'],
  ['Read', 'Knowra reads every page and keeps the original.'],
  ['Ask', 'Someone asks in plain language.'],
  ['Gate', 'Retrieval runs inside that person’s permissions.'],
  ['Answer', 'The answer arrives with the page it came from.'],
  ['Closed', 'No authorised source, no answer.'],
];

function Caption({ T, C }) {
  return (
    <React.Fragment>
      {CAPS.map(([cue, line], i) => {
        const from = C[cue];
        const to = i === CAPS.length - 1 ? C.Closed + 5.4 : C[CAPS[i + 1][0]];
        const op = inOut(T, from - 0.2, to, 0.5, 0.4);
        const y = animate({ from: 16, to: 0, start: from - 0.2, end: from + 0.6, ease: MOTION.enter })(T);
        return (
          <div key={cue} style={{
            position: 'absolute', left: px(WX), top: 862, width: 1620, opacity: op,
            transform: 'translateY(' + px(y) + ')',
            font: '500 46px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.025em', color: P.text,
          }}>{line}</div>
        );
      })}
    </React.Fragment>
  );
}

function Title({ T, C }) {
  const o = inOut(T, 0.2, C.Ingest + 0.3, 0.7, 0.5);
  const g = ramp(T, 0.4, 1.6, MOTION.enter);
  const w = interpolate([0.8, 3.0], [72, 100], MOTION.draw)(T);
  const rule = ramp(T, 1.6, 3.2);
  return (
    <div style={{ position: 'absolute', left: 150, top: 400, opacity: o }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        <Mark size={130} hue={HUE} grow={g} />
        <div>
          <div style={{ font: '400 26px ' + MONO, letterSpacing: '0.24em', color: HU(HUE) }}>02</div>
          <div style={{
            marginTop: 12, font: '600 132px ' + DISP, fontVariationSettings: wdth(w),
            letterSpacing: '-0.04em', lineHeight: 0.95, color: P.text,
          }}>How it works</div>
        </div>
      </div>
      <div style={{ marginTop: 40, width: px(1180 * rule), height: 4, borderRadius: 2, background: 'linear-gradient(90deg,' + HU(HUE) + ',' + HU(HUE, 0.15) + ')' }} />
    </div>
  );
}

function Lockup({ T, C }) {
  const a = C.Closed + 5.6;
  const o = ramp(T, a, a + 0.9, MOTION.enter);
  const g = ramp(T, a + 0.1, a + 1.1, MOTION.enter);
  const line = ramp(T, a + 1.0, a + 1.9, MOTION.enter);
  return (
    <div style={{ position: 'absolute', left: 150, top: 420, opacity: o }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        <Mark size={140} hue={HUE} grow={g} />
        <div style={{ font: '600 150px ' + DISP, fontVariationSettings: wdth(100), letterSpacing: '-0.045em', lineHeight: 0.92, color: P.text }}>Knowra</div>
      </div>
      <div style={{
        marginTop: 46, opacity: line, font: '400 36px ' + DISP, fontVariationSettings: wdth(92), color: P.dim,
      }}>Ask your organisation anything. Open the page it came from.</div>
    </div>
  );
}

function Film() {
  const { T, CUES: C } = useComposition();
  const active = T < C.Read ? 'uploads' : T < C.Ask ? 'documents' : 'chat';
  return (
    <div style={{ position: 'absolute', inset: 0, background: P.bg, overflow: 'hidden', fontFamily: DISP, color: P.text }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(1300px 900px at 24% 40%, ' + HU(HUE, 0.13) + ', rgba(0,0,0,0) 72%)' }} />
      <Shot from={0} to={C.Ingest + 0.6}><Title T={T} C={C} /></Shot>
      <Shot from={C.Ingest - 1.0} to={999}>
        <div style={{
          position: 'absolute', left: px(WX), top: 76,
          opacity: inOut(T, C.Ingest - 0.4, C.Closed + 5.4, 0.6, 0.4),
          font: '400 24px ' + MONO, letterSpacing: '0.22em', color: HU(HUE),
        }}>02 · HOW IT WORKS</div>
        <AppShell T={T} C={C} active={active} />
        <IngestPane T={T} C={C} />
        <ReadPane T={T} C={C} />
        <ChatPane T={T} C={C} />
        <Caption T={T} C={C} />
      </Shot>
      <Shot from={C.Closed + 5.4} to={999}><Lockup T={T} C={C} /></Shot>
    </div>
  );
}

function Knowra02() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} bg={P.bg} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Film />
      </CompositionStage>
      <window.TweaksPanel title="02 How it works">
        <window.TweakSection label="Look">
          <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

window.Knowra02 = Knowra02;

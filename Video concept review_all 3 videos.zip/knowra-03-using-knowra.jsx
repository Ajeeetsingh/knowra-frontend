// Knowra 03 — Using Knowra. 50s.
// One person, one real task, start to finish. Same shell and tokens as 02.

const P = { bg: '#12141f', text: '#e9e9ed', dim: '#a5a7b6', mid: '#8b8d9c' };
const K = {
  bg: '#14121f', surface: '#1c1930', surface2: '#211d36', panel: '#231f3c',
  ink: '#f4f2ff', ink2: '#e4e0f6', body: '#a8a3c6', muted: '#8d88ac', faint: '#7b769a',
  border: '#2e2947', rule: '#282340', accent: '#7c3aed', soft: '#a78bfa',
  tint: 'rgba(124,58,237,0.20)', ok: '#34d399',
};
const DISP = "'Archivo', system-ui, sans-serif";
const APP = "'Plus Jakarta Sans', system-ui, sans-serif";
const MONO = "'Chivo Mono', ui-monospace, monospace";
const HUE = 285;
const HU = (h, a) => 'oklch(0.74 0.15 ' + h + (a == null ? '' : ' / ' + a) + ')';
const px = (n) => n + 'px';
const wdth = (w) => "'wdth' " + w;
const MOTION = { enter: Easing.easeOutQuart, draw: Easing.easeInOutCubic, pop: Easing.easeOutBack };
const inOut = (T, a, b, rise, fall) => Math.min(
  animate({ from: 0, to: 1, start: a, end: a + rise, ease: MOTION.enter })(T),
  animate({ from: 1, to: 0, start: b - fall, end: b, ease: MOTION.draw })(T)
);
const ramp = (T, a, b, ease) => animate({ from: 0, to: 1, start: a, end: b, ease: ease || MOTION.draw })(T);
const cut = (s, p) => (
  <span>{s.slice(0, Math.floor(p * s.length))}
    <span style={{ visibility: 'hidden' }}>{s.slice(Math.floor(p * s.length))}</span>
  </span>
);

const WX = 150, WY = 140, WW = 1620, WH = 690, BAR = 56, SBW = 300;
const MX = WX + SBW, MY = WY + BAR, MW = WW - SBW, MH = WH - BAR;

const NAV = [
  { group: 'WORKSPACE', items: [['dashboard', 'Dashboard'], ['chat', 'Chat'], ['documents', 'Documents']] },
  { group: 'MANAGE', items: [['admin', 'Admin overview'], ['uploads', 'Upload Center'], ['collections', 'Collections'], ['users', 'Users']] },
];

function Mark({ size, hue, grow }) {
  const s = size, g = grow == null ? 1 : grow;
  return (
    <div style={{ position: 'relative', width: px(s), height: px(s), borderRadius: px(s * 0.24), border: '2px solid ' + HU(hue, 0.45) }}>
      {[0, 1, 2].map((i) => (
        <div key={i} style={{
          position: 'absolute', left: px(s * 0.16), top: px(s * (0.2 + i * 0.24)),
          width: px(s * (0.68 - i * 0.16) * clamp(g * 1.6 - i * 0.3, 0, 1)), height: px(s * 0.11),
          borderRadius: px(s * 0.055), background: HU(hue),
          boxShadow: '0 0 ' + px(s * 0.3) + ' ' + HU(hue, 0.4),
        }} />
      ))}
    </div>
  );
}

// ── sign in ───────────────────────────────────────────────────────────────
function Login({ T, C }) {
  const o = inOut(T, C.Enter - 0.1, C.Enter + 2.8, 0.6, 0.5);
  const y = animate({ from: 26, to: 0, start: C.Enter - 0.1, end: C.Enter + 0.7, ease: MOTION.enter })(T);
  const press = ramp(T, C.Enter + 1.9, C.Enter + 2.3, MOTION.enter);
  return (
    <div style={{
      position: 'absolute', left: 660, top: 250, width: 600, opacity: o,
      transform: 'translateY(' + px(y) + ')', padding: 48, borderRadius: 20,
      background: K.surface, border: '1px solid ' + K.border, boxShadow: '0 40px 90px rgba(0,0,0,0.5)', fontFamily: APP,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 36 }}>
        <div style={{ width: 40, height: 40, borderRadius: 10, background: K.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', font: '800 24px ' + APP, color: '#fff' }}>K</div>
        <div style={{ font: '800 30px ' + APP, letterSpacing: '-0.03em', color: K.ink }}>Knowra</div>
      </div>
      {['Work email', 'Password'].map((l, i) => (
        <div key={l} style={{ marginBottom: 22 }}>
          <div style={{ font: '600 24px ' + APP, color: K.muted, marginBottom: 10 }}>{l}</div>
          <div style={{ padding: '18px 20px', borderRadius: 12, background: K.surface2, border: '1px solid ' + K.border, font: '500 26px ' + APP, color: K.ink }}>
            {i === 0 ? cut('mara@apexnational.com', clamp((T - (C.Enter + 0.5)) / 0.9, 0, 1)) : '••••••••••'}
          </div>
        </div>
      ))}
      <div style={{
        marginTop: 32, padding: '20px 24px', borderRadius: 12, textAlign: 'center',
        background: press > 0.5 ? K.soft : K.accent, font: '700 26px ' + APP, color: '#fff',
      }}>Sign in</div>
    </div>
  );
}

// ── the window ────────────────────────────────────────────────────────────
function AppShell({ T, C, active }) {
  const o = inOut(T, C.Enter + 2.4, 999, 0.7, 0.4);
  const y = animate({ from: 28, to: 0, start: C.Enter + 2.4, end: C.Enter + 3.3, ease: MOTION.enter })(T);
  const out = ramp(T, C.Close - 0.4, C.Close + 0.6, MOTION.draw);
  return (
    <div style={{
      position: 'absolute', left: px(WX), top: px(WY), width: px(WW), height: px(WH),
      opacity: o * (1 - out), transform: 'translateY(' + px(y) + ') scale(' + (1 - 0.04 * out) + ')',
      borderRadius: 22, overflow: 'hidden', background: K.surface,
      border: '1px solid ' + K.border, boxShadow: '0 40px 100px rgba(0,0,0,0.55)', fontFamily: APP,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, height: px(BAR), padding: '0 24px', background: K.surface2, borderBottom: '1px solid ' + K.rule }}>
        {['#ff5f57', '#febc2e', '#28c840'].map((c) => <div key={c} style={{ width: 12, height: 12, borderRadius: 6, background: c }} />)}
        <div style={{ marginLeft: 10, font: '700 24px ' + APP, color: K.muted }}>Knowra</div>
        <div style={{ marginLeft: 'auto', font: '600 22px ' + APP, color: K.faint }}>Mara Sen · Admin</div>
      </div>
      <div style={{ display: 'flex', height: px(WH - BAR) }}>
        <div style={{ width: px(SBW), padding: '26px 20px', background: K.surface2, borderRight: '1px solid ' + K.rule }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 30 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: K.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', font: '800 22px ' + APP, color: '#fff' }}>K</div>
            <div style={{ font: '800 24px ' + APP, letterSpacing: '-0.03em', color: K.ink }}>Knowra</div>
          </div>
          {NAV.map((g) => (
            <div key={g.group} style={{ marginBottom: 26 }}>
              <div style={{ font: '700 20px ' + APP, letterSpacing: '0.12em', color: K.faint, marginBottom: 12 }}>{g.group}</div>
              {g.items.map(([id, label]) => {
                const on = id === active;
                return (
                  <div key={id} style={{
                    display: 'flex', alignItems: 'center', gap: 12, padding: '11px 14px', marginBottom: 4, borderRadius: 10,
                    background: on ? K.tint : 'transparent',
                    font: (on ? '700 23px ' : '500 23px ') + APP, color: on ? K.soft : K.body,
                  }}>
                    <div style={{ width: 8, height: 8, borderRadius: 4, background: on ? K.soft : K.border }} />{label}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
        <div style={{ position: 'relative', width: px(MW), height: px(MH), background: K.surface }} />
      </div>
    </div>
  );
}

function Pane({ children, style }) {
  return (
    <div style={{
      position: 'absolute', left: px(MX), top: px(MY), width: px(MW), height: px(MH),
      overflow: 'hidden', fontFamily: APP, padding: '34px 40px', boxSizing: 'border-box', ...style,
    }}>{children}</div>
  );
}

// ── dashboard ─────────────────────────────────────────────────────────────
const KPIS = [['Documents', '33'], ['Pages indexed', '1,412'], ['Search success', '94%'], ['Your questions', '4']];
const RECENT = [
  ['Remote work for new joiners', 'you · today'],
  ['Expense claim limits', 'you · yesterday'],
  ['Parental leave notice period', 'you · last week'],
];

function DashPane({ T, C }) {
  const o = inOut(T, C.Enter + 2.6, C.Ask + 0.4, 0.5, 0.5);
  return (
    <Pane style={{ opacity: o }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 20, marginBottom: 26 }}>
        <div style={{ font: '800 36px ' + APP, letterSpacing: '-0.025em', color: K.ink }}>Dashboard</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, font: '600 24px ' + APP, color: K.ok }}>
          <div style={{ width: 10, height: 10, borderRadius: 5, background: K.ok }} />AI assistant ready
        </div>
      </div>
      <div style={{ display: 'flex', gap: 14, marginBottom: 28 }}>
        {KPIS.map((k, i) => {
          const a = C.Enter + 2.9 + i * 0.18;
          const op = ramp(T, a, a + 0.5, MOTION.enter);
          const y = animate({ from: 18, to: 0, start: a, end: a + 0.6, ease: MOTION.enter })(T);
          return (
            <div key={k[0]} style={{
              flex: 1, padding: '20px 22px', borderRadius: 14, opacity: op, transform: 'translateY(' + px(y) + ')',
              background: K.surface2, border: '1px solid ' + K.border,
            }}>
              <div style={{ font: '800 40px ' + APP, letterSpacing: '-0.03em', color: K.ink }}>{k[1]}</div>
              <div style={{ marginTop: 6, font: '600 24px ' + APP, color: K.muted }}>{k[0]}</div>
            </div>
          );
        })}
      </div>
      <div style={{ font: '700 24px ' + APP, letterSpacing: '0.12em', color: K.faint, marginBottom: 16 }}>RECENT CONVERSATIONS</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {RECENT.map((r, i) => {
          const a = C.Enter + 3.6 + i * 0.2;
          const op = ramp(T, a, a + 0.5, MOTION.enter);
          return (
            <div key={r[0]} style={{
              opacity: op, display: 'flex', alignItems: 'center', gap: 16, padding: '18px 22px',
              borderRadius: 12, background: K.surface2, border: '1px solid ' + K.border,
            }}>
              <div style={{ width: 10, height: 10, borderRadius: 5, background: i === 0 ? K.soft : K.border }} />
              <div style={{ flex: 1, font: '600 26px ' + APP, color: K.ink }}>{r[0]}</div>
              <div style={{ font: '500 24px ' + APP, color: K.faint, whiteSpace: 'nowrap' }}>{r[1]}</div>
            </div>
          );
        })}
      </div>
    </Pane>
  );
}

// ── chat: ask, answer, verify ─────────────────────────────────────────────
const Q = 'What is the remote work policy for new joiners?';
const ANS = 'New joiners work from the office for their first 30 days, then move to the standard hybrid schedule of three days on site. Requests for full remote go through your manager and HR.';
const THREADS = [['Remote work for new joiners', true], ['Expense claim limits', false], ['Parental leave notice', false]];

function ChatPane({ T, C }) {
  const o = inOut(T, C.Ask - 0.1, C.Add + 0.3, 0.5, 0.5);
  const tq = clamp((T - (C.Ask + 0.9)) / 1.7, 0, 1);
  const send = ramp(T, C.Ask + 2.9, C.Ask + 3.3, MOTION.enter);
  const think = T >= C.Ask + 3.3 && T < C.Answer + 0.2;
  const ta = clamp((T - (C.Answer + 0.2)) / 2.4, 0, 1);
  const chip = ramp(T, C.Answer + 3.2, C.Answer + 3.7, MOTION.pop);
  const srcs = ramp(T, C.Answer + 4.0, C.Answer + 4.8, MOTION.enter);
  const view = ramp(T, C.Verify + 0.8, C.Verify + 1.8, MOTION.enter);
  const hl = ramp(T, C.Verify + 2.0, C.Verify + 2.8, MOTION.enter);
  const TW = 344, THW = MW - 80 - TW - 34;
  return (
    <Pane style={{ opacity: o, display: 'flex', gap: 34 }}>
      <div style={{ width: px(TW), flex: 'none' }}>
        <div style={{ font: '700 24px ' + APP, letterSpacing: '0.1em', color: K.faint, marginBottom: 16 }}>CONVERSATIONS</div>
        {THREADS.map(([t, on]) => (
          <div key={t} style={{
            padding: '16px 18px', marginBottom: 10, borderRadius: 12,
            background: on ? K.tint : 'transparent', border: '1px solid ' + (on ? 'rgba(124,58,237,0.4)' : K.border),
            font: (on ? '700 24px ' : '500 24px ') + APP, lineHeight: 1.3, color: on ? K.ink : K.body,
          }}>{t}</div>
        ))}
      </div>
      <div style={{ width: px(THW), flex: 'none' }}>
        <div style={{
          marginLeft: 'auto', width: 'fit-content', maxWidth: 680, padding: '18px 24px',
          borderRadius: '14px 14px 4px 14px', background: K.accent,
          opacity: 0.55 + 0.45 * send, font: '500 26px ' + APP, lineHeight: 1.35, color: '#fff',
        }}>{cut(Q, tq)}</div>

        {think ? (
          <div style={{ marginTop: 22, display: 'flex', alignItems: 'center', gap: 12 }}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{
                width: 12, height: 12, borderRadius: 6, background: K.soft,
                opacity: 0.3 + 0.7 * clamp(Math.sin((T - C.Ask) * 5 - i * 0.7), 0, 1),
              }} />
            ))}
            <div style={{ marginLeft: 6, font: '600 24px ' + APP, color: K.muted }}>Reading your documents</div>
          </div>
        ) : null}

        {ta > 0.005 ? (
          <div style={{ marginTop: 22 }}>
            <div style={{
              padding: '22px 26px', borderRadius: 14, background: K.panel, border: '1px solid ' + K.border,
              font: '500 26px ' + APP, lineHeight: 1.55, color: K.ink2,
            }}>
              {cut(ANS, ta)}
              <span style={{
                display: 'inline-block', marginLeft: 8, transform: 'scale(' + chip + ')',
                padding: '2px 10px', borderRadius: 6,
                background: view > 0.3 ? K.soft : K.tint, border: '1px solid ' + K.soft,
                font: '700 24px ' + MONO, color: view > 0.3 ? '#1c1930' : K.soft, verticalAlign: 'middle',
              }}>1</span>
            </div>
            <div style={{ marginTop: 16, opacity: srcs, display: 'flex', alignItems: 'center', gap: 14, padding: '16px 20px', borderRadius: 12, background: K.surface2, border: '1px solid ' + K.border }}>
              <div style={{ font: '700 24px ' + MONO, color: K.soft }}>[1]</div>
              <div style={{ flex: 1, font: '600 24px ' + APP, color: K.ink, whiteSpace: 'nowrap' }}>Remote Work Policy.pdf</div>
              <div style={{ font: '500 24px ' + APP, color: K.faint, whiteSpace: 'nowrap' }}>page 5</div>
              <div style={{ font: '700 24px ' + APP, color: K.soft, whiteSpace: 'nowrap' }}>Open</div>
            </div>
            {view > 0.01 ? (
              <div style={{ marginTop: 16, opacity: view, transform: 'translateY(' + px(16 - 16 * view) + ')', borderRadius: 12, overflow: 'hidden', border: '1px solid ' + K.border }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', padding: '14px 20px', background: K.surface2, font: '700 24px ' + APP, letterSpacing: '0.06em', color: K.faint }}>
                  <span>REMOTE WORK POLICY.PDF · PAGE 5</span><span style={{ color: K.soft }}>CLOSE</span>
                </div>
                <div style={{ padding: '18px 22px', background: K.surface, font: '500 24px ' + APP, lineHeight: 1.6, color: K.body }}>
                  5.2 Onboarding period —{' '}
                  <span style={{ padding: '3px 8px', borderRadius: 6, background: 'rgba(124,58,237,' + (0.34 * hl) + ')', color: K.ink, fontWeight: 700 }}>
                    New joiners are office-based for the first thirty days, after which the standard hybrid schedule of three on-site days applies.
                  </span>
                </div>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>
    </Pane>
  );
}

// ── add a document ────────────────────────────────────────────────────────
const COLLECTIONS = [['HR Policies', '11 documents'], ['Finance', '8 documents'], ['Onboarding', '6 documents'], ['Engineering', '8 documents']];

function AddPane({ T, C }) {
  const o = inOut(T, C.Add - 0.1, C.Close, 0.5, 0.5);
  const drop = ramp(T, C.Add + 0.5, C.Add + 1.2, MOTION.enter);
  const prog = ramp(T, C.Add + 1.3, C.Add + 3.2);
  const done = prog > 0.999;
  const filed = ramp(T, C.Add + 3.6, C.Add + 4.4, MOTION.enter);
  return (
    <Pane style={{ opacity: o }}>
      <div style={{ font: '800 36px ' + APP, letterSpacing: '-0.025em', color: K.ink }}>Upload Center</div>
      <div style={{ marginTop: 8, font: '500 24px ' + APP, color: K.muted, marginBottom: 26 }}>Admins and anyone granted upload rights can add to the library.</div>
      <div style={{
        padding: '26px 28px', borderRadius: 14, marginBottom: 22,
        background: K.tint, border: '1px dashed ' + K.soft, opacity: 0.4 + 0.6 * drop,
        display: 'flex', alignItems: 'center', gap: 20,
      }}>
        <div style={{ font: '800 34px ' + APP, color: K.soft }}>+</div>
        <div style={{ font: '600 26px ' + APP, color: K.ink2 }}>Leave Policy 2026.pdf dropped here</div>
      </div>
      <div style={{
        opacity: drop, display: 'flex', alignItems: 'center', gap: 18, padding: '18px 22px', borderRadius: 12,
        background: K.surface2, border: '1px solid ' + (done ? 'rgba(52,211,153,0.35)' : K.border), marginBottom: 26,
      }}>
        <div style={{ width: 12, height: 12, borderRadius: 3, background: done ? K.ok : K.soft }} />
        <div style={{ flex: 1, font: '600 26px ' + APP, color: K.ink }}>Leave Policy 2026.pdf</div>
        <div style={{ font: '500 24px ' + APP, color: K.faint }}>18 pages</div>
        <div style={{ width: 200, height: 8, borderRadius: 4, background: K.rule, overflow: 'hidden' }}>
          <div style={{ width: px(200 * prog), height: 8, borderRadius: 4, background: done ? K.ok : K.accent }} />
        </div>
        <div style={{ width: 156, textAlign: 'right', font: '700 24px ' + APP, color: done ? K.ok : K.soft }}>{done ? 'Searchable' : 'Reading'}</div>
      </div>
      <div style={{ font: '700 24px ' + APP, letterSpacing: '0.12em', color: K.faint, marginBottom: 16 }}>COLLECTIONS</div>
      <div style={{ display: 'flex', gap: 14 }}>
        {COLLECTIONS.map((c, i) => {
          const hot = i === 0;
          return (
            <div key={c[0]} style={{
              flex: 1, padding: '20px 22px', borderRadius: 14,
              background: hot ? 'rgba(124,58,237,' + (0.06 + 0.14 * filed) + ')' : K.surface2,
              border: '1px solid ' + (hot ? 'rgba(124,58,237,' + (0.2 + 0.35 * filed) + ')' : K.border),
            }}>
              <div style={{ font: '700 26px ' + APP, color: K.ink }}>{c[0]}</div>
              <div style={{ marginTop: 8, font: '500 24px ' + APP, color: hot && filed > 0.5 ? K.soft : K.muted }}>
                {hot && filed > 0.5 ? '12 documents · just updated' : c[1]}
              </div>
            </div>
          );
        })}
      </div>
    </Pane>
  );
}

// ── chrome ────────────────────────────────────────────────────────────────
const CAPS = [
  ['Enter', 'Sign in. What you see is what you are cleared to see.'],
  ['Ask', 'Ask the way you would ask a colleague.'],
  ['Answer', 'The answer arrives with its source attached.'],
  ['Verify', 'Open the citation and read the page yourself.'],
  ['Add', 'New document? Drop it in. It is searchable in seconds.'],
];

function Caption({ T, C }) {
  return (
    <React.Fragment>
      {CAPS.map(([cue, line], i) => {
        const from = C[cue];
        const to = i === CAPS.length - 1 ? C.Close - 0.2 : C[CAPS[i + 1][0]];
        const op = inOut(T, from - 0.2, to, 0.5, 0.4);
        const y = animate({ from: 16, to: 0, start: from - 0.2, end: from + 0.6, ease: MOTION.enter })(T);
        return (
          <div key={cue} style={{
            position: 'absolute', left: px(WX), top: 862, width: 1620, opacity: op,
            transform: 'translateY(' + px(y) + ')',
            font: '500 46px ' + DISP, fontVariationSettings: wdth(90), letterSpacing: '-0.025em', color: P.text,
          }}>{line}</div>
        );
      })}
    </React.Fragment>
  );
}

function Title({ T, C }) {
  const o = inOut(T, 0.2, C.Enter + 0.3, 0.7, 0.5);
  const g = ramp(T, 0.3, 1.4, MOTION.enter);
  const w = interpolate([0.6, 2.6], [72, 100], MOTION.draw)(T);
  const rule = ramp(T, 1.3, 2.8);
  return (
    <div style={{ position: 'absolute', left: 150, top: 400, opacity: o }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        <Mark size={130} hue={HUE} grow={g} />
        <div>
          <div style={{ font: '400 26px ' + MONO, letterSpacing: '0.24em', color: HU(HUE) }}>03</div>
          <div style={{
            marginTop: 12, font: '600 132px ' + DISP, fontVariationSettings: wdth(w),
            letterSpacing: '-0.04em', lineHeight: 0.95, color: P.text,
          }}>Using Knowra</div>
        </div>
      </div>
      <div style={{ marginTop: 40, width: px(1180 * rule), height: 4, borderRadius: 2, background: 'linear-gradient(90deg,' + HU(HUE) + ',' + HU(HUE, 0.15) + ')' }} />
    </div>
  );
}

function Close({ T, C }) {
  const a = C.Close + 0.5;
  const o = ramp(T, a, a + 0.9, MOTION.enter);
  const g = ramp(T, a + 0.1, a + 1.1, MOTION.enter);
  const steps = ['Ask.', 'Read the answer.', 'Open the page.'];
  return (
    <div style={{ position: 'absolute', left: 150, top: 400, opacity: o }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 40 }}>
        <Mark size={140} hue={HUE} grow={g} />
        <div style={{ font: '600 150px ' + DISP, fontVariationSettings: wdth(100), letterSpacing: '-0.045em', lineHeight: 0.92, color: P.text }}>Knowra</div>
      </div>
      <div style={{ marginTop: 50, display: 'flex', gap: 40 }}>
        {steps.map((t, i) => (
          <div key={t} style={{
            opacity: ramp(T, a + 1.0 + i * 0.35, a + 1.6 + i * 0.35, MOTION.enter),
            font: '400 42px ' + DISP, fontVariationSettings: wdth(92), color: i === 2 ? HU(HUE) : P.dim,
          }}>{t}</div>
        ))}
      </div>
    </div>
  );
}

function Film() {
  const { T, CUES: C } = useComposition();
  const active = T < C.Ask ? 'dashboard' : T < C.Add ? 'chat' : 'uploads';
  return (
    <div style={{ position: 'absolute', inset: 0, background: P.bg, overflow: 'hidden', fontFamily: DISP, color: P.text }}>
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(1300px 900px at 24% 40%, ' + HU(HUE, 0.13) + ', rgba(0,0,0,0) 72%)' }} />
      <Shot from={0} to={C.Enter + 0.6}><Title T={T} C={C} /></Shot>
      <Shot from={C.Enter - 0.4} to={C.Enter + 3.2}><Login T={T} C={C} /></Shot>
      <Shot from={C.Enter + 2.0} to={C.Close + 1.0}>
        <div style={{
          position: 'absolute', left: px(WX), top: 76,
          opacity: inOut(T, C.Enter + 2.4, C.Close, 0.6, 0.4),
          font: '400 24px ' + MONO, letterSpacing: '0.22em', color: HU(HUE),
        }}>03 · USING KNOWRA</div>
        <AppShell T={T} C={C} active={active} />
        <DashPane T={T} C={C} />
        <ChatPane T={T} C={C} />
        <AddPane T={T} C={C} />
        <Caption T={T} C={C} />
      </Shot>
      <Shot from={C.Close} to={999}><Close T={T} C={C} /></Shot>
    </div>
  );
}

function Knowra03() {
  const [tw, setTweak] = window.useTweaks(window.TWEAK_DEFAULTS || { motionEditor: true });
  return (
    <React.Fragment>
      <CompositionStage width={1920} height={1080} bg={P.bg} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        <Film />
      </CompositionStage>
      <window.TweaksPanel title="03 Using Knowra">
        <window.TweakSection label="Look">
          <window.TweakToggle label="Motion editor" value={tw.motionEditor} onChange={(v) => setTweak('motionEditor', v)} />
        </window.TweakSection>
      </window.TweaksPanel>
    </React.Fragment>
  );
}

window.Knowra03 = Knowra03;
